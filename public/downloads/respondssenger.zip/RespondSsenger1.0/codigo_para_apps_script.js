// CÓDIGO PARA COPIAR Y PEGAR EN GOOGLE APPS SCRIPT (Editor)

function doPost(e) {
    // Configurar cabeceras CORS y tipo JSON
    var output = ContentService.createTextOutput();
    output.setMimeType(ContentService.MimeType.JSON);

    try {
        // 1. Obtener parámetros (soporta x-www-form-urlencoded y JSON body)
        var params = e.parameter || {};

        // Si no hay parámetros en e.parameter (a veces pasa con JSON puro), parsear postData
        if (Object.keys(params).length === 0 && e.postData && e.postData.contents) {
            try {
                var jsonBody = JSON.parse(e.postData.contents);
                // Mezclar con params
                for (var key in jsonBody) {
                    params[key] = jsonBody[key];
                }
            } catch (err) {
                // No es JSON, seguir
            }
        }

        var action = params.action;
        var email = params.email;
        var whatsapp = params.whatsapp;
        var key = params.key;

        // --- BASE DE DATOS SIMULADA ---
        // En un caso real, usarías SpreadsheetApp para guardar en una hoja de cálculo.
        // Aquí validamos lógica básica.

        var response = {
            status: 'error',
            message: 'Acción no válida'
        };

        // 2. Lógica de registro TRIAL
        if (action === 'trial') {
            if (!email || !whatsapp) {
                response = { status: 'error', message: 'Faltan datos (email o whatsapp).' };
            } else {
                // AQUÍ GUARDARÍAS EN TU HOJA DE CÁLCULO
                // saveToSheet(email, whatsapp, 'TRIAL');

                // Calculamos fecha de expiración (30 días)
                var expireDate = new Date();
                expireDate.setDate(expireDate.getDate() + 30);

                response = {
                    status: 'success',
                    result: 'success', // Compatibilidad
                    plan: 'pro',
                    key: 'TRIAL-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
                    expires: expireDate.toISOString()
                };
            }
        }

        // 3. Lógica de validación LICENCIA
        else if (action === 'validate') {
            if (!key) {
                response = { status: 'error', message: 'Falta la licencia (key).' };
            } else {
                // Validar licencia real (simulada aquí)
                // Ejemplo: Si la licencia empieza por "PRO", es válida.
                if (key.indexOf('PRO') === 0 || key.indexOf('TRIAL') === 0 || key === 'DEMO123') {
                    var expireDate = new Date();
                    expireDate.setDate(expireDate.getDate() + 365); // 1 año

                    response = {
                        status: 'success',
                        result: 'success',
                        plan: 'pro',
                        expires: expireDate.toISOString(),
                        key: key
                    };
                } else {
                    response = { status: 'error', message: 'Licencia inválida o no encontrada.' };
                }
            }
        }

        // Devolver JSON
        output.setContent(JSON.stringify(response));
        return output;

    } catch (error) {
        var errorResponse = {
            status: 'error',
            message: 'Error en servidor: ' + error.toString()
        };
        output.setContent(JSON.stringify(errorResponse));
        return output;
    }
}

function doGet(e) {
    // Manejar peticiones GET simples (para probar en navegador)
    var params = e.parameter;
    var output = ContentService.createTextOutput();
    output.setMimeType(ContentService.MimeType.JSON);
    output.setContent(JSON.stringify({
        status: 'success',
        message: 'Servidor de licencias activo. Usa POST para acciones.'
    }));
    return output;
}
