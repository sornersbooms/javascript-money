// content.js - RespondMessenger 1.0 (Modularized)

// ==========================================
// CONFIGURACIÓN DE CATEGORÍAS Y RESPUESTAS
// ==========================================
const CATEGORIES = {
  "IA Copiloto 🧠": [
    { type: 'ai_panel', title: 'Panel de IA', text: '' }
  ],
  "Disponibilidad ✅": [
    {
      title: "Sí + Gancho Escasez",
      tag: "Apertura",
      text: "¡Hola [Nombre]! 👋 Sí, el [Producto] está disponible. De hecho, nos quedan pocas unidades con el precio promocional de [Precio] y envío GRATIS. ¿Te gustaría asegurar el tuyo antes de que se agoten?"
    },
    {
      title: "Sí + Info Rápida",
      tag: "Directo",
      text: "¡Claro que sí, [Nombre]! 😊 El [Producto] está disponible por [Precio] con pago contraentrega (pagas cuando lo recibes en tu casa). Envío GRATIS a toda Colombia. ¿Te lo aparto?"
    },
    {
      title: "Sí + Beneficios",
      tag: "Valor",
      text: "¡Hola [Nombre]! Sí está disponible. 🎉 El [Producto] cuesta [Precio] e incluye:\n✅ Envío GRATIS\n✅ Pago Contraentrega\n✅ Garantía de satisfacción\n\n¿Procedemos con tu pedido?"
    },
    {
      title: "Sí + Urgencia",
      tag: "FOMO",
      text: "¡Sí, [Nombre]! Aún tenemos disponibilidad. 🔥 Pero te recomiendo confirmar pronto porque este [Producto] se está vendiendo muy rápido hoy. Precio: [Precio] con envío gratis. ¿Lo confirmamos ya?"
    },
    {
      title: "Sí + Pregunta Calificadora",
      tag: "Engagement",
      text: "¡Hola [Nombre]! Sí, el [Producto] está disponible. 😊 ¿Lo buscas para uso personal o es un regalo? Así puedo darte la mejor recomendación."
    }
  ],
  "Ganchos 🔥": [
    {
      title: "Escasez Inmediata",
      tag: "Apertura",
      text: "¡Hola [Nombre]! 👋 Veo que estás interesado en [Producto]. Solo nos quedan 3 unidades disponibles con envío gratis hoy. ¿Te gustaría aprovechar la oferta antes de que se agoten?"
    },
    {
      title: "Curiosidad",
      tag: "Hook",
      text: "¡Hola [Nombre]! Este es uno de nuestros productos más vendidos de la semana. 🌟 Muchos clientes lo llevan por su gran calidad. ¿Lo buscabas para uso personal o para regalo?"
    },
    {
      title: "Oferta Flash",
      tag: "Urgencia",
      text: "¡Bienvenido [Nombre]! 🎉 Solo por hoy tenemos un precio especial de lanzamiento para [Producto]. Si confirmas ahora, te aseguras el precio antiguo antes de la subida. ¿Te interesa ver los detalles?"
    }
  ],
  "Ofertas 🎁": [
    {
      title: "Promo 2 Unidades",
      tag: "Upsell",
      text: "¡Aprovecha nuestra promo del día [Nombre]! 🌟 Si llevas 2 unidades de [Producto], te quedan en solo [Precio Oferta] (Ahorras un 20%). Ideal para regalar o tener repuesto. ¿Te gustaría aplicar este descuento a tu orden?"
    },
    {
      title: "Envío Prioritario",
      tag: "Valor",
      text: "Por ser cliente nuevo, si confirmas tu pedido de [Producto] en los próximos 10 minutos, te actualizamos a Envío Prioritario GRATIS. 🚀 Tu pedido saldrá en el primer despacho de mañana. ¿Tomamos tus datos?"
    },
    {
      title: "Combo Familiar",
      tag: "Ticket Alto",
      text: "Tenemos una oferta especial para familias: 3 unidades de [Producto] por un precio increíble. 👨‍👩‍👧‍👦 Así todos tienen el suyo y pagas un solo envío. ¿Te interesa conocer el precio del pack familiar?"
    }
  ],
  "Info & Envío 📦": [
    {
      title: "Info General + Cierre",
      tag: "Básico",
      text: "¡Claro [Nombre]! El [Producto] es ideal para ti. Su precio es de [Precio] y lo mejor es que ofrecemos **Pago Contraentrega**: pagas solo al recibirlo en la puerta de tu casa. 🏠 ¿Te gustaría que tomemos tus datos para el envío?"
    },
    {
      title: "Envío Gratis 🚚",
      tag: "Beneficio",
      text: "¡Para nada [Nombre]! El envío es totalmente **GRATIS** a nivel nacional. 🇨🇴 Tú solo pagas el valor del producto ([Precio]) cuando lo recibes en tus manos. ¿Te animas a pedirlo?"
    },
    {
      title: "Todo Incluido",
      tag: "Transparencia",
      text: "El precio de [Precio] es final y ya incluye los costos de envío y el servicio de pago contraentrega. No hay cargos ocultos ni sorpresas. 😉 ¿Procedemos con tu orden?"
    },
    {
      title: "Tiempos de Envío",
      tag: "Logística",
      text: "El tiempo estimado de entrega es de 12 a 18 días hábiles. 🚚 Sabemos que la espera puede parecer larga, pero te garantizamos el mejor precio del mercado y la seguridad total de pagar solo al recibir. ¿Estás de acuerdo con este plazo para proceder?"
    },
    {
      title: "Garantía",
      tag: "Confianza",
      text: "Todos nuestros productos cuentan con garantía de satisfacción. Si llega con algún defecto, lo reponemos sin costo. Compras con 0% de riesgo gracias al pago contraentrega. 🛡️ ¿Te da tranquilidad esta garantía para realizar tu pedido?"
    }
  ],
  "Logística 🚚": [
    {
      title: "No llega hoy 🛑",
      tag: "Aclaración",
      text: "Hola [Nombre]. Te comento que no realizamos entregas el mismo día. 🚚 Manejamos una logística de envíos nacionales que toma unos días hábiles en llegar a tu ubicación. ¿Te sirve esperar un poco para recibir el mejor producto?"
    },
    {
      title: "Soy Distribuidor 🏭",
      tag: "Modelo",
      text: "Te cuento cómo funcionamos: soy distribuidor autorizado y el producto sale directamente de la bodega del proveedor principal. 🏭 Por eso no puedo entregártelo yo mismo hoy, pero te garantizo que te llega totalmente nuevo y garantizado."
    },
    {
      title: "Tiempo de Entrega ⏳",
      tag: "Info",
      text: "El tiempo de llegada depende netamente de la transportadora (como Envía o Interrapidisimo). 🚛 Nosotros agilizamos el despacho para que salga cuanto antes, pero el tránsito normal toma de 2 a 5 días hábiles. ¿Podemos proceder con el envío?"
    }
  ],
  "Ubicación 📍": [
    {
      title: "Bodegas Nacionales",
      tag: "Logística",
      text: "Nuestras oficinas administrativas están en Medellín, pero contamos con bodegas de distribución en las principales ciudades del país para agilizar las entregas. 🚚 Tu pedido saldrá de la bodega más cercana con stock disponible directamente a tu casa. ¿A qué ciudad sería el envío?"
    },
    {
      title: "Tienda 100% Virtual",
      tag: "Modelo",
      text: "Somos una tienda 100% virtual. 💻 Al no tener los gastos de un local físico, podemos ofrecerte el mejor precio del mercado y ENVÍO GRATIS. Además, te damos la seguridad total de pagar solo cuando recibes el producto. ¿Te parece justo?"
    },
    {
      title: "Medellín + Envíos",
      tag: "Confianza",
      text: "Estamos baseados en Medellín. 🌆 Sin embargo, cubrimos todo el país con pago contraentrega. No tienes que moverte de tu casa, nosotros te lo llevamos y pagas al recibir. ¿En qué municipio te encuentras para verificar la cobertura?"
    }
  ],
  "Objeciones 🛡️": [
    {
      title: "Precio Alto",
      tag: "Valor",
      text: "Entiendo que el precio es un factor importante, [Nombre]. Sin embargo, considera que este [Producto] es de alta calidad y el envío es totalmente GRATIS hasta tu casa. Además, la tranquilidad de pagar al recibir no tiene precio. ¿Te animas a probarlo?"
    },
    {
      title: "Tiempo de Espera",
      tag: "Manejo",
      text: "Es verdad, 2-3 semanas no es inmediato. Pero esta logística nos permite ofrecerte este precio tan competitivo sin cobrarte envío por adelantado. Muchos clientes prefieren esperar un poco y asegurar su dinero pagando al recibir. ¿Vale la pena el ahorro para ti?"
    },
    {
      title: "Vi uno más barato",
      tag: "Calidad",
      text: "Es posible encontrar opciones más económicas, pero ten cuidado con las imitaciones. Nosotros garantizamos la versión original de [Producto] y te damos la seguridad del pago contraentrega. Lo barato a veces sale caro. ¿Prefieres arriesgarte o ir a la segura con nosotros?"
    },
    {
      title: "Consultaré con esposa/o",
      tag: "Cierre",
      text: "¡Perfecto! Es una excelente decisión familiar. 🏠 Solo ten en cuenta que la promoción de envío gratis termina hoy. ¿Te gustaría que te aparte una unidad sin compromiso por 24 horas mientras lo consultan?"
    }
  ],
  "Fotos/Videos 📸": [
    {
      title: "No tengo video",
      tag: "Honestidad",
      text: "Entiendo perfectamente que quieras ver un video. 🎥 Actualmente el fabricante no nos ha enviado el video oficial, pero te garantizo que las fotos que ves son 100% reales del [Producto]. Además, con el pago contraentrega, tú tienes el control: pagas hasta que llega. ¿Te parece justo?"
    },
    {
      title: "Confirmar con Foto",
      tag: "Alternativa",
      text: "No tengo un video a la mano en este momento, pero puedo confirmarte que el producto es exactamente como en las imágenes. Miles de clientes satisfechos lo respaldan. Si gustas, podemos procesar el pedido y así lo ves en persona sin haber pagado un centavo antes. ¿Qué opinas?"
    }
  ],
  "Seguimiento Fotos 📸": [
    {
      title: "¿Qué tal las fotos? 😃",
      tag: "Feedback",
      text: "¡Listo [Nombre]! 📸 Ahí te compartí las fotos. ¿Qué tal te parecieron? El [Producto] luce incluso mejor en persona."
    },
    {
      title: "Buscar Cierre 🔥",
      tag: "Cierre",
      text: "¿Verdad que está genial? 😍 Si te gustaron las fotos, confírmame para apartarte una unidad del [Producto] ahora mismo antes de que se agoten."
    },
    {
      title: "¿Alguna duda? 🤔",
      tag: "Soporte",
      text: "Espero que las fotos te ayuden a decidir, [Nombre]. 🧐 ¿Tienes alguna otra duda puntual sobre el producto o sus detalles que pueda resolverte?"
    }
  ],
  "Cierre 🚀": [
    {
      title: "Pedir Datos",
      tag: "Directo",
      text: "¡Excelente decisión [Nombre]! 🌟 Para preparar tu guía de envío ahora mismo, solo necesito: \n1. Nombre Completo\n2. Dirección Exacta (Calle, Nro, Ciudad)\n3. Teléfono\n\n¿Me podrías facilitar estos datos por favor?"
    },
    {
      title: "Doble Alternativa",
      tag: "Técnica",
      text: "¡Genial! Para el envío, ¿prefieres que lo mandemos a tu dirección de casa o a la de tu trabajo? 🏢🏠 Quedo atento para tomar nota."
    },
    {
      title: "Urgencia Stock",
      tag: "Push",
      text: "¡Ojo! Me acaba de notificar el sistema que quedan solo 2 unidades de este color. Si me pasas tus datos ya, alcanzo a reservarte una. ¿Te lo aparto?"
    }
  ],
  "Recuperación 👻": [
    {
      title: "¿Sigues ahí?",
      tag: "Suave",
      text: "Hola [Nombre], vi que te quedaste a un paso. 👋 ¿Tuviste alguna duda con el precio o el proceso de pago contraentrega? Cuéntame para ver si puedo ayudarte."
    },
    {
      title: "Urgencia Stock",
      tag: "FOMO",
      text: "Hola [Nombre], solo pasaba para avisarte que las unidades de esta promoción están volando 🚀. Me quedan solo 2 en stock. ¿Te gustaría que te guarde una antes de que se agoten definitivamente?"
    },
    {
      title: "Recordatorio Envío",
      tag: "Beneficio",
      text: "¿Todo bien? Recuerda que hoy tenemos ENVÍO GRATIS y pagas solo al recibir. 🚚 No dejes pasar la oportunidad de tener [Producto] al mejor precio. ¿Retomamos el pedido?"
    },
    {
      title: "Última Llamada",
      tag: "Cierre",
      text: "¿Sigues interesado en el [Producto]? 🤔 Estoy cerrando los despachos del día y me gustaría saber si incluyo el tuyo. Avísame para no perder tu turno."
    }
  ],
  "Post-Venta ✅": [
    {
      title: "Resumen Pedido",
      tag: "Confirmación",
      text: "✅ ¡Pedido Registrado! \n📦 Producto: [Producto]\n💰 Valor: [Precio] (Pago Contraentrega)\n🚚 Entrega: 12-18 días hábiles\n\nPor favor, mantente atento a tu teléfono para la confirmación de la transportadora. ¡Gracias por tu compra!"
    },
    {
      title: "Upsell Rápido",
      tag: "Venta Cruzada",
      text: "¡Tu pedido ya está en proceso! 🎉 Por cierto, muchos clientes que llevan [Producto] también aprovechan para llevar una segunda unidad con un 20% de descuento adicional ya que van en el mismo envío. ¿Te gustaría agregar uno a tu paquete?"
    }
  ],
  "Reclamos 😔": [
    {
      title: "Disculpa + Explicación",
      tag: "Empatía",
      text: "Lamento mucho que el [Producto] no haya cumplido tus expectativas, [Nombre]. 😔 Entiendo tu frustración. Como intermediarios, trabajamos con proveedores externos y a veces pueden ocurrir diferencias. ¿Podrías compartirme fotos del producto que recibiste para gestionar una solución contigo?"
    },
    {
      title: "Solución: Devolución",
      tag: "Resolución",
      text: "Entiendo perfectamente tu situación, [Nombre]. Aunque nosotros actuamos como intermediarios entre el proveedor y el cliente final, queremos que quedes satisfecho. Podemos gestionar la devolución del producto y el reembolso completo. ¿Te parece bien esta solución?"
    },
    {
      title: "Solución: Descuento",
      tag: "Compensación",
      text: "Lamento mucho lo sucedido, [Nombre]. 😔 Como gesto de buena voluntad y para compensar esta situación, puedo ofrecerte un descuento del 30% en tu próxima compra. Valoramos tu confianza y queremos seguir atendiéndote. ¿Qué opinas?"
    },
    {
      title: "Explicación Dropshipping",
      tag: "Transparencia",
      text: "Entiendo tu molestia, [Nombre]. Es importante que sepas que nosotros somos una plataforma de ventas que conecta clientes con proveedores especializados. No fabricamos ni almacenamos los productos directamente. Sin embargo, esto no te deja sin solución. ¿Qué te gustaría que hiciéramos para resolver esto?"
    },
    {
      title: "Reemplazo del Producto",
      tag: "Solución",
      text: "Lamento que el [Producto] no haya llegado como esperabas. 😔 Podemos gestionar con el proveedor el envío de un reemplazo sin costo adicional para ti. El nuevo producto saldría en los próximos días. ¿Te gustaría que procedamos con esta opción?"
    }
  ],
  "Herramientas 🛠️": [
    { type: 'mass_message', title: '📢 Difusión Masiva', text: '' },
    { type: 'search_dropi', title: '🔍 Buscar en Dropi', text: '' },
    { type: 'link', title: '🔗 Link de Pago', url: 'https://dropi.co/checkout' },
    { type: 'show_description_guide', title: '📋 Copiar Descripción', text: '' }
  ]
};

const VISIBLE_TABS = ["IA Copiloto 🧠", "Herramientas 🛠️"];
let activeCategory = VISIBLE_TABS[0]; // Default to first visible category
let productConfig = {
  name: localStorage.getItem('dropi_product_name') || '',
  price: localStorage.getItem('dropi_product_price') || '',
  clientName: 'Amigo/a'
};

// Exponer activeCategory y productConfig globalmente para que el modulo UI pueda leerlas si es necesario
// (Aunque el módulo UI lee window.CATEGORIES si lo exponemos)
window.CATEGORIES = CATEGORIES;
window.productConfig = productConfig;


let lastDetectedName = '';
let lastDetectedProduct = '';
let lastDetectedPrice = '';
let detectionTimeout;
let isDragging = false;
let isUIRendering = false;


async function createUI() {
  if (document.getElementById('dropi-responses-container') || isUIRendering) {
    return;
  }

  // ** INICIO: Comprobación de licencia **
  const licenseCheck = await getLicenseStatus();

  if (licenseCheck.status !== LICENSE_STATUS.VALID) {
    showLicenseNag(licenseCheck.message);
    return;
  }
  // ** FIN: Comprobación de licencia **


  isUIRendering = true;

  try {
    const container = document.createElement('div');
    container.id = 'dropi-responses-container';

    // 1. Header Moderno
    const header = document.createElement('div');
    header.id = 'dropi-header';
    header.innerHTML = `
      <div id="dropi-title">
        <img src="${chrome.runtime.getURL('icon_pro.png')}" style="height:20px; width:20px;"> 
        <span>RespondSsenger IA</span>
      </div>
      <div class="dropi-actions">
           <button class="dropi-icon-btn" id="dropi-minimize-btn" title="Minimizar">─</button>
      </div>
    `;

    // 2. Context Bar (Inputs modernos)
    const contextBar = document.createElement('div');
    contextBar.id = 'dropi-context-bar';
    contextBar.innerHTML = `
        <div class="dropi-context-item">
            <span class="dropi-context-label">Producto</span>
            <input type="text" id="dropi-product-input" class="dropi-context-input" placeholder="..." value="${productConfig.name}">
        </div>
        <div class="dropi-context-item">
            <span class="dropi-context-label">Precio</span>
            <input type="text" id="dropi-price-input" class="dropi-context-input" placeholder="$0" value="${productConfig.price}">
        </div>
        <div class="dropi-context-item">
            <span class="dropi-context-label">Cliente</span>
            <input type="text" id="dropi-client-input" class="dropi-context-input" placeholder="Nombre" value="${productConfig.clientName}">
        </div>
    `;

    // Listeners Context Bar
    const pInput = contextBar.querySelector('#dropi-product-input');
    const prInput = contextBar.querySelector('#dropi-price-input');
    const cInput = contextBar.querySelector('#dropi-client-input');

    // Evitar que el drag del header interfiera
    pInput.addEventListener('mousedown', (e) => e.stopPropagation());
    prInput.addEventListener('mousedown', (e) => e.stopPropagation());
    cInput.addEventListener('mousedown', (e) => e.stopPropagation());

    pInput.addEventListener('input', (e) => {
      productConfig.name = e.target.value;
      localStorage.setItem('dropi_product_name', e.target.value);
    });
    prInput.addEventListener('input', (e) => {
      productConfig.price = e.target.value;
      localStorage.setItem('dropi_product_price', e.target.value);
    });
    cInput.addEventListener('input', (e) => {
      productConfig.clientName = e.target.value;
    });

    // 3. Navigation (Tabs modernas)
    const nav = document.createElement('div');
    nav.id = 'dropi-nav';

    // Mapeo iconos/títulos cortos
    const icons = {
      "IA Copiloto 🧠": "✨ Copiloto AI",
      "Herramientas 🛠️": "🛠️ Tools"
    };

    VISIBLE_TABS.forEach(cat => {
      if (CATEGORIES[cat]) {
        const tab = document.createElement('div');
        tab.className = `dropi-nav-item ${cat === activeCategory ? 'active' : ''}`;
        tab.textContent = icons[cat] || cat;
        tab.onclick = () => switchTab(cat, tab);
        nav.appendChild(tab);
      }
    });

    // 4. Body
    const body = document.createElement('div');
    body.id = 'dropi-body';

    const content = document.createElement('div');
    content.id = 'dropi-content';

    body.appendChild(content);

    // Ensamblaje
    container.appendChild(header);
    container.appendChild(contextBar);
    container.appendChild(nav);
    container.appendChild(body);

    document.body.appendChild(container);

    renderResponses();

    // Make Draggable (Header only)
    let isDragging = false;
    let offsetX, offsetY;

    header.addEventListener('mousedown', (e) => {
      isDragging = true;
      offsetX = e.clientX - container.offsetLeft;
      offsetY = e.clientY - container.offsetTop;
      container.style.transition = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      let newLeft = e.clientX - offsetX;
      let newTop = e.clientY - offsetY;
      const maxX = window.innerWidth - container.offsetWidth;
      const maxY = window.innerHeight - container.offsetHeight;
      newLeft = Math.max(0, Math.min(newLeft, maxX));
      newTop = Math.max(0, Math.min(newTop, maxY));
      container.style.left = `${newLeft}px`;
      container.style.top = `${newTop}px`;
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        container.style.transition = 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)';
      }
    });

    // Minimize logic
    const minBtn = header.querySelector('#dropi-minimize-btn');
    if (minBtn) {
      minBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        container.classList.toggle('minimized');
        minBtn.textContent = container.classList.contains('minimized') ? '□' : '─';
      });
    }

  } finally {
    isUIRendering = false;
  }
}

function switchTab(category, tabElement) {
  activeCategory = category;
  document.querySelectorAll('.dropi-nav-item').forEach(t => t.classList.remove('active'));
  tabElement.classList.add('active');
  renderResponses();
}

function renderResponses() {
  // Prevent re-rendering if user is typing in API Key field
  if (document.activeElement && document.activeElement.id === 'dropi-ai-key-input') {
    return;
  }

  const content = document.getElementById('dropi-content');
  if (!content) return;
  content.innerHTML = '';

  const list = document.createElement('div');
  list.className = 'dropi-list';

  CATEGORIES[activeCategory].forEach(resp => {

    // --- LÓGICA ESPECIAL: DELEGADA AL MÓDULO UI ---
    if (resp.type === 'ai_panel') {
      const btn = document.createElement('div');
      btn.className = 'dropi-btn';
      // Ajustes visuales para el contenedor del panel
      btn.style.cursor = 'default';
      btn.style.padding = '0';
      btn.style.background = 'transparent';
      btn.style.border = 'none';

      // Llamada al módulo UI modularizado
      if (window.RespondAIUI) {
        window.RespondAIUI.render(btn, insertText, () => renderResponses());
      } else {
        btn.innerHTML = 'Error: Módulo RespondAIUI no cargado.';
      }

      list.appendChild(btn);

    } else if (resp.type === 'mass_message') {
      const btn = document.createElement('div');
      btn.className = 'dropi-btn';
      btn.innerHTML = `
        <div class="dropi-btn-header">
          <span class="dropi-btn-title" style="color: #FF5722;">${resp.title}</span>
          <span class="dropi-btn-tag" style="background: #ffebee; color: #FF5722;">AI</span>
        </div>
        <div class="dropi-btn-preview">Generar y enviar mensaje masivo con IA</div>
      `;
      btn.addEventListener('click', () => {
        if (window.MassSender && typeof window.MassSender.openUI === 'function') {
          window.MassSender.openUI();
        } else {
          // Fallback
          if (typeof sendMassMessage === 'function') {
            sendMassMessage();
          } else {
            alert('⚠️ Error: Módulo de Difusión Masiva (MassSender) no cargado.');
          }
        }
      });
      list.appendChild(btn);

    } else if (resp.type === 'show_description_guide') {
      const btn = document.createElement('div');
      btn.className = 'dropi-btn';
      btn.innerHTML = `
        <div class="dropi-btn-header">
          <span class="dropi-btn-title" style="color: #9C27B0;">${resp.title}</span>
          <span class="dropi-btn-tag" style="background: #f3e5f5; color: #9C27B0;">GUÍA</span>
        </div>
        <div class="dropi-btn-preview">Instrucciones para copiar descripción</div>
      `;
      btn.addEventListener('click', () => {
        alert(`📋 PASOS PARA COPIAR LA DESCRIPCIÓN:\n\n1️⃣ Click en "Más opciones"\n2️⃣ Click en "Ver detalles"\n3️⃣ Espera 5 segundos\n4️⃣ Click en "Ver más"\n5️⃣ Selecciona y copia la descripción completa\n6️⃣ Pégala en el chat con Ctrl+V\n\n💡 Tip: Agrega "¡Claro [Nombre]! Aquí está la info:" antes de pegar.`);
      });
      list.appendChild(btn);

    } else if (resp.type === 'search_dropi') {
      const btn = document.createElement('div');
      btn.className = 'dropi-btn';

      // Calcular término corto para visualización
      let displayTerm = productConfig.name || '...';
      const words = displayTerm.trim().split(/\s+/);
      if (words.length > 2) {
        displayTerm = words.slice(0, 2).join(' ');
      }

      btn.innerHTML = `
        <div class="dropi-btn-header">
          <span class="dropi-btn-title" style="color: #E91E63;">${resp.title}</span>
          <span class="dropi-btn-tag" style="background: rgba(233, 30, 99, 0.1); color: #E91E63;">CATÁLOGO</span>
        </div>
        <div class="dropi-btn-preview">Buscar "${displayTerm}" en Dropi</div>
      `;
      btn.addEventListener('click', () => {
        let term = productConfig.name;
        if (!term) {
          alert('⚠️ Por favor escribe o espera a que detectemos el nombre del producto.');
          return;
        }

        // Usar solo las 2 primeras palabras para mejor precisión
        const termWords = term.trim().split(/\s+/);
        if (termWords.length > 0) {
          term = termWords.slice(0, 2).join(' ');
        }

        const url = `https://app.dropi.co/dashboard/search?search=${encodeURIComponent(term)}&search_type=simple`;
        window.open(url, '_blank');
      });
      list.appendChild(btn);

    } else if (resp.type === 'link') {
      const btn = document.createElement('div');
      btn.className = 'dropi-btn';
      btn.innerHTML = `
        <div class="dropi-btn-header">
          <span class="dropi-btn-title" style="color: #333;">${resp.title}</span>
          <span class="dropi-btn-tag" style="background: #e6fffa; color: #009688;">LINK</span>
        </div>
        <div class="dropi-btn-preview">${resp.url}</div>
      `;
      btn.addEventListener('click', () => {
        window.open(resp.url, '_blank');
      });
      list.appendChild(btn);

    } else {
      // RESPUESTA NORMAL
      const btn = document.createElement('div');
      btn.className = 'dropi-btn';

      let previewText = resp.text;
      const pName = productConfig.name || '[Producto]';
      const pPrice = productConfig.price || '[Precio]';
      const cName = productConfig.clientName || '';

      previewText = previewText.replace(/\[Producto\]/g, pName);
      previewText = previewText.replace(/\[Precio\]/g, pPrice);
      previewText = previewText.replace(/\[Nombre\]/g, cName);
      previewText = previewText.replace(/  /g, ' ');

      btn.innerHTML = `
        <div class="dropi-btn-header">
          <span class="dropi-btn-title">${resp.title}</span>
          <span class="dropi-btn-tag">${resp.tag}</span>
        </div>
        <div class="dropi-btn-preview">${previewText}</div>
      `;

      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        insertText(resp.text);
      });
      list.appendChild(btn);
    }
  });

  content.appendChild(list);
}

// ... Funciones de inserción y detección ...

async function insertText(text) {
  // Comprobación de licencia
  const licenseCheck = await getLicenseStatus();
  if (licenseCheck.status !== LICENSE_STATUS.VALID) {
    showLicenseNag(licenseCheck.message);
    const container = document.getElementById('dropi-responses-container');
    if (container) container.remove();
    createUI();
    return;
  }

  let finalText = text;
  const pName = productConfig.name || '[PRODUCTO]';
  const pPrice = productConfig.price || '[PRECIO]';
  const cName = productConfig.clientName || '';
  const pOffer = '[PRECIO OFERTA]';

  finalText = finalText.replace(/\[Producto\]/gi, pName);
  finalText = finalText.replace(/\[Precio\]/gi, pPrice);
  finalText = finalText.replace(/\[Precio Oferta\]/gi, pOffer);

  if (cName) {
    finalText = finalText.replace(/\[Nombre\]/gi, cName);
  } else {
    finalText = finalText.replace(/\[Nombre\]/gi, '').replace(/  /g, ' ');
  }

  // Lógica de inserción robusta y SIN DUPLICADOS
  let activeElement = document.activeElement;

  // 1. Asegurar foco en el input de Messenger si no estamos en uno
  const isEditable = activeElement && (
    activeElement.isContentEditable ||
    activeElement.tagName === 'INPUT' ||
    activeElement.tagName === 'TEXTAREA' ||
    activeElement.getAttribute('role') === 'textbox'
  );

  if (!isEditable) {
    const messengerInput = document.querySelector('[role="textbox"][contenteditable="true"], [aria-label="Mensaje"], [aria-label="Message"]');
    if (messengerInput) {
      messengerInput.focus();
      activeElement = messengerInput;
    } else {
      alert('⚠️ Haz clic en el chat primero para saber dónde escribir.');
      return;
    }
  }

  // 2. Inserción según el tipo de elemento
  try {
    // ESTRATEGIA A: Inputs Estándar (Input/Textarea)
    if (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA') {
      const start = activeElement.selectionStart;
      const end = activeElement.selectionEnd;
      const val = activeElement.value;
      activeElement.value = val.slice(0, start) + finalText + val.slice(end);
      activeElement.selectionStart = activeElement.selectionEnd = start + finalText.length;
      activeElement.dispatchEvent(new Event('input', { bubbles: true }));
    }
    // ESTRATEGIA B: ContentEditable (Messenger Divs)
    else {
      // Intentamos execCommand. 
      // NOTA IMPORTANTE: No lanzamos error si devuelve false, porque a veces funciona igual
      // y lanzar error provocaría duplicación al entrar al fallback.
      const result = document.execCommand('insertText', false, finalText);

      // Si execCommand falla silenciosamente o no está soportado, podríamos intentar un fallback,
      // pero en Chrome/Messenger suele funcionar. Si realmente falla, el usuario puede pegar manualmente.
      // Evitamos entrar al catch para no duplicar.
    }

    // Decrementar uso
    await decrementUsage();

    // Actualizar UI contador
    const updatedLicense = await getLicenseStatus();
    if (updatedLicense.status === LICENSE_STATUS.VALID && updatedLicense.license.plan === 'basico') {
      const usesCounter = document.getElementById('uses-counter');
      if (usesCounter) {
        usesCounter.textContent = `Usos: ${updatedLicense.license.remainingUses}`;
      }
    }

  } catch (e) {
    console.error("Error en inserción automática:", e);
    // Solo si falla catastróficamente (excepción real), intentamos un último recurso
    try {
      const textNode = document.createTextNode(finalText);
      const selection = window.getSelection();
      if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        range.insertNode(textNode);
        range.collapse(false);
      }
    } catch (err2) {
      console.error("Fallo total de inserción", err2);
    }
  }
}

// ... Detección ...
function detectContext() {
  try {
    const specificSelectors = ['.x1dyh7pn', '.x1j85h84']; // Selectores comunes de FB
    for (const selector of specificSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        const text = el.innerText;
        if (!text || text.trim().length === 0) continue;

        if (text.includes(' · ') || text.includes(' - ')) {
          const separator = text.includes(' · ') ? ' · ' : ' - ';
          const parts = text.split(separator);
          if (parts.length >= 2) {
            const possibleName = parts[0].trim();
            const possibleProduct = parts[1].trim();
            if (possibleName && !possibleName.includes('$') && possibleName.length > 1 && possibleName.length < 30) {
              updateClientName(possibleName);
            }
            if (possibleProduct && !possibleProduct.includes('$') && possibleProduct.length > 2) {
              updateProductName(possibleProduct);
            }
          }
        }
        if (text.includes('$') || /^\$?\s*[\d,\.]+\s*$/.test(text.trim())) {
          updateProductPrice(text.trim());
        }
      }
    }
  } catch (e) { }
}

function updateClientName(name) {
  const cleanName = name.split(' ')[0];
  if (lastDetectedName !== cleanName && cleanName.length > 2) {
    lastDetectedName = cleanName;
    productConfig.clientName = cleanName;
    const input = document.getElementById('dropi-client-input');
    if (input && document.activeElement !== input) input.value = cleanName;
  }
}

function updateProductName(name) {
  const cleanName = name.replace(/Ver detalles|Marketplace/gi, '').trim();
  if (cleanName && lastDetectedProduct !== cleanName) {
    lastDetectedProduct = cleanName;
    productConfig.name = cleanName;
    localStorage.setItem('dropi_product_name', cleanName);
    const input = document.getElementById('dropi-product-input');
    if (input) input.value = cleanName;
  }
}

function updateProductPrice(price) {
  const cleanPrice = price.replace(/[^\d,\.\$]/g, '').trim();
  if (cleanPrice && lastDetectedPrice !== cleanPrice) {
    lastDetectedPrice = cleanPrice;
    productConfig.price = cleanPrice;
    localStorage.setItem('dropi_product_price', cleanPrice);
    const input = document.getElementById('dropi-price-input');
    if (input) input.value = cleanPrice;
  }
}


// Estado de la licencia
let isLicenseValid = false;

// Inicialización controlada
async function initExtension() {
  if (isLicenseValid) {
    createUI();
    return;
  }

  // Verificar licencia antes de crear UI
  if (typeof validateAndShowUI === 'function') {
    const valid = await validateAndShowUI();
    if (valid) {
      isLicenseValid = true;
      createUI();
    }
  } else {
    // Si no existe el manager (dev), cargar igual
    console.warn("license_manager.js no detectado.");
    createUI();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initExtension);
} else {
  initExtension();
}

// Observer para re-inyectar si Facebook borra el DOM
const observer = new MutationObserver((mutations) => {
  // Solo recrear si la licencia ya fue validada
  if (isLicenseValid && !document.getElementById('dropi-responses-container')) {
    createUI();
  }
  clearTimeout(detectionTimeout);
  detectionTimeout = setTimeout(() => {
    detectContext();
  }, 1000);
});

observer.observe(document.body, { childList: true, subtree: true });
