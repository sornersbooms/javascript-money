// ========================================
// CÓDIGO PARA AGREGAR AL FINAL DE content.js
// ========================================
// Copia todo este código y pégalo al FINAL del archivo content.js
// justo después de la línea: observer.observe(document.body, { childList: true, subtree: true });

// Variables para control de mensaje masivo
let massMessageRunning = false;
let massMessageStopped = false;

async function sendMassMessage() {
    if (massMessageRunning) {
        alert('⚠️ Ya hay un envío masivo en progreso.');
        return;
    }

    const message = prompt('📢 MENSAJE MASIVO\n\nEscribe el mensaje que quieres enviar a todos tus contactos de Marketplace:\n\n(Puedes usar [Nombre] para personalizar)');

    if (!message || message.trim() === '') {
        return;
    }

    const confirmSend = confirm(`¿Estás seguro de enviar este mensaje a TODOS tus contactos?\n\n"${message}"\n\n⚠️ Esta acción no se puede deshacer.`);

    if (!confirmSend) {
        return;
    }

    massMessageRunning = true;
    massMessageStopped = false;

    // Crear botón de detener
    const stopButton = document.createElement('div');
    stopButton.id = 'dropi-stop-mass-message';
    stopButton.innerHTML = '⏹️ DETENER ENVÍO MASIVO';
    stopButton.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #f44336;
    color: white;
    padding: 15px 25px;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
    z-index: 999999;
    box-shadow: 0 4px 12px rgba(244, 67, 54, 0.4);
    font-size: 14px;
  `;

    stopButton.addEventListener('click', () => {
        massMessageStopped = true;
        massMessageRunning = false;
        stopButton.remove();
        alert('✋ Envío masivo detenido.');
    });

    document.body.appendChild(stopButton);

    try {
        // Buscar todos los chats en la lista
        const chatSelectors = [
            'a[href*="/t/"]',
            '[role="link"][href*="/t/"]',
            'div[role="row"] a'
        ];

        let chatLinks = [];
        for (const selector of chatSelectors) {
            const links = Array.from(document.querySelectorAll(selector));
            if (links.length > 0) {
                chatLinks = links.filter(link => link.href && link.href.includes('/t/'));
                break;
            }
        }

        if (chatLinks.length === 0) {
            alert('⚠️ No se encontraron chats. Asegúrate de estar en la página principal de Messenger.');
            stopButton.remove();
            massMessageRunning = false;
            return;
        }

        alert(`📊 Se encontraron ${chatLinks.length} chats.\n\nEl envío comenzará en 3 segundos...`);
        await sleep(3000);

        let sentCount = 0;
        let errorCount = 0;

        for (let i = 0; i < chatLinks.length; i++) {
            if (massMessageStopped) {
                break;
            }

            try {
                // Click en el chat
                chatLinks[i].click();
                await sleep(2000);

                // Buscar el input del chat
                const messageInput = document.querySelector('[role="textbox"][contenteditable="true"], [aria-label="Mensaje"], [aria-label="Message"]');

                if (messageInput) {
                    // Personalizar mensaje si es posible
                    let personalizedMessage = message;

                    // Intentar obtener el nombre del contacto
                    const nameElement = chatLinks[i].querySelector('span');
                    if (nameElement && nameElement.innerText) {
                        const contactName = nameElement.innerText.split(' ')[0];
                        personalizedMessage = message.replace(/\[Nombre\]/g, contactName);
                    } else {
                        personalizedMessage = message.replace(/ \[Nombre\]/g, '').replace(/\[Nombre\]/g, '');
                    }

                    // Insertar texto
                    messageInput.focus();
                    document.execCommand('insertText', false, personalizedMessage);
                    await sleep(500);

                    // Buscar y hacer click en el botón de enviar
                    const sendButton = document.querySelector('[aria-label="Enviar"], [aria-label="Send"], [data-testid="send-button"]');
                    if (sendButton) {
                        sendButton.click();
                        sentCount++;

                        // Actualizar botón con progreso
                        stopButton.innerHTML = `⏹️ DETENER (${sentCount}/${chatLinks.length})`;
                    } else {
                        errorCount++;
                    }
                } else {
                    errorCount++;
                }

                // Esperar entre 3-5 segundos entre cada mensaje para evitar bloqueos
                const randomDelay = 3000 + Math.random() * 2000;
                await sleep(randomDelay);

            } catch (e) {
                errorCount++;
                console.error('Error enviando mensaje:', e);
            }
        }

        stopButton.remove();
        massMessageRunning = false;

        if (massMessageStopped) {
            alert(`⏹️ ENVÍO DETENIDO\n\n✅ Mensajes enviados: ${sentCount}\n❌ Errores: ${errorCount}`);
        } else {
            alert(`✅ ENVÍO COMPLETADO\n\n📨 Mensajes enviados: ${sentCount}\n❌ Errores: ${errorCount}\n\nTotal de chats: ${chatLinks.length}`);
        }

    } catch (error) {
        console.error('Error en envío masivo:', error);
        alert('❌ Ocurrió un error durante el envío masivo.');
        if (document.getElementById('dropi-stop-mass-message')) {
            document.getElementById('dropi-stop-mass-message').remove();
        }
        massMessageRunning = false;
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
