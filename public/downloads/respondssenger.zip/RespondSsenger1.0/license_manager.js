/**
 * @file license_manager.js
 * @description Gestión completa de licencias: validación, activación y UI.
 */

const LICENSE_API_URL = "https://script.google.com/macros/s/AKfycbx_v5_v-yS_1DE5p0a2e9QAN5k5oA8SRd-5s5v2o5dE8Fz83L_Wj2d_3L9nEXxS8s-G/exec";

const LICENSE_STATUS = {
    VALID: 'VALID',
    INVALID: 'INVALID',
    EXPIRED: 'EXPIRED',
    NO_LICENSE: 'NO_LICENSE'
};

/* --- UTILIDADES --- */

/**
 * Módulo de Rastreo Sofisticado
 * Combina datos de Background (API) con datos Locales (GPS)
 */
async function getPcInfo() {
    let finalData = {
        ip: 'Unknown',
        location: { lat: '', lon: '', error: '' }
    };

    console.log("📍 Iniciando rastreo modular...");

    // PASO 1: Solicitar al Background que busque la IP y GeoIP (Bypass CSP)
    // Esto evita bloqueos de Facebook a fetchs externos.
    const bgDataPromise = new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'getIpLocation' }, (response) => {
            if (chrome.runtime.lastError) {
                console.warn("Error contactando background:", chrome.runtime.lastError);
                resolve(null);
            } else {
                resolve(response);
            }
        });
    });

    // PASO 2: Intentar obtener GPS Local en paralelo
    const gpsPromise = new Promise((resolve) => {
        if (!navigator.geolocation) {
            resolve(null);
            return;
        }
        navigator.geolocation.getCurrentPosition(
            (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
            (err) => {
                console.warn("GPS Navegador denegado/falló:", err.message);
                resolve(null);
            },
            { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
        );
    });

    // Esperamos a ambos (Race condicionado, pero queremos ambos)
    const [bgResponse, gpsData] = await Promise.allSettled([bgDataPromise, gpsPromise]);

    // PROCESAR DATOS DE BACKGROUND (IP + Geo Aproximado)
    if (bgResponse.status === 'fulfilled' && bgResponse.value && bgResponse.value.success) {
        const d = bgResponse.value.data;
        if (d.ip) finalData.ip = d.ip;
        if (d.lat) finalData.location.lat = d.lat;
        if (d.lon) finalData.location.lon = d.lon;
        finalData.location.error = 'Approximate (IP Based)';
    }

    // PROCESAR DATOS GPS (Si existen, sobrescriben la ubicación aproximada)
    if (gpsData.status === 'fulfilled' && gpsData.value) {
        finalData.location.lat = gpsData.value.lat;
        finalData.location.lon = gpsData.value.lon;
        finalData.location.error = ''; // Exacta
        console.log("✅ GPS Exacto obtenido.");
    }

    console.log("📍 Rastreo finalizado:", finalData);
    return finalData;
}

function getDeviceId() {
    return new Promise((resolve) => {
        chrome.storage.local.get('userId', (data) => {
            if (data.userId) {
                resolve(data.userId);
            } else {
                const newId = 'user_' + Math.random().toString(36).substr(2, 9);
                chrome.storage.local.set({ userId: newId }, () => resolve(newId));
            }
        });
    });
}

function saveLicense(data) {
    return new Promise((resolve) => {
        chrome.storage.local.set({
            license: {
                status: 'VALID',
                plan: data.plan,
                expires: data.expires,
                key: data.key || 'TRIAL'
            }
        }, resolve);
    });
}

/* --- API CALLS --- */

function callLicenseAPI(payload) {
    return new Promise((resolve) => {
        // Determinar acción para background.js
        let actionBg = '';
        if (payload.action === 'register_trial') {
            actionBg = 'registerTrial';
        } else {
            actionBg = 'validateLicense';
        }

        chrome.runtime.sendMessage({
            action: actionBg,
            email: payload.email,
            whatsapp: payload.whatsapp,
            key: payload.licenseKey,
            userId: payload.userId,
            // Datos de rastreo
            ip: payload.ip,
            lat: payload.lat,
            lon: payload.lon,
            locError: payload.locError
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Runtime connectivity error:", chrome.runtime.lastError);
                resolve({ status: 'ERROR', message: 'Error interno de la extensión. Recarga la página.' });
                return;
            }

            if (response && response.success) {
                const data = response.data;
                console.log("Respuesta del Servidor:", data); // Log para programador

                // Normalización de mensaje para chequeo
                const msgLower = (data.message || '').toLowerCase();

                const isSuccess =
                    data.status === 'success' ||
                    data.result === 'success' ||
                    msgLower.includes('usuario nuevo') ||
                    msgLower.includes('activado') ||
                    msgLower.includes('bienvenido') ||
                    msgLower.includes('registrado') ||
                    msgLower.includes('éxito') ||
                    msgLower.includes('success');

                if (isSuccess) {
                    // Si el servidor no envía fecha de expiración, le damos 30 días por defecto (Trial)
                    const defaultExpires = new Date();
                    defaultExpires.setDate(defaultExpires.getDate() + 30);

                    resolve({
                        status: 'VALID',
                        plan: data.plan || 'pro', // Ante la duda, dale PRO
                        expires: data.expires || defaultExpires.toISOString(),
                        key: data.key || 'TRIAL-GENERATED-' + Date.now()
                    });
                } else {
                    // Solo si explícitamente falla
                    resolve({
                        status: 'INVALID',
                        message: data.message || 'Respuesta no reconocida del servidor.'
                    });
                }
            } else {
                resolve({
                    status: 'ERROR',
                    message: response?.error || 'Error de conexión con el servidor de licencias.'
                });
            }
        });
    });
}

/* --- LOGICA PRINCIPAL --- */

async function getLicenseStatus() {
    return new Promise((resolve) => {
        chrome.storage.local.get('license', async (data) => {
            const license = data.license;
            const now = new Date();

            if (!license) {
                resolve({ status: LICENSE_STATUS.NO_LICENSE });
                return;
            }

            const expires = new Date(license.expires);
            if (expires < now) {
                // Re-validar con servidor por si renovó
                const userId = await getDeviceId();
                const check = await callLicenseAPI({ action: 'check_status', userId });

                if (check && check.status === 'VALID') {
                    await saveLicense(check);
                    resolve({ status: LICENSE_STATUS.VALID, license: check });
                } else {
                    resolve({ status: LICENSE_STATUS.EXPIRED });
                }
            } else {
                resolve({ status: LICENSE_STATUS.VALID, license });
            }
        });
    });
}

async function validateAndShowUI() {
    const status = await getLicenseStatus();
    if (status.status !== LICENSE_STATUS.VALID) {
        showLicenseModal(status.status === LICENSE_STATUS.EXPIRED);
        return false;
    }
    return true;
}

/* --- INTERFAZ USUARIO (MODAL) --- */

function showLicenseModal(isExpired = false) {
    if (document.getElementById('dropi-license-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'dropi-license-modal';
    modal.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(15, 23, 42, 0.95); z-index: 2147483700;
        display: flex; justify-content: center; align-items: center;
        backdrop-filter: blur(10px); font-family: 'Segoe UI', sans-serif;
    `;

    const content = document.createElement('div');
    content.style.cssText = `
        width: 450px; background: #1e293b; border: 1px solid rgba(255,255,255,0.1);
        border-radius: 20px; padding: 30px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        color: white; text-align: center;
    `;

    const title = isExpired ? '⚠️ Tu Licencia ha Expirado' : '🚀 Bienvenido a RespondSsenger';
    const subtitle = isExpired ? 'Renueva para continuar vendiendo.' : 'Activa tu prueba gratis de 30 días o ingresa tu licencia.';

    content.innerHTML = `
        <img src="${chrome.runtime.getURL('icon_pro.png')}" style="width: 64px; margin-bottom: 20px;">
        <h2 style="margin: 0 0 10px 0; font-size: 24px; font-weight: 700; color: #ffffff !important;">${title}</h2>
        <p style="color: #94a3b8; margin-bottom: 30px; font-size: 14px;">${subtitle}</p>

        <div style="display: flex; gap: 10px; margin-bottom: 20px; justify-content: center;">
            <button id="tab-trial" class="lic-tab active" style="background: rgba(255,255,255,0.1); border: none; padding: 10px 20px; color: white; border-radius: 8px; cursor: pointer;">🎁 Prueba Gratis</button>
            <button id="tab-key" class="lic-tab" style="background: transparent; border: 1px solid rgba(255,255,255,0.1); padding: 10px 20px; color: #94a3b8; border-radius: 8px; cursor: pointer;">🔑 Tengo Licencia</button>
        </div>

        <!-- FORMULARIO TRIAL -->
        <div id="form-trial">
            <input type="email" id="lic-email" placeholder="Tu Correo Electrónico" style="width: 100%; padding: 12px; margin-bottom: 10px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: white; outline: none;">
            <input type="tel" id="lic-whatsapp" placeholder="Tu WhatsApp (con código país)" style="width: 100%; padding: 12px; margin-bottom: 20px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: white; outline: none;">
            <button id="btn-activate-trial" style="width: 100%; padding: 15px; background: #3b82f6; color: white; border: none; border-radius: 10px; font-weight: bold; cursor: pointer; font-size: 16px; transition: transform 0.1s;">
                Comenzar Prueba de 30 Días
            </button>
        </div>

        <!-- FORMULARIO KEY -->
        <div id="form-key" style="display: none;">
            <input type="text" id="lic-key" placeholder="Pega tu licencia aquí (ej: PRO-XYZA-1234)" style="width: 100%; padding: 12px; margin-bottom: 20px; border-radius: 8px; border: 1px solid #334155; background: #0f172a; color: white; outline: none; font-family: monospace; text-align: center;">
            <button id="btn-activate-key" style="width: 100%; padding: 15px; background: #22c55e; color: white; border: none; border-radius: 10px; font-weight: bold; cursor: pointer; font-size: 16px;">
                Validar Licencia
            </button>
        </div>

        <p id="lic-msg" style="margin-top: 15px; font-size: 13px; min-height: 20px; color: #ef4444;"></p>
    `;

    modal.appendChild(content);
    document.body.appendChild(modal);

    // Lógica UI
    const tabTrial = content.querySelector('#tab-trial');
    const tabKey = content.querySelector('#tab-key');
    const formTrial = content.querySelector('#form-trial');
    const formKey = content.querySelector('#form-key');
    const msg = content.querySelector('#lic-msg');

    tabTrial.onclick = () => {
        formTrial.style.display = 'block';
        formKey.style.display = 'none';
        tabTrial.style.background = 'rgba(255,255,255,0.1)';
        tabTrial.style.color = 'white';
        tabKey.style.background = 'transparent';
        tabKey.style.color = '#94a3b8';
    };

    tabKey.onclick = () => {
        formTrial.style.display = 'none';
        formKey.style.display = 'block';
        tabKey.style.background = 'rgba(255,255,255,0.1)';
        tabKey.style.color = 'white';
        tabTrial.style.background = 'transparent';
        tabTrial.style.color = '#94a3b8';
    };

    // ACTIVAR PRUEBA
    content.querySelector('#btn-activate-trial').onclick = async () => {
        const btn = content.querySelector('#btn-activate-trial');
        const email = content.querySelector('#lic-email').value;
        const whatsapp = content.querySelector('#lic-whatsapp').value;

        if (!email || !whatsapp) {
            msg.textContent = 'Por favor completa todos los campos.';
            return;
        }

        // VALIDACIÓN STRICTA: Debe tener '+' y números
        // El usuario pidió explícitamente obligar el +codigo
        const whatsappRegex = /^\+\d{7,}$/;
        if (!whatsappRegex.test(whatsapp)) {
            msg.textContent = '⚠️ El WhatsApp debe iniciar con "+" y el código de país (Ej: +57...)';
            msg.style.color = '#ef4444'; // Rojo error
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Obteniendo ubicación...';
        msg.textContent = 'Permite la ubicación si se solicita...';
        msg.style.color = '#94a3b8';

        try {
            // 1. Obtener Info PC (IP + Ubicación)
            const pcInfo = await getPcInfo();
            console.log("PC Info FINAL:", pcInfo);

            btn.textContent = 'Verificando...';

            // 2. Llamar API
            const userId = await getDeviceId();
            const response = await callLicenseAPI({
                action: 'register_trial',
                userId,
                email,
                whatsapp,
                ip: pcInfo.ip,
                lat: pcInfo.location.lat,
                lon: pcInfo.location.lon,
                locError: pcInfo.location.error // Enviar error si hubo
            });

            // Lógica SUPER ROBUSTA en frontend:
            // Si el status es VALID -> OK
            // O si el mensaje parece positivo (aunque status falle) -> OK
            const msgText = (response.message || '').toLowerCase();
            const isReallyValid =
                response.status === 'VALID' ||
                msgText.includes('usuario nuevo') ||
                msgText.includes('activado') ||
                msgText.includes('bienvenido');

            if (isReallyValid) {
                // Si forzamos la validez por mensaje, aseguramos guardar una licencia válida
                if (response.status !== 'VALID') {
                    response.status = 'VALID';
                    response.plan = 'pro';
                    response.expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
                    response.key = 'FORCED-TRIAL';
                }

                await saveLicense(response);
                msg.style.color = '#22c55e';
                msg.textContent = '¡Activado correctamente!';
                setTimeout(() => {
                    modal.remove();
                    location.reload(); // Recargar para activar features
                }, 1500);
            } else {
                msg.style.color = '#ef4444';
                msg.textContent = response.message || 'Error al activar prueba.';
                btn.disabled = false;
                btn.textContent = 'Comenzar Prueba de 30 Días';
            }
        } catch (e) {
            console.error(e);
            msg.textContent = 'Error de conexión o ubicación.';
            btn.disabled = false;
            btn.textContent = 'Reintentar';
        }
    };

    // ACTIVAR LICENCIA
    content.querySelector('#btn-activate-key').onclick = async () => {
        const btn = content.querySelector('#btn-activate-key');
        const key = content.querySelector('#lic-key').value.trim();

        if (!key) {
            msg.textContent = 'Ingresa una licencia válida.';
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Validando...';
        msg.textContent = '';

        try {
            const userId = await getDeviceId();
            const response = await callLicenseAPI({
                action: 'activate_license',
                userId,
                licenseKey: key
            });

            if (response.status === 'VALID') {
                await saveLicense({ ...response, key });
                msg.style.color = '#22c55e';
                msg.textContent = '¡Licencia PRO activada!';
                setTimeout(() => {
                    modal.remove();
                    location.reload();
                }, 1500);
            } else {
                msg.style.color = '#ef4444';
                msg.textContent = response.message || 'Licencia inválida o en uso.';
                btn.disabled = false;
                btn.textContent = 'Validar Licencia';
            }
        } catch (e) {
            msg.textContent = 'Error de conexión.';
            btn.disabled = false;
        }
    };
}
