document.addEventListener('DOMContentLoaded', () => {
    // URL del backend de licencias (reemplazada)
    const APP_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbyNtJAXO_QaYNM9_rEXU1-sEXGGsUUTqDThdTmR7bNTAgcLBlymNjH0Da3uxYdK6Z1aEw/exec';

    // Elementos del DOM
    const licenseForm = document.getElementById('license-form');
    const activateBtn = document.getElementById('activate-btn');
    const licenseInput = document.getElementById('license-key-input');
    const statusArea = document.getElementById('status-area');
    const licenseDetailsDiv = document.getElementById('license-details');
    const planNameEl = document.getElementById('plan-name');
    const daysLeftEl = document.getElementById('days-left');
    const usesLeftEl = document.getElementById('uses-left');

    // Al cargar, comprobar si ya hay una licencia válida guardada
    checkSavedLicense();

    // Event Listeners
    activateBtn.addEventListener('click', handleActivation);
    licenseInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') handleActivation();
    });

    /**
     * Gestiona el proceso de activación de la licencia.
     */
    async function handleActivation() {
        const licenseKey = licenseInput.value.trim();
        if (!licenseKey) {
            displayMessage('Por favor, introduce una clave de licencia.', 'error');
            return;
        }

        displayMessage('Activando, por favor espera...', 'info');
        activateBtn.disabled = true;

        try {
            const userId = await getUserId();
            const response = await fetch(APP_SCRIPT_URL, {
                method: 'POST',
                mode: 'cors',
                cache: 'no-cache',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ licenseKey, userId }),
                 redirect: 'follow'
            });
            
             if (!response.ok) {
                throw new Error(`Error de red: ${response.statusText}`);
            }

            // El backend de Apps Script puede hacer un redirect, necesitamos obtener la respuesta final
            const resultText = await response.text();
            const result = JSON.parse(resultText);


            if (result.status === 'VALID') {
                const licenseData = {
                    key: licenseKey,
                    plan: result.plan,
                    expires: result.expires,
                    remainingUses: result.remainingUses
                };
                chrome.storage.local.set({ license: licenseData }, () => {
                    displayMessage('¡Licencia activada! La página se recargará en 5 segundos...', 'success');
                    showLicenseDetails(licenseData);

                    // Recargar la pestaña activa de FB/Messenger después de 5 segundos
                    setTimeout(() => {
                        chrome.tabs.query({
                            active: true,
                            url: [
                                "https://www.facebook.com/*",
                                "https://www.messenger.com/*"
                            ]
                        }, (tabs) => {
                            if (tabs.length > 0) {
                                chrome.tabs.reload(tabs[0].id);
                            }
                        });
                    }, 5000); // 5000ms = 5 segundos
                });
            } else {
                throw new Error(result.message || 'Error desconocido al activar la licencia.');
            }
        } catch (error) {
            displayMessage(`Error: ${error.message}`, 'error');
        } finally {
            activateBtn.disabled = false;
        }
    }

    /**
     * Comprueba si hay una licencia guardada y si es válida.
     */
    function checkSavedLicense() {
        chrome.storage.local.get('license', (data) => {
            if (data.license) {
                const { expires } = data.license;
                const expirationDate = new Date(expires);
                if (expirationDate > new Date()) {
                    displayMessage('Licencia activa.', 'success');
                    showLicenseDetails(data.license);
                } else {
                    // La licencia ha expirado, la eliminamos
                    chrome.storage.local.remove('license');
                    showActivationForm('Tu licencia ha expirado. Por favor, activa una nueva.');
                }
            } else {
                showActivationForm('No hay una licencia activa.');
            }
        });
    }

    /**
     * Obtiene el ID único del usuario, creándolo si no existe.
     * @returns {Promise<string>} El ID de usuario.
     */
    function getUserId() {
        return new Promise((resolve) => {
            chrome.storage.local.get('userId', (data) => {
                let userId = data.userId;
                if (!userId) {
                    userId = 'user-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
                    chrome.storage.local.set({ userId: userId }, () => {
                        resolve(userId);
                    });
                } else {
                    resolve(userId);
                }
            });
        });
    }

    /**
     * Muestra los detalles de una licencia activa y oculta el formulario de activación.
     * @param {object} license - El objeto de la licencia.
     */
    function showLicenseDetails(license) {
        licenseForm.style.display = 'none';
        
        const expirationDate = new Date(license.expires);
        const today = new Date();
        const daysRemaining = Math.ceil((expirationDate - today) / (1000 * 60 * 60 * 24));

        planNameEl.textContent = license.plan;
        daysLeftEl.textContent = daysRemaining > 0 ? daysRemaining : '0';
        usesLeftEl.textContent = license.remainingUses === -1 ? 'Ilimitados' : license.remainingUses;
        
        licenseDetailsDiv.style.display = 'block';
    }

    /**
     * Muestra el formulario de activación y oculta los detalles de la licencia.
     * @param {string} message - Mensaje para mostrar en el área de estado.
     */
    function showActivationForm(message) {
        licenseDetailsDiv.style.display = 'none';
        licenseForm.style.display = 'block';
        displayMessage(message, 'info');
    }

    /**
     * Muestra un mensaje en el área de estado.
     * @param {string} message - El mensaje a mostrar.
     * @param {'info' | 'success' | 'error'} type - El tipo de mensaje.
     */
    function displayMessage(message, type = 'info') {
        statusArea.textContent = message;
        statusArea.className = `status-${type}`; // Clases CSS para estilizar
    }
});