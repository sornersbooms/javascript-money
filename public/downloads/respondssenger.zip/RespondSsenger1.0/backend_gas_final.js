// ==========================================
// BACKEND RESPONDSSENGER - FINAL PRO
// ==========================================

// ID DE LA HOJA DE CÁLCULO (Extraído de tu imagen/historial)
// Asegúrate de que este sea el correcto. Si cambias de hoja, actualízalo.
const SHEET_ID = "1wFK1ryroalixl7UagVkKqu0OJ-BuFGDHVqNqGqV3hbms";

// --- CONFIGURACIÓN TELEGRAM ---
const TELEGRAM_BOT_TOKEN = '8160444630:AAHEOxugi4Fr0zBeAgDpab90JW715GGySbg';
const TELEGRAM_CHAT_ID = '6432018838';

function sendTelegramNotification(text) {
    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) return;

    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    try {
        UrlFetchApp.fetch(url, {
            method: 'post',
            contentType: 'application/json',
            muteHttpExceptions: true,
            payload: JSON.stringify({
                chat_id: TELEGRAM_CHAT_ID,
                text: text,
                parse_mode: 'HTML'
            })
        });
    } catch (e) {
        console.error('Telegram Error: ' + e.toString());
    }
}

/**
 * Punto de entrada principal (POST)
 */
function doPost(e) {
    var output = ContentService.createTextOutput();
    output.setMimeType(ContentService.MimeType.JSON);

    var respuesta = {};

    try {
        // 1. Obtener parámetros (Soporte robusto JSON/Form)
        var params = {};
        if (e.postData && e.postData.contents) {
            try {
                params = JSON.parse(e.postData.contents);
            } catch (err) {
                params = e.parameter || {};
            }
        } else {
            params = e.parameter || {};
        }

        // Normalizar nombres de claves (La extensión envía 'key', tu script usa 'licenseKey', etc.)
        var action = params.action;
        var userId = params.userId;
        var licenseKey = params.key || params.licenseKey;
        var email = params.email;
        var whatsapp = params.whatsapp;

        // Datos de rastreo extra
        var ip = params.ip || 'N/A';
        var lat = params.lat || '';
        var lon = params.lon || '';
        var locError = params.locError || '';

        if (!userId) throw new Error("Falta el 'userId'.");

        // --- ENRUTAMIENTO INTELIGENTE ---
        // La extensión envía 'trial' o 'validate'. Tu lógica usa 'register_trial' o 'activate_license'.

        if (action === 'trial' || action === 'register_trial' || action === 'registerTrial') {
            // CASO 1: ACTIVAR PRUEBA
            if (!email || !whatsapp) throw new Error("Faltan datos de contacto.");
            respuesta = activarPruebaGratuita(userId, email, whatsapp, ip, lat, lon);

        } else if ((action === 'validate' || action === 'activate_license' || action === 'validateLicense') && licenseKey) {
            // CASO 2: ACTIVAR LICENCIA (Solo si viene key)
            respuesta = verificarYActivarLicencia(licenseKey, userId, ip, lat, lon);

        } else {
            // CASO 3: VERIFICAR ESTADO (Check status)
            // Si la acción es 'validate' pero no hay key, es un chequeo.
            respuesta = verificarEstadoUsuario(userId);
        }

    } catch (error) {
        respuesta = {
            status: 'ERROR',
            message: error.message
        };
        // Opcional: Notificar error grave a Telegram
        // sendTelegramNotification(`🚨 <b>Error Backend:</b> ${error.message}`);
    }

    output.setContent(JSON.stringify(respuesta));
    return output;
}

// --- FUNCIONES DE LÓGICA ---

function getSheet(name) {
    // Usar openById es más seguro para scripts standalone o Web App
    var ss = SpreadsheetApp.openById(SHEET_ID);
    var sheet = ss.getSheetByName(name);
    if (!sheet) sheet = ss.insertSheet(name);
    return sheet;
}

function verificarEstadoUsuario(userId) {
    const hoja = getSheet('usuarios');
    const datos = hoja.getDataRange().getValues();

    // Buscar de abajo hacia arriba (más reciente)
    for (let i = datos.length - 1; i >= 1; i--) {
        // Asumiendo Columna A = userId
        if (datos[i][0] == userId) {
            const fechaExpiracion = new Date(datos[i][4]);
            const hoy = new Date();

            if (fechaExpiracion > hoy) {
                return {
                    status: 'VALID',
                    message: 'Licencia activa',
                    plan: datos[i][2],
                    expires: fechaExpiracion.toISOString(),
                    type: datos[i][1] === 'TRIAL_Mw30' ? 'TRIAL' : 'PAID'
                };
            } else {
                return {
                    status: 'EXPIRED',
                    message: 'Tu licencia ha expirado.'
                };
            }
        }
    }

    return { status: 'NOT_FOUND', message: 'Usuario nuevo' };
}

function activarPruebaGratuita(userId, email, whatsapp, ip, lat, lon) {
    const hoja = getSheet('usuarios');
    const datos = hoja.getDataRange().getValues();

    // Validar duplicados
    for (let i = 1; i < datos.length; i++) {
        if (datos[i][0] == userId) {
            // Si ya existe, verificamos si está activo para no dar error feo
            return verificarEstadoUsuario(userId);
        }
        // Columna G = Email (índice 6), Columna H = Whatsapp (índice 7)
        // Asegurarse de que existan esas columnas antes de leer
        if (datos[i][6] && String(datos[i][6]).toLowerCase() == String(email).toLowerCase()) {
            return { status: 'ERROR', message: 'Este correo ya tiene una prueba registrada.' };
        }
    }

    const hoy = new Date();
    const fechaExpiracion = new Date();
    fechaExpiracion.setDate(hoy.getDate() + 30);

    // Generar Map Link
    let mapLink = "Ubicación desconocida";
    if (lat && lon) {
        mapLink = `https://www.google.com/maps?q=${lat},${lon}`;
    }

    // Guardar en 'usuarios'
    // A: ID, B: Tipo, C: Plan, D: Inicio, E: Fin, F: Usos, G: Email, H: Whatsapp, I: IP, J: MapLink
    hoja.appendRow([
        userId,
        'TRIAL_Mw30',
        'pro', // Damos PRO en el trial
        hoy,
        fechaExpiracion,
        -1,
        email,
        whatsapp,
        ip,
        mapLink
    ]);

    // --- CORRECCIÓN SOLICITADA: GUARDAR TAMBIÉN EN HOJA 'LICENCIAS' ---
    const hojaLicencias = getSheet('licencias');
    // Estructura Licencias: A: Key, B: Plan, C: Fecha Creacion, D: Activada Por, E: Expiracion, F: Email, G: Whatsapp
    const trialKey = 'TRIAL-' + Math.random().toString(36).substr(2, 6).toUpperCase();

    hojaLicencias.appendRow([
        trialKey,        // A: Licencia (Generada para trial)
        'pro',           // B: Plan
        hoy,             // C: Fecha Creacion
        userId,          // D: Activada por
        fechaExpiracion, // E: Expiracion
        email,           // F: Email (NUEVO)
        whatsapp         // G: Whatsapp (NUEVO)
        // Podríamos agregar IP aquí también si quisieras
    ]);
    // ------------------------------------------------------------------

    sendTelegramNotification(
        `🎁 <b>NUEVA PRUEBA (30 Días)</b>\n` +
        `👤 <b>User:</b> <code>${userId}</code>\n` +
        `📧 <b>Email:</b> ${email}\n` +
        `📱 <b>WhatsApp:</b> ${whatsapp}\n` +
        `🌐 <b>IP:</b> ${ip}\n` +
        `📍 <b>Ubicación:</b> ${mapLink}`
    );

    return {
        status: 'success', // Importante para frontend
        result: 'success',
        plan: 'pro',
        expires: fechaExpiracion.toISOString(),
        message: '¡Prueba activada correctamente!'
    };
}

function verificarYActivarLicencia(key, userId, ip, lat, lon) {
    const hojaLic = getSheet('licencias');
    const hojaUsu = getSheet('usuarios');

    const datosLic = hojaLic.getDataRange().getValues();
    let licenciaRow = -1;
    let licenciaData = null;

    // Buscar licencia en Columna A (índice 0)
    for (let i = 1; i < datosLic.length; i++) {
        if (datosLic[i][0] == key) {
            licenciaData = {
                plan: datosLic[i][1],       // Columna B
                fechaExp: datosLic[i][4],   // Columna E
                activadaPor: datosLic[i][3] // Columna D
            };
            licenciaRow = i + 1; // Fila real (1-based)
            break;
        }
    }

    if (!licenciaData) {
        return { status: 'ERROR', message: 'Licencia no encontrada.' };
    }

    if (licenciaData.activadaPor) {
        sendTelegramNotification(`⚠️ <b>Intento de Robo de Licencia</b>\nKey: ${key}\nLadrón?: ${userId}\nIP: ${ip}`);
        return { status: 'ERROR', message: 'Esta licencia ya fue usada por otro usuario.' };
    }

    // Parsear fecha flexible
    let fechaFin;
    try {
        fechaFin = new Date(licenciaData.fechaExp);
        if (isNaN(fechaFin.getTime())) throw new Error("Fecha inválida");
    } catch (e) {
        // Fallback si es string DD-MM-YYYY
        // Implementar parseo manual si necesario
        fechaFin = new Date();
        fechaFin.setDate(fechaFin.getDate() + 365);
    }

    // Actualizar hoja licencias (Marcar como usada)
    // Columna D es la 4
    hojaLic.getRange(licenciaRow, 4).setValue(userId);

    // Registrar en hoja usuarios (Nuevo periodo)
    const hoy = new Date();

    // Map Link
    let mapLink = "Ubicación desconocida";
    if (lat && lon) {
        mapLink = `https://www.google.com/maps?q=${lat},${lon}`;
    }

    hojaUsu.appendRow([
        userId,
        key,
        licenciaData.plan,
        hoy,
        fechaFin,
        -1,
        'UPGRADE',
        'UPGRADE',
        ip,
        mapLink
    ]);

    const fechaStr = Utilities.formatDate(fechaFin, Session.getScriptTimeZone(), "dd-MM-yyyy");

    sendTelegramNotification(
        `💰 <b>LICENCIA ACTIVADA</b>\n` +
        `🔑 <b>Key:</b> <code>${key}</code>\n` +
        `💎 <b>Plan:</b> ${licenciaData.plan}\n` +
        `👤 <b>User:</b> <code>${userId}</code>\n` +
        `📅 <b>Vence:</b> ${fechaStr}\n` +
        `🌐 <b>IP:</b> ${ip}\n` +
        `📍 <b>Ubicación:</b> ${mapLink}`
    );

    return {
        status: 'success',
        result: 'success',
        plan: licenciaData.plan,
        expires: fechaFin.toISOString(),
        message: '¡Licencia PRO activada!'
    };
}

function doGet(e) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'online', msg: 'RespondSsenger Server OK' })).setMimeType(ContentService.MimeType.JSON);
}
