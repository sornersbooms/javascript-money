// Variables para control de mensaje masivo
let massMessageRunning = false;
let massMessageStopped = false;

async function sendMassMessage(predefinedMessage = null) {
    // ** INICIO: Comprobación de licencia **
    const licenseCheck = await getLicenseStatus();
    if (licenseCheck.status !== LICENSE_STATUS.VALID) {
        showLicenseNag(licenseCheck.message);
        return;
    }
    // ** FIN: Comprobación de licencia **

    if (massMessageRunning) {
        alert('⚠️ Ya hay un envío masivo en progreso.');
        return;
    }

    let message = predefinedMessage;

    if (!message) {
        message = prompt('📢 MENSAJE MASIVO\n\nEscribe el mensaje que quieres enviar a todos tus contactos de Marketplace:\n\n(Puedes usar [Nombre] para personalizar)');
    }

    if (!message || message.trim() === '') {
        return;
    }

    const confirmSend = confirm(`¿Estás seguro de enviar este mensaje a TODOS tus contactos?\n\n"${message}"\n\n⚠️ Esta acción no se puede deshacer.`);

    if (!confirmSend) {
        return;
    }

    const confirmMarketplace = confirm('⚠️ IMPORTANTE: Para enviar mensajes solo a clientes de Marketplace, debes seleccionar la carpeta "Marketplace" en el menú de la izquierda de Messenger.\n\n¿Ya estás en la carpeta de Marketplace?');

    if (!confirmMarketplace) {
        alert('👉 Por favor, ve a la carpeta "Marketplace" y vuelve a intentarlo.');
        return;
    }

    massMessageRunning = true;
    massMessageStopped = false;

    // Crear botón de detener
    const stopButton = document.createElement('div');
    stopButton.id = 'dropi-stop-mass-message';
    stopButton.innerHTML = '⏹️ DETENER ENVÍO MASIVO';
    stopButton.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #f44336;
    color: white;
    padding: 15px 25px;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
    z-index: 999999;
    box-shadow: 0 4px 12px rgba(244, 67, 54, 0.4);
    font-size: 14px;
  `;

    stopButton.addEventListener('click', () => {
        massMessageStopped = true;
        massMessageRunning = false;
        stopButton.remove();
        alert('✋ Envío masivo detenido.');
    });

    document.body.appendChild(stopButton);

    try {
        // Buscar todos los chats en la lista
        // Buscar todos los chats en la lista (Selectores más específicos para la lista lateral)
        const chatSelectors = [
            'div[role="grid"] div[role="row"] a[href*="/t/"]', // Lista principal virtualizada
            'div[aria-label="Chats"] a[href*="/t/"]' // Contenedor explícito de chats
        ];

        let chatLinks = [];

        for (const selector of chatSelectors) {
            // Convertir a array y filtrar solo los visibles REALES usando getBoundingClientRect
            const links = Array.from(document.querySelectorAll(selector)).filter(el => {
                const rect = el.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0 && rect.top >= 0 && rect.left >= 0;
            });

            if (links.length > 0) {
                chatLinks = links;
                break;
            }
        }

        if (chatLinks.length === 0) {
            // Fallback a selectores más genéricos pero con chequeo estricto de visibilidad
            const potentialSidebars = document.querySelectorAll('div[class*="scroll"], div[class*="Scroll"]');
            for (const sidebar of potentialSidebars) {
                const links = Array.from(sidebar.querySelectorAll('a[href*="/t/"]')).filter(el => {
                    const rect = el.getBoundingClientRect();
                    return rect.width > 0 && rect.height > 0;
                });
                if (links.length > 5) {
                    chatLinks = links;
                    break;
                }
            }
        }

        if (chatLinks.length === 0) {
            alert('⚠️ No se encontraron chats visibles. Asegúrate de estar en la página principal de Messenger y que la lista de chats haya cargado.');
            stopButton.remove();
            massMessageRunning = false;
            return;
        }

        // Obtener nombres para previsualización
        const previewNames = chatLinks.slice(0, 5).map(link => {
            const nameEl = link.querySelector('span');
            return nameEl ? nameEl.innerText : 'Desconocido';
        }).join(', ');

        // RESALTAR CHATS ENCONTRADOS PARA VERIFICACIÓN VISUAL
        chatLinks.forEach(link => {
            link.style.border = "2px solid #f44336";
            link.style.backgroundColor = "rgba(244, 67, 54, 0.1)";
        });

        const confirmChats = confirm(`📊 He detectado ${chatLinks.length} chats VISIBLES.\n\nPrimeros contactos detectados:\n${previewNames}\n\n¿Son estos los contactos correctos de Marketplace?`);

        // Limpiar resaltado
        chatLinks.forEach(link => {
            link.style.border = "";
            link.style.backgroundColor = "";
        });

        if (!confirmChats) {
            stopButton.remove();
            massMessageRunning = false;
            return;
        }

        alert(`🚀 Iniciando envío a ${chatLinks.length} contactos...`);
        await sleep(1000);

        let sentCount = 0;
        let errorCount = 0;

        for (let i = 0; i < chatLinks.length; i++) {
            if (massMessageStopped) {
                break;
            }

            try {
                // Click en el chat
                chatLinks[i].click();
                await sleep(2000);

                // Buscar el input del chat
                const messageInput = document.querySelector('[role="textbox"][contenteditable="true"], [aria-label="Mensaje"], [aria-label="Message"]');

                if (messageInput) {
                    // Personalizar mensaje si es posible
                    let personalizedMessage = message;

                    // 1. Intentar obtener el nombre del contacto
                    const nameElement = chatLinks[i].querySelector('span');
                    if (nameElement && nameElement.innerText) {
                        const contactName = nameElement.innerText.split(' ')[0];
                        personalizedMessage = personalizedMessage.replace(/\[Nombre\]/g, contactName);
                    } else {
                        personalizedMessage = personalizedMessage.replace(/ \[Nombre\]/g, '').replace(/\[Nombre\]/g, '');
                    }

                    // 2. Intentar detectar el PRODUCTO del chat activo
                    let detectedProduct = "este artículo";
                    try {
                        const productSelectors = [
                            'div[aria-label="Detalles del artículo"] span',
                            'div[role="complementary"] h2',
                            'a[href*="/marketplace/item/"] span',
                            'div.x78zum5.xdt5ytf.x1iyjqo2.x1n2onr6 div.x1lliihq.x6ikm8r.x10wlt62.x1n2onr6.xlyipyv.xuxw1ft' // Contenedor de título común
                        ];

                        for (const sel of productSelectors) {
                            const foundEls = document.querySelectorAll(sel);
                            for (const el of foundEls) {
                                // Filtrar textos muy cortos o precios
                                const txt = el.innerText;
                                if (txt && txt.length > 4 && !txt.includes('$') && !txt.match(/^\d/)) {
                                    detectedProduct = txt.trim();
                                    break;
                                }
                            }
                            if (detectedProduct !== "este artículo") break;
                        }
                    } catch (e) {
                        console.log("No se pudo detectar producto auto", e);
                    }

                    personalizedMessage = personalizedMessage.replace(/\[Producto\]/g, detectedProduct);

                    // 3. Reemplazar [Precio] si existe en config global (difícil extraer por chat)
                    const globalPrice = window.productConfig?.price || '';
                    personalizedMessage = personalizedMessage.replace(/\[Precio\]/g, globalPrice);

                    // Insertar texto
                    messageInput.focus();
                    const success = document.execCommand('insertText', false, personalizedMessage);

                    // Disparar evento de input para que React detecte el cambio
                    messageInput.dispatchEvent(new Event('input', { bubbles: true }));
                    await sleep(1000);

                    // Intentar enviar
                    let sent = false;

                    // 1. Buscar botón de enviar (varios selectores)
                    const sendButton = document.querySelector('[aria-label="Enviar"], [aria-label="Send"], [data-testid="send-button"], svg[aria-label="Enviar"]');

                    if (sendButton) {
                        sendButton.click();
                        sent = true;
                    } else {
                        // 2. Si no hay botón, intentar con ENTER
                        console.log('Botón enviar no encontrado, intentando ENTER...');
                        const enterEvent = new KeyboardEvent('keydown', {
                            bubbles: true,
                            cancelable: true,
                            key: 'Enter',
                            code: 'Enter',
                            keyCode: 13,
                            which: 13
                        });
                        messageInput.dispatchEvent(enterEvent);
                        sent = true; // Asumimos que se envió
                    }

                    if (sent) {
                        sentCount++;
                        stopButton.innerHTML = `⏹️ DETENER (${sentCount}/${chatLinks.length})`;
                    } else {
                        errorCount++;
                    }

                    // Esperar entre 3-5 segundos entre cada mensaje para evitar bloqueos
                    const randomDelay = 3000 + Math.random() * 2000;
                    await sleep(randomDelay);

                } else {
                    errorCount++;
                }
            } catch (e) {
                errorCount++;
                console.error('Error enviando mensaje:', e);
            }
        }

        stopButton.remove();
        massMessageRunning = false;

        // Decrementar el uso de la licencia si la operación no fue detenida por el usuario
        if (!massMessageStopped) {
            await decrementUsage();
        }

        if (massMessageStopped) {
            alert(`⏹️ ENVÍO DETENIDO\n\n✅ Mensajes enviados: ${sentCount}\n❌ Errores: ${errorCount}`);
        } else {
            alert(`✅ ENVÍO COMPLETADO\n\n📨 Mensajes enviados: ${sentCount}\n❌ Errores: ${errorCount}\n\nTotal de chats: ${chatLinks.length}`);
        }

    } catch (error) {
        console.error('Error en envío masivo:', error);
        alert('❌ Ocurrió un error durante el envío masivo.');
        if (document.getElementById('dropi-stop-mass-message')) {
            document.getElementById('dropi-stop-mass-message').remove();
        }
        massMessageRunning = false;
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
