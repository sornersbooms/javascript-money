window.MassSender = {
    openUI: function () {
        // Eliminar modal previo si existe
        const existing = document.getElementById('mass-sender-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'mass-sender-modal';
        modal.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.7); z-index: 2147483650;
            display: flex; justify-content: center; align-items: center;
            backdrop-filter: blur(5px); animation: fadeIn 0.2s;
        `;

        const card = document.createElement('div');
        card.style.cssText = `
            width: 500px; max-width: 90%; background: #0f172a;
            border: 1px solid rgba(255,255,255,0.1); border-radius: 16px;
            padding: 24px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);
            display: flex; flex-direction: column; gap: 16px; position: relative;
        `;

        // Contenido del Modal
        card.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h3 style="margin: 0; color: #fff; display: flex; align-items: center; gap: 10px;">
                    📢 Difusión Masiva Inteligente
                </h3>
                <button id="close-mass-modal" style="background: none; border: none; color: #94a3b8; font-size: 24px; cursor: pointer;">&times;</button>
            </div>

            <p style="color: #94a3b8; font-size: 13px; margin: 0;">
                Genera un mensaje atractivo con IA para enviar a tus clientes de Marketplace.
            </p>

            <!-- Configuración Rápida -->
            <div style="display: flex; gap: 10px;">
                <select id="mass-tone" style="
                    flex: 1; 
                    padding: 12px; 
                    padding-right: 32px; 
                    background: #1e293b url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23FFFFFF%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E') no-repeat right 12px center; 
                    background-size: 10px; 
                    color: #fff; 
                    border: 1px solid rgba(255,255,255,0.2); 
                    border-radius: 8px; 
                    appearance: none; 
                    cursor: pointer; 
                    font-size: 14px;">
                    <option value="oferta" style="background: #1e293b; color: #fff;">🔥 Oferta Irresistible</option>
                    <option value="recuperar" style="background: #1e293b; color: #fff;">🔄 Recuperar Conversación</option>
                    <option value="seguimiento" style="background: #1e293b; color: #fff;">👋 Nuevo Seguimiento</option>
                    <option value="urgencia" style="background: #1e293b; color: #fff;">⏳ Últimas Unidades</option>
                    <option value="navidad" style="background: #1e293b; color: #fff;">🎄 Especial Festivo</option>
                </select>
            </div>

            <!-- Área de Generación -->
            <button id="mass-generate-btn" style="
                background: linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%);
                color: white; border: none; padding: 12px; border-radius: 10px;
                font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
                transition: transform 0.1s;
            ">
                ✨ Generar Mensaje con IA
            </button>

            <!-- Resultado -->
            <textarea id="mass-message-result" placeholder="El mensaje generado aparecerá aquí..." style="
                width: 100%; height: 150px; background: rgba(0,0,0,0.3);
                border: 1px solid rgba(255,255,255,0.1); border-radius: 12px;
                padding: 16px; color: #e2e8f0; font-family: sans-serif; resize: none;
                line-height: 1.5; font-size: 14px; outline: none; box-sizing: border-box;
            "></textarea>

            <div style="display: flex; gap: 10px; margin-top: 10px;">
                <button id="mass-send-btn" disabled style="
                    flex: 1; background: #22c55e; color: white; border: none; 
                    padding: 12px; border-radius: 10px; font-weight: bold; cursor: not-allowed; opacity: 0.5;
                    transition: all 0.2s;
                ">
                    🚀 Iniciar Envío Masivo
                </button>
            </div>
            
            <div style="font-size: 11px; color: #64748b; text-align: center; margin-top: 5px;">
                Se abrirá el selector de chats de la extensión clásica.
            </div>
        `;

        modal.appendChild(card);
        document.body.appendChild(modal);

        // Eventos
        modal.querySelector('#close-mass-modal').onclick = () => modal.remove();

        // Botón Enviar
        modal.querySelector('#mass-send-btn').onclick = () => {
            const msg = modal.querySelector('#mass-message-result').value;
            if (msg && msg.trim().length > 0) {
                modal.remove(); // Cerrar modal primero
                // Llamar a la función original de envío
                if (window.sendMassMessage) {
                    window.sendMassMessage(msg);
                } else {
                    alert('Error: El módulo de envío (mass_message.js) no está cargado.');
                }
            }
        };

        // Botón Generar
        modal.querySelector('#mass-generate-btn').onclick = async () => {
            const btn = modal.querySelector('#mass-generate-btn');
            const resultArea = modal.querySelector('#mass-message-result');
            const toneSelect = modal.querySelector('#mass-tone');
            const tone = toneSelect ? toneSelect.value : 'oferta';
            const sendBtn = modal.querySelector('#mass-send-btn');

            btn.disabled = true;
            btn.innerHTML = '⚡ Pensando...';
            btn.style.opacity = '0.7';

            // Preparar Prompt
            const product = window.productConfig?.name || '[Producto]';
            const price = window.productConfig?.price || '[Precio]';

            let prompt = `ACTÚA COMO UN EXPERTO EN MARKETING.
            
            OBJETIVO: Redactar un mensaje de difusión masiva (remarketing) para ventas, corto (máximo 2 frases), persuasivo y con emojis.
            
            🛑 REGLA DE ORO (GENÉRICO):
            - El mensaje debe servir para CUALQUIER producto.
            - NO menciones ningún producto específico.
            - NO uses el marcador [Producto].
            - REFIÉRETE al interés del cliente de forma abierta: "lo que buscabas", "tu pedido", "la oferta", "nuestros productos".
            - Usa OBLIGATORIAMENTE el marcador literal "[Nombre]" para personalizar el saludo.
            
            TONO ESPECÍFICO: `;

            if (tone === 'oferta') prompt += "Oferta irresistible. Ejemplo: 'Tenemos descuentos en todo lo que te gustó'.";
            if (tone === 'urgencia') prompt += "Escasez. Ejemplo: 'Quedan pocas unidades de lo que preguntaste'.";
            if (tone === 'seguimiento') prompt += "Amable. Ejemplo: '¿Aún sigues interesado en completar tu compra?'.";
            if (tone === 'recuperar') prompt += "Reactivación muy suave. Ejemplo: 'Hola, ¿sigues buscando algo especial?'.";
            if (tone === 'navidad') prompt += "Festivo/Navideño genérico. Ejemplo: 'Regala lo mejor esta Navidad'.";

            prompt += `
            
            EJEMPLO DE SALIDA PERFECTA:
            "Hola [Nombre] 👋, ¿aún te interesa lo que preguntaste? Hoy tenemos envío gratis en todo. 🚀"`;

            // Llamar a IA
            if (window.RespondAI && window.RespondAI.generateSalesResponse) {
                // TRUCO: Enviamos una configuración "falsa" donde el nombre del cliente ES la plantilla.
                // Así la IA usará "[Nombre]" creyendo que es el nombre real o siguiendo la instrucción.
                const templateConfig = {
                    name: '[Producto]',
                    price: '[Precio]',
                    clientName: '[Nombre]'
                };

                // Pasamos templateConfig en lugar de window.productConfig
                const resp = await window.RespondAI.generateSalesResponse(prompt, templateConfig, {}, []);

                if (resp.success) {
                    resultArea.value = resp.text;
                    sendBtn.disabled = false;
                    sendBtn.style.cursor = 'pointer';
                    sendBtn.style.opacity = '1';
                } else {
                    resultArea.value = "Error al generar: " + resp.error;
                }
            } else {
                resultArea.value = "Error: Módulo de IA no disponible.";
            }

            btn.disabled = false;
            btn.innerHTML = '✨ Generar Mensaje con IA';
            btn.style.opacity = '1';
        };
    }
};
