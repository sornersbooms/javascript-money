// modules/ai_manager.js
// Logica de Inteligencia Artificial con Groq

const AI_STORAGE_KEY = 'dropi_groq_key';

window.RespondAI = {
    getApiKey: () => {
        return new Promise((resolve) => {
            chrome.storage.local.get([AI_STORAGE_KEY], (res) => {
                resolve(res[AI_STORAGE_KEY] || '');
            });
        });
    },

    setApiKey: (key) => {
        return new Promise((resolve) => {
            chrome.storage.local.set({ [AI_STORAGE_KEY]: key.trim() }, () => {
                resolve(key.trim());
            });
        });
    },

    // Convierte las Respuestas Rápidas en Contexto para la IA
    buildContextFromCategories: (categories) => {
        let text = "BASE DE CONOCIMIENTO Y RESPUESTAS PRE-APROBADAS:\n";
        for (const [catName, responses] of Object.entries(categories)) {
            if (catName.includes('Herramientas')) continue; // Ignorar herramientas
            text += `\nCATEGORÍA: ${catName}\n`;
            responses.forEach(r => {
                text += `- Si preguntan sobre "${r.title}": ${r.text}\n`;
            });
        }
        return text;
    },

    generateSalesResponse: async (lastMessage, productInfo, baseKnowledge, chatHistory = []) => {
        const apiKey = await window.RespondAI.getApiKey();
        if (!apiKey) return { success: false, error: 'Falta API Key' };

        // Formatear historial
        const historyText = chatHistory.map(msg => `-${msg.role === 'user' ? 'Cliente' : 'Vendedor'}: "${msg.content}"`).join('\n');

        const systemPrompt = `
ERES UN EXPERTO VENDEDOR DE MARKETPLACE.
Tu Misión: Cerrar la venta del producto "${productInfo.name || 'este producto'}" (${productInfo.price || 'precio al DM'}).
Cliente: "${productInfo.clientName || 'Amigo/a'}".

HISTORIAL DE CHAT RECIENTE (Últimos 10 mensajes):
${historyText || '(No hay historial previo detectado)'}

TUS REGLAS DE ORO:
1. Responde de forma CORTA (máximo 2-3 frases).
2. Sé AMIGABLE y PERSUASIVO. Usa emojis (1 o 2).
3. TERMINA SIEMPRE CON UNA PREGUNTA para mantener la conversación viva.
4. BASÁTE EN TU BASE DE CONOCIMIENTO (abajo) para responder dudas técnicas o de envío.
5. Si no sabes algo, prioriza pedir los datos para el envío o invitar a la compra.
6. NO parezcas un robot. Habla natural.
7. Ten en cuenta el contexto del historial para no repetir preguntas o información ya dada.

BASE DE CONOCIMIENTO:
${baseKnowledge}
        `.trim();

        const messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `El cliente dice (o el contexto actual es): "${lastMessage}". ¿Qué respondo?` }
        ];

        return new Promise((resolve) => {
            chrome.runtime.sendMessage({
                action: 'generateChatCompletion',
                apiKey: apiKey,
                messages: messages
            }, response => {
                if (chrome.runtime.lastError) {
                    resolve({ success: false, error: chrome.runtime.lastError.message });
                } else {
                    resolve(response);
                }
            });
        });
    }
};
