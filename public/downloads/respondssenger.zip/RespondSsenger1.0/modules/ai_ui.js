window.RespondAIUI = {
    /**
     * Renderiza el panel de IA dentro del contenedor dado.
     * Maneja tanto el estado de configuración (sin API Key) como el estado activo.
     */
    render: function (container, onInsertText, onRefresh) {
        if (!container) return;

        // Limpiar contenedor previo
        container.innerHTML = '<div style="padding: 20px; text-align: center; color: rgba(255,255,255,0.5); font-size: 14px;">Cargando IA... ⏳</div>';

        // Obtener estado de la API Key (Asíncrono)
        if (window.RespondAI && window.RespondAI.getApiKey) {
            window.RespondAI.getApiKey().then(apiKey => {
                container.innerHTML = ''; // Limpiar spinner

                if (!apiKey) {
                    this.renderConfigMode(container, onRefresh);
                } else {
                    this.renderActiveMode(container, onInsertText, onRefresh);
                }
            });
        } else {
            container.innerHTML = '<div style="padding: 10px; color: #ef4444;">Error: Módulo de IA no cargado.</div>';
        }
    },

    /**
     * Renderiza el formulario de configuración cuando no hay API Key.
     */
    renderConfigMode: function (container, onRefresh) {
        const configPanel = document.createElement('div');
        // Estilo moderno, oscuro y sin padding extra
        configPanel.style.cssText = 'display: flex; flex-direction: column; gap: 16px; padding: 4px;';

        configPanel.innerHTML = `
            <div style="background: rgba(30, 41, 59, 0.4); padding: 16px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.05); text-align: center;">
                <div style="font-size: 32px; margin-bottom: 8px;">🤖</div>
                <h3 style="margin: 0 0 6px 0; color: #fff; font-size: 15px; font-weight: 600;">Configurar Copiloto</h3>
                <p style="margin: 0; color: #94a3b8; font-size: 12px; line-height: 1.4;">Ingresa tu API Key de Groq para activar la inteligencia artificial.</p>
            </div>
            
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="position: relative;">
                    <input type="password" id="dropi-ai-key-input" placeholder="gsk_..." 
                        style="width: 100%; padding: 12px; background: rgba(0, 0, 0, 0.3); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; color: #fff; font-family: monospace; font-size: 13px; outline: none; box-sizing: border-box; transition: all 0.2s;">
                </div>
                
                <button id="dropi-save-key-btn" 
                        style="width: 100%; padding: 12px; background: #6366f1; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 14px; transition: all 0.2s; box-shadow: 0 4px 6px -1px rgba(99, 102, 241, 0.2);">
                        Activar IA
                </button>
            </div>
            
            <a href="https://console.groq.com/keys" target="_blank" style="color: #6366f1; font-size: 11px; text-align: center; text-decoration: none; opacity: 0.8; display: block; margin-top: 4px;">
                ¿No tienes Key? Consíguela Gratis ↗
            </a>
        `;

        // Evitar propagación
        configPanel.addEventListener('mousedown', (e) => e.stopPropagation());
        configPanel.addEventListener('click', (e) => e.stopPropagation());

        container.appendChild(configPanel);

        // Lógica del formulario
        setTimeout(() => {
            const saveBtn = document.getElementById('dropi-save-key-btn');
            const input = document.getElementById('dropi-ai-key-input');

            if (saveBtn && input) {
                // Efecto focus
                input.addEventListener('focus', () => {
                    input.style.borderColor = '#6366f1';
                    input.style.background = 'rgba(0, 0, 0, 0.5)';
                });
                input.addEventListener('blur', () => {
                    input.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                    input.style.background = 'rgba(0, 0, 0, 0.3)';
                });
                input.addEventListener('keydown', (e) => e.stopPropagation()); // Permitir escribir sin conflictos

                saveBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const key = input.value.trim();

                    if (key.startsWith('gsk_')) {
                        saveBtn.textContent = 'Verificando...';
                        saveBtn.style.opacity = '0.7';

                        window.RespondAI.setApiKey(key).then(() => {
                            saveBtn.textContent = '¡Verificado!';
                            saveBtn.style.background = '#22c55e'; // Green

                            setTimeout(() => {
                                if (onRefresh && typeof onRefresh === 'function') {
                                    onRefresh(); // Limpieza total
                                } else {
                                    container.innerHTML = '';
                                    this.renderActiveMode(container, onInsertText, onRefresh);
                                }
                            }, 600);
                        });
                    } else {
                        alert('⚠️ La Key debe comenzar con "gsk_"');
                        input.focus();
                    }
                });
            }
        }, 100);
    },

    /**
     * Renderiza el panel activo cuando ya hay API Key.
     */
    renderActiveMode: function (container, onInsertText, onRefresh) {
        // Contenedor principal del panel activo
        const activePanel = document.createElement('div');
        activePanel.style.cssText = 'display: flex; flex-direction: column; gap: 12px; height: 100%;';

        const lastText = window.lastAIGeneratedText || '';

        activePanel.innerHTML = `
            <!-- Prompt Area -->
            <div style="position: relative; flex-shrink: 0;">
                <textarea id="dropi-ai-prompt" placeholder="Escribe una instrucción para la IA (Opcional)..." 
                    style="width: 100%; height: 80px; padding: 12px; 
                           background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); 
                           border-radius: 12px; color: #e2e8f0; font-family: inherit; font-size: 13px; 
                           resize: none; outline: none; display: block; box-sizing: border-box; transition: all 0.2s;"></textarea>
                
                <button id="dropi-ai-reset-key" title="Configuración"
                        style="position: absolute; bottom: 8px; right: 8px; font-size: 12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #94a3b8; cursor: pointer; padding: 4px 8px; border-radius: 6px; transition: all 0.2s;">
                    ⚙️
                </button>
            </div>

            <!-- Generate Button -->
            <button id="dropi-ai-generate-btn" 
                    style="width: 100%; background: linear-gradient(135deg, #6366f1 0%, #818cf8 100%); 
                           box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
                           color: white; border: none; padding: 12px; border-radius: 10px; 
                           cursor: pointer; font-weight: 600; font-size: 14px; 
                           display: flex; align-items: center; justify-content: center; gap: 8px; 
                           transition: transform 0.2s; flex-shrink: 0;">
                <span>✨</span> Generar Respuesta
            </button>

            <!-- Result Area (Scrollable) -->
            <div id="dropi-ai-result-container" style="display: ${lastText ? 'flex' : 'none'}; flex: 1; min-height: 0; flex-direction: column; gap: 8px;">
                <div id="dropi-ai-result" 
                     style="padding: 16px; background: rgba(30, 41, 59, 0.6); border: 1px solid rgba(255,255,255,0.1); 
                            border-radius: 12px; font-size: 13px; line-height: 1.5; color: #e2e8f0; 
                            cursor: pointer; position: relative; animation: fadeIn 0.3s ease; white-space: pre-wrap; overflow-y: auto;">
                    ${lastText}
                </div>
                <div id="dropi-ai-action-label" 
                     style="font-size: 11px; color: #64ffda; text-align: center; font-weight: bold; cursor: pointer; border: 1px dashed rgba(100, 255, 218, 0.3); padding: 6px; border-radius: 6px; background: rgba(100, 255, 218, 0.05); transition: all 0.2s;">
                    ⬇️ Clic aquí para insertar en chat
                </div>
            </div>
        `;

        // Events bubble propagation prevention
        activePanel.addEventListener('mousedown', (e) => e.stopPropagation());
        activePanel.addEventListener('click', (e) => e.stopPropagation());

        container.appendChild(activePanel);

        setTimeout(() => {
            // Textarea focus effects
            const promptInput = document.getElementById('dropi-ai-prompt');
            if (promptInput) {
                promptInput.addEventListener('focus', () => {
                    promptInput.style.borderColor = '#6366f1';
                    promptInput.style.background = 'rgba(0,0,0,0.5)';
                });
                promptInput.addEventListener('blur', () => {
                    promptInput.style.borderColor = 'rgba(255,255,255,0.1)';
                    promptInput.style.background = 'rgba(0,0,0,0.3)';
                });
                promptInput.addEventListener('keydown', (e) => e.stopPropagation());
            }

            // Reset Key Logic
            const resetBtn = document.getElementById('dropi-ai-reset-key');
            if (resetBtn) {
                resetBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (confirm('¿Eliminar API Key guardada?')) {
                        window.RespondAI.setApiKey('').then(() => {
                            window.lastAIGeneratedText = '';
                            if (onRefresh && typeof onRefresh === 'function') {
                                onRefresh();
                            } else {
                                container.innerHTML = '';
                                this.renderConfigMode(container, onRefresh);
                            }
                        });
                    }
                });
            }

            // Generate Logic
            const genBtn = document.getElementById('dropi-ai-generate-btn');
            if (genBtn) {
                genBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const resultContainer = document.getElementById('dropi-ai-result-container');
                    const resultDiv = document.getElementById('dropi-ai-result');
                    const prompt = promptInput ? promptInput.value.trim() : '';

                    genBtn.innerHTML = '<span class="spin">⚡</span> Pensando...';
                    genBtn.disabled = true;
                    genBtn.style.opacity = '0.7';
                    genBtn.style.cursor = 'wait';

                    // Context gathering
                    const productInfo = window.productConfig || { name: '', price: '', clientName: '' };
                    const categories = window.CATEGORIES || {};
                    const knowledge = window.RespondAI.buildContextFromCategories(categories);
                    let chatHistory = [];
                    if (window.MessageScanner) {
                        try { chatHistory = window.MessageScanner.getMessengerHistory(); } catch (err) { }
                    }

                    // Call AI
                    const response = await window.RespondAI.generateSalesResponse(
                        prompt || "Genera la mejor respuesta posible basada en el contexto.",
                        productInfo,
                        knowledge,
                        chatHistory
                    );

                    genBtn.innerHTML = '<span>✨</span> Generar Respuesta';
                    genBtn.disabled = false;
                    genBtn.style.opacity = '1';
                    genBtn.style.cursor = 'pointer';

                    if (response.success) {
                        window.lastAIGeneratedText = response.text;
                        if (resultDiv && resultContainer) {
                            resultDiv.textContent = response.text;
                            resultContainer.style.display = 'flex';

                            // Unified Insert Handler with Debounce
                            let isInserting = false;
                            const handleInsert = (ev) => {
                                ev.stopPropagation();
                                if (isInserting) return;
                                isInserting = true;

                                if (typeof onInsertText === 'function') {
                                    onInsertText(response.text);
                                }

                                // Visual feedback
                                resultDiv.style.borderColor = '#22c55e';
                                const label = document.getElementById('dropi-ai-action-label');
                                if (label) {
                                    const originalText = label.textContent;
                                    label.textContent = '✅ Insertado';
                                    label.style.borderColor = '#22c55e';
                                    label.style.color = '#22c55e';
                                    label.style.background = 'rgba(34, 197, 94, 0.1)';

                                    setTimeout(() => {
                                        resultDiv.style.borderColor = 'rgba(255,255,255,0.1)';
                                        label.textContent = '⬇️ Clic aquí para insertar en chat';
                                        label.style.borderColor = 'rgba(100, 255, 218, 0.3)';
                                        label.style.color = '#64ffda';
                                        label.style.background = 'rgba(100, 255, 218, 0.05)';
                                        isInserting = false; // Reset lock
                                    }, 1500);
                                } else {
                                    setTimeout(() => {
                                        resultDiv.style.borderColor = 'rgba(255,255,255,0.1)';
                                        isInserting = false;
                                    }, 1500);
                                }
                            };

                            // Attach to both result bubble and action label
                            resultDiv.onclick = handleInsert;
                            const actionLabel = document.getElementById('dropi-ai-action-label');
                            if (actionLabel) {
                                actionLabel.onclick = handleInsert;
                            }
                        }
                    } else {
                        alert('Error: ' + response.error);
                    }
                });
            }
        }, 100);
    }
};
