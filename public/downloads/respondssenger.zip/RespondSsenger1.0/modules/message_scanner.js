// modules/message_scanner.js
// Lógica de escaneo de mensajes en Messenger (Inspirado en Textea IA)

window.MessageScanner = {
    getMessengerHistory: () => {
        // Selector principal del área de chat
        const chatArea = document.querySelector('div[role="main"]');
        if (!chatArea) return [];

        try {
            const chatRect = chatArea.getBoundingClientRect();

            // Buscamos cajas de texto y emojis
            // Estos selectores capturan burbujas de texto y emojis grandes
            const elements = Array.from(chatArea.querySelectorAll('div[dir="auto"], img[alt]'))
                .filter(el => {
                    // Filtrar elementos irrelevantes
                    if (el.tagName === 'IMG') {
                        const alt = el.alt || "";
                        // Ignorar fotos de perfil o iconos pequeños detectados por tamaño
                        const isProfilePic = alt.toLowerCase().includes('perfil') || alt.toLowerCase().includes('profile');
                        const isIcon = el.width < 15 || el.height < 15;
                        // Solo queremos emojis que sean parte del mensaje
                        return alt.length > 0 && !isProfilePic && !isIcon;
                    }

                    const txt = el.textContent?.trim() || "";
                    // Filtrar textos de sistema o interfaz
                    const ignored = ['Aa', 'Multimedia', 'Archivos', 'Privacidad y ayuda', 'Visto', 'Entregado', 'Sent', 'Delivered', 'Seen'];
                    return txt.length > 0 && !ignored.includes(txt);
                });

            // Mapeamos a objetos con posición para ordenar cronológicamente
            const rawMsgs = elements.map(el => {
                const rect = el.getBoundingClientRect();

                // Determinamos si es mensaje del CLIENTE (Izquierda) o NUESTRO (Derecha)
                // Umbral: Si está en el 35% izquierdo de la pantalla, es cliente.
                const isOnLeft = (rect.left - chatRect.left) < (chatRect.width * 0.45);

                // Refinamiento: Las burbujas grises son del cliente en Messenger clásico
                const isGray = window.getComputedStyle(el.parentElement || el).backgroundColor === 'rgb(240, 242, 245)'; // #f0f2f5

                // Lógica combinada: Posición + Color (si aplica)
                const isClient = isOnLeft;

                let content = el.tagName === 'IMG' ? el.alt : (el.textContent?.trim() || "");

                return {
                    role: isClient ? 'user' : 'assistant', // user = cliente, assistant = vendedor
                    content: content,
                    top: rect.top
                };
            });

            // Ordenar por posición vertical (de arriba a abajo)
            // Eliminamos duplicados muy cercanos (mismo mensaje detectado múltiples veces)
            const sorted = rawMsgs.sort((a, b) => a.top - b.top);

            const uniqueMsgs = [];
            let lastTop = -9999;
            let lastContent = "";

            for (const msg of sorted) {
                // Si está muy cerca verticalmente y tiene el mismo texto, es duplicado del renderizado
                const isDuplicate = Math.abs(msg.top - lastTop) < 10 && msg.content === lastContent;

                if (!isDuplicate) {
                    uniqueMsgs.push({ role: msg.role, content: msg.content });
                    lastTop = msg.top;
                    lastContent = msg.content;
                }
            }

            // Devolvemos los últimos 10 mensajes
            return uniqueMsgs.slice(-10);

        } catch (e) {
            console.error("[MessageScanner] Error:", e);
            return [];
        }
    }
};
