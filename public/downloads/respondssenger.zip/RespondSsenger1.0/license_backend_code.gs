// -------------------------------------------------------------------------------
// CONFIGURACIÓN DE LA HOJA DE CÁLCULO
// -------------------------------------------------------------------------------
// 1. Hoja "licencias":
//    A1: Licencia, B1: Plan, C1: Fecha de Creacion, D1: Activada por (ID de Usuario), E1: Fecha de Expiracion
// 2. Hoja "usuarios":
//    A1: ID de Usuario, B1: Licencia, C1: Plan, D1: Fecha de Activacion, E1: Fecha de Expiracion, F1: Usos Restantes
// -------------------------------------------------------------------------------

// --- INICIO: SECCIÓN DE TELEGRAM ---
const TELEGRAM_BOT_TOKEN = '8160444630:AAHEOxugi4Fr0zBeAgDpab90JW715GGySbg';
const TELEGRAM_CHAT_ID = '6432018838';

function sendTelegramNotification(text) {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    console.log('Falta el token del bot de Telegram o el ID del chat.');
    return;
  }
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  const payload = {
    method: 'post',
    contentType: 'application/json',
    muteHttpExceptions: true,
    payload: JSON.stringify({
      chat_id: TELEGRAM_CHAT_ID,
      text: text,
      parse_mode: 'HTML'
    })
  };
  try {
    UrlFetchApp.fetch(url, payload);
  } catch (e) {
    console.error('Error al enviar notificación a Telegram: ' + e.toString());
  }
}
// --- FIN: SECCIÓN DE TELEGRAM ---

/**
 * @description Punto de entrada para las peticiones web de la extensión. Valida la licencia.
 */
function doPost(e) {
  let respuesta = {};
  try {
    const body = JSON.parse(e.postData.contents);
    const { licenseKey, userId } = body;

    if (!licenseKey || !userId) {
      throw new Error("Faltan 'licenseKey' o 'userId' en la petición.");
    }
    respuesta = verificarYActivarLicencia(licenseKey, userId);
  } catch (error) {
    respuesta = { 
      status: 'ERROR', 
      message: 'Error en el servidor: ' + error.message 
    };
  }
  return ContentService.createTextOutput(JSON.stringify(respuesta))
      .setMimeType(ContentService.MimeType.JSON);
}

/**
 * @description Verifica una licencia creada manualmente y la activa para un usuario.
 * @param {string} key - La clave de licencia a verificar.
 * @param {string} userId - Un identificador único para el usuario de la extensión.
 * @returns {object} - Un objeto con el estado de la licencia.
 */
function verificarYActivarLicencia(key, userId) {
  const hojaLicencias = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('licencias');
  const hojaUsuarios = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('usuarios');

  // 1. Revisar si el usuario ya tiene una licencia activa
  const datosUsuarios = hojaUsuarios.getDataRange().getValues();
  for (let i = 1; i < datosUsuarios.length; i++) {
    if (datosUsuarios[i][0] === userId) {
      const fechaExpiracion = new Date(datosUsuarios[i][4]);
      if (fechaExpiracion > new Date()) {
        return {
          status: 'VALID',
          plan: datosUsuarios[i][2],
          expires: fechaExpiracion.toISOString(),
          remainingUses: datosUsuarios[i][5]
        };
      }
    }
  }

  // 2. Buscar la clave de licencia en la hoja "licencias"
  const datosLicencias = hojaLicencias.getDataRange().getValues();
  let licenciaEncontrada = null;
  let filaIndex = -1;

  for (let i = 1; i < datosLicencias.length; i++) {
    // Columnas: A: Licencia, B: Plan, D: Activada por, E: Fecha de Expiracion
    if (datosLicencias[i][0] === key) {
      if (datosLicencias[i][3]) { // Columna "Activada por"
        sendTelegramNotification(`⚠️ <b>Activación Fallida</b>\n\n<b>Usuario:</b> ${userId}\n<b>Clave:</b> ${key}\n<b>Motivo:</b> Licencia ya en uso.`);
        return { status: 'INVALID', message: 'Esta licencia ya ha sido activada por otro usuario.' };
      }
      licenciaEncontrada = {
        key: datosLicencias[i][0],
        plan: datosLicencias[i][1],
        fechaExp: datosLicencias[i][4] // Leemos la fecha de expiración de la columna E
      };
      filaIndex = i;
      break;
    }
  }

  if (!licenciaEncontrada) {
    sendTelegramNotification(`🚫 <b>Activación Fallida</b>\n\n<b>Usuario:</b> ${userId}\n<b>Clave:</b> ${key}\n<b>Motivo:</b> La licencia no existe.`);
    return { status: 'INVALID', message: 'La licencia no existe.' };
  }

  // 3. Activar la licencia usando la fecha de expiración manual
  const fechaActivacion = new Date();

  let fechaExpiracionManual;
  const expValue = licenciaEncontrada.fechaExp;

  // Parsea la fecha. Prioriza el formato DD-MM-YYYY si es un string.
  if (expValue instanceof Date) {
    fechaExpiracionManual = expValue;
  } else if (typeof expValue === 'string' && expValue.match(/^\d{1,2}-\d{1,2}-\d{4}$/)) {
    const parts = expValue.split('-');
    // Asumimos formato DD-MM-YYYY. El mes en JS es 0-indexed.
    fechaExpiracionManual = new Date(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));
  } else {
    // Fallback para otros formatos que new Date() pueda entender
    fechaExpiracionManual = new Date(expValue);
  }

  // Validar que la fecha leída de la hoja sea una fecha válida
  if (isNaN(fechaExpiracionManual.getTime())) {
    sendTelegramNotification(`❌ <b>Error de Activación</b>\n\n<b>Usuario:</b> ${userId}\n<b>Clave:</b> ${key}\n<b>Motivo:</b> La fecha de expiración en la hoja de cálculo es inválida. Formato esperado: DD-MM-YYYY.`);
    return { status: 'INVALID', message: 'La fecha de expiración configurada para esta licencia es inválida. Use el formato DD-MM-YYYY.' };
  }

  let usos = -1; // -1 significa ilimitado
  if (licenciaEncontrada.plan.toLowerCase() === 'basico') {
    usos = 400;
  }

  // Registrar en la hoja "usuarios"
  hojaUsuarios.appendRow([userId, licenciaEncontrada.key, licenciaEncontrada.plan, fechaActivacion, fechaExpiracionManual, usos]);
  
  // Marcar como activada en la hoja "licencias" (columna D)
  hojaLicencias.getRange(filaIndex + 1, 4).setValue(userId);
  
  // Enviar notificación de éxito
  const timezone = SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone();
  const fechaExpFormateada = Utilities.formatDate(fechaExpiracionManual, timezone, "dd-MM-yyyy");
  sendTelegramNotification(`✅ <b>Nueva Activación Manual</b>\n\n<b>Usuario:</b> ${userId}\n<b>Licencia:</b> ${licenciaEncontrada.key}\n<b>Plan:</b> ${licenciaEncontrada.plan}\n<b>Expira:</b> ${fechaExpFormateada}`);

  return {
    status: 'VALID',
    plan: licenciaEncontrada.plan,
    expires: fechaExpiracionManual.toISOString(),
    remainingUses: usos
  };
}

/**
 * @description Revisa diariamente las licencias de los usuarios para notificar sobre expiraciones.
 * Esta función está diseñada para ser ejecutada por un activador diario (trigger).
 */
function revisarExpiraciones() {
  const hojaUsuarios = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('usuarios');
  if (!hojaUsuarios) {
    console.error('No se encontró la hoja "usuarios".');
    return;
  }
  const datosUsuarios = hojaUsuarios.getDataRange().getValues();
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0); // Normalizar a medianoche para comparar solo fechas

  const timezone = SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone();

  // Empezar en i = 1 para saltar la fila de encabezado
  for (let i = 1; i < datosUsuarios.length; i++) {
    const fila = datosUsuarios[i];
    const userId = fila[0];
    const plan = fila[2];
    const fechaExpiracionRaw = fila[4];

    if (!fechaExpiracionRaw || !userId) {
      continue; // Saltar filas incompletas
    }
    
    const fechaExpiracion = new Date(fechaExpiracionRaw);
    if (isNaN(fechaExpiracion.getTime())) {
      console.error(`Fecha de expiración inválida para el usuario ${userId} en la fila ${i + 1}. Valor: ${fechaExpiracionRaw}`);
      continue; // Saltar si la fecha no es válida
    }
    
    fechaExpiracion.setHours(0, 0, 0, 0); // Normalizar también

    const diffTiempo = fechaExpiracion.getTime() - hoy.getTime();
    const diffDias = Math.round(diffTiempo / (1000 * 60 * 60 * 24));

    const fechaExpFormateada = Utilities.formatDate(new Date(fechaExpiracionRaw), timezone, "dd-MM-yyyy");

    // Notificar si la licencia expira en exactamente 3 días
    if (diffDias === 3) {
      const mensaje = `🔔 <b>Aviso de Renovación</b>\n\nLa licencia del usuario <b>${userId}</b> (Plan: ${plan}) expira en 3 días.\n\n<b>Fecha de Expiración:</b> ${fechaExpFormateada}`;
      sendTelegramNotification(mensaje);
    }
    // Notificar si la licencia expiró ayer (diferencia de -1 día)
    else if (diffDias === -1) {
       const mensaje = `💀 <b>Licencia Expirada</b>\n\nLa licencia del usuario <b>${userId}</b> (Plan: ${plan}) expiró ayer.\n\n<b>Fecha de Expiración:</b> ${fechaExpFormateada}`;
       sendTelegramNotification(mensaje);
    }
  }
}