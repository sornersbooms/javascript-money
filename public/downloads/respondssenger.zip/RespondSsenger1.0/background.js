// background.js - Groq AI Integration
// Handles API calls to avoid CORS issues

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'generateChatCompletion') {
        handleGroqRequest(request.apiKey, request.messages, sendResponse);
        return true; // Indicates async response
    }

    // Manejo de licencias y trials
    if (request.action === 'validateLicense' || request.action === 'registerTrial') {
        handleLicenseRequest(request, sendResponse);
        return true;
    }

    // NUEVO: Manejador de Geolocalización (Bypass CSP)
    if (request.action === 'getIpLocation') {
        handleGeoRequest(sendResponse);
        return true;
    }
});

/**
 * Obtiene IP y Ubicación desde el Background (Sin restricciones CSP)
 * Usa múltiples servicios redundantes.
 */
async function handleGeoRequest(sendResponse) {
    let result = { ip: 'Unknown', lat: null, lon: null, source: 'none' };

    try {
        // Opción 1: ipwho.is (Muy completa)
        try {
            const r1 = await fetch("https://ipwho.is/");
            if (r1.ok) {
                const d1 = await r1.json();
                if (d1.ip) {
                    result.ip = d1.ip;
                    result.lat = d1.latitude;
                    result.lon = d1.longitude;
                    result.source = 'ipwho.is';
                    sendResponse({ success: true, data: result });
                    return;
                }
            }
        } catch (e) {
            console.warn("ipwho.is failed in bg", e);
        }

        // Opción 2: ip-api.com (Fallback clásico)
        try {
            const r2 = await fetch("http://ip-api.com/json");
            if (r2.ok) {
                const d2 = await r2.json();
                if (d2.query) {
                    result.ip = d2.query;
                    result.lat = d2.lat;
                    result.lon = d2.lon;
                    result.source = 'ip-api';
                    sendResponse({ success: true, data: result });
                    return;
                }
            }
        } catch (e) {
            console.warn("ip-api failed in bg", e);
        }

        // Opción 3: ipify (Solo IP, último recurso)
        try {
            const r3 = await fetch("https://api.ipify.org?format=json");
            if (r3.ok) {
                const d3 = await r3.json();
                if (d3.ip) {
                    result.ip = d3.ip;
                    result.source = 'ipify';
                    sendResponse({ success: true, data: result });
                    return;
                }
            }
        } catch (e) { console.warn("ipify failed in bg", e); }

        // Si todo falla
        sendResponse({ success: false, error: "All Geo APIs failed" });

    } catch (err) {
        sendResponse({ success: false, error: err.message });
    }
}

async function handleLicenseRequest(request, sendResponse) {
    // AQUI COLOCA TU URL DE APPS SCRIPT (Asegúrate de que termina en /exec y tiene acceso público)
    const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbziHkt_-e0TuGCTtnBVM4m_aucjqPlqnuOICuRcjEzAnZOjzo-9hR94tbQpSciwaKL5pg/exec";

    try {
        // Enviar como JSON para mayor compatibilidad
        const payload = {
            action: request.action === 'validateLicense' ? 'validate' : 'trial',
            email: request.email,
            key: request.key,
            whatsapp: request.whatsapp,
            userId: request.userId, // Añadir userId necesario
            // Nuevos campos de ubicación
            ip: request.ip,
            lat: request.lat,
            lon: request.lon,
            locError: request.locError
        };

        const response = await fetch(SCRIPT_URL, {
            method: 'POST',
            credentials: 'omit', // IMPORTANTE: Evita conflictos de cookies de Google
            headers: {
                'Content-Type': 'text/plain;charset=utf-8'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`HTTP Check Error: ${response.status}`);
        }

        const text = await response.text();
        console.log("Servidor respondió:", text); // Para depuración

        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            // Si falla el parseo, devolver el texto crudo como error para verlo
            throw new Error(`El servidor no devolvió JSON válida. Respondió: ${text.substring(0, 50)}...`);
        }

        if (data.result === 'success' || data.status === 'success') {
            sendResponse({ success: true, data: data });
        } else {
            sendResponse({ success: false, error: data.message || "Error desconocido" });
        }

    } catch (err) {
        console.error("License Error:", err);
        sendResponse({ success: false, error: err.message });
    }
}

async function handleGroqRequest(apiKey, messages, sendResponse) {
    try {
        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                messages: messages,
                model: 'llama-3.3-70b-versatile', // Modelo actualizado y más potente (2025/2026)
                temperature: 0.6,
                max_tokens: 300
            })
        });

        const data = await response.json();

        if (data.error) {
            sendResponse({ success: false, error: data.error.message });
        } else {
            const content = data.choices[0].message.content;
            sendResponse({ success: true, text: content });
        }
    } catch (error) {
        sendResponse({ success: false, error: error.toString() });
    }
}
