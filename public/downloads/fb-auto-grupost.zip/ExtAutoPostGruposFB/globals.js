// globals.js
const STATE_KEY = 'fb_autopost_state';
const GROUPS_KEY = 'fb_autopost_groups';
const TEMPLATES_KEY = 'fb_autopost_templates';
const LOGS_KEY = 'fb_autopost_logs';

const SCHEDULE_KEY = 'fb_autopost_schedule';
let currentState = {
    isActive: false,
    groups: [],
    currentIndex: 0,
    message: '',
    minDelay: 10,
    maxDelay: 40,
    waitingForUserClick: false,
    interactionTimeout: null,
    interactionTimeout: null,
    imagesBase64: [], // Array
    imageNames: [],   // Array
    imageTypes: [],   // Array
    logs: []
};

let allGroups = [];
let allTemplates = {};
let selectedImageFiles = []; // Array
