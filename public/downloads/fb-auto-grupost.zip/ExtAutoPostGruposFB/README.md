# Facebook Group Autoposter Extension

Esta es una extensión de Chrome para publicar automáticamente en grupos de Facebook, diseñada con una interfaz moderna y flotante.

## Instalación

1. Abre Google Chrome y ve a `chrome://extensions/`.
2. Activa el "Modo de desarrollador" (Developer mode) en la esquina superior derecha.
3. Haz clic en "Cargar descomprimida" (Load unpacked).
4. Selecciona la carpeta `chrome_extension` dentro de este proyecto.

## Uso

1. Ve a Facebook.
2. Verás un panel flotante "FB Autoposter" en la esquina derecha.
3. **Mensaje**: Escribe el texto que quieres publicar.
4. **Grupos**: Pega tu lista de grupos. Puede ser:
   - Un array JSON: `["https://...", "https://..."]`
   - O una lista de URLs (una por línea).
   *Tip: Puedes copiar el contenido de `grupos_urls.json` y pegarlo aquí.*
5. Haz clic en "Iniciar Publicación".

## Funcionamiento

- La extensión navegará al primer grupo.
- Esperará a que cargue la página.
- Buscará el campo de "Crear publicación".
- Escribirá el mensaje simulando un usuario real.
- Hará clic en "Publicar".
- Esperará unos segundos y pasará al siguiente grupo automáticamente.

## Notas Técnicas

- Usa **Manifest V3**.
- **Vanilla JS** y **CSS** puro (sin frameworks).
- Persistencia de estado: Si cierras el navegador, al volver a abrirlo recordará dónde se quedó (siempre que vuelvas a Facebook).
