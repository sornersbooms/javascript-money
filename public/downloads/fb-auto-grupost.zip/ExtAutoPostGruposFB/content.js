// content.js - Entry Point

// Initialize UI
createUI();

// Ensure UI persists
setInterval(() => {
    if (!document.getElementById('dropi-container')) {
        createUI();
    }
}, 2000);
