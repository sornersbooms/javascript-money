// background.js
// Service Worker encargado de la comunicación externa para evitar CORS y manejo de alertas

const SCHEDULE_KEY = 'fb_autopost_schedule';

chrome.runtime.onInstalled.addListener(() => {
    console.log('Facebook Autoposter Extension instalada.');
    // Crear alarma de chequeo cada 1 minuto
    chrome.alarms.create('checkSchedule', { periodInMinutes: 1 });
});

// Escuchar mensajes desde el content script (license.js)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'notifyAdmin') {
        fetch(request.url)
            .then(response => response.text())
            .then(text => sendResponse({ success: true, data: text }))
            .catch(error => sendResponse({ success: false, error: error.toString() }));

        return true; // Indica que responderemos asíncronamente
    }
});

// Alarma para verificar programación
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'checkSchedule') {
        const data = await chrome.storage.local.get(SCHEDULE_KEY);
        const schedule = data[SCHEDULE_KEY];

        if (schedule && schedule.time <= Date.now()) {
            console.log('⏰ Ejecutando programación...', schedule);

            // Buscar si ya hay una pestaña de Facebook abierta
            let tabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });

            if (tabs.length > 0) {
                // Usar la primera encontrada
                const tabId = tabs[0].id;
                // chrome.tabs.update(tabId, { active: true }); // COMENTADO: No traer al frente para permitir trabajo en segundo plano

                chrome.tabs.sendMessage(tabId, { action: 'EXECUTE_SCHEDULE', data: schedule.config }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.log('No se pudo contactar content script, recargando...', chrome.runtime.lastError.message);
                        chrome.tabs.reload(tabId, {}, () => {
                            waitForTabAndExecute(tabId, schedule.config);
                        });
                    } else {
                        console.log('Comando enviado a pestaña existente.');
                        chrome.storage.local.remove(SCHEDULE_KEY);
                    }
                });
            } else {
                // Abrir nueva pestaña (inactive: true para intentar que no robe el foco)
                chrome.tabs.create({ url: 'https://www.facebook.com/groups/feed', active: false }, (tab) => {
                    waitForTabAndExecute(tab.id, schedule.config);
                });
            }
        }
    }
});

function waitForTabAndExecute(tabId, config) {
    chrome.tabs.onUpdated.addListener(function listener(updatedTabId, changeInfo) {
        if (updatedTabId === tabId && changeInfo.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);

            // Esperar un poco a que se inyecten los scripts
            setTimeout(() => {
                chrome.tabs.sendMessage(tabId, { action: 'EXECUTE_SCHEDULE', data: config }, () => {
                    if (!chrome.runtime.lastError) {
                        chrome.storage.local.remove(SCHEDULE_KEY);
                    }
                });
            }, 5000);
        }
    });
}
