// ui.js

function createUI() {
  if (document.getElementById('dropi-container')) return;

  const container = document.createElement('div');
  container.id = 'dropi-container';
  container.innerHTML = `
    <div class="dropi-header" id="dropi-header">
      <span class="dropi-title">
        <span style="font-size: 18px;">🤖</span> FB Auto GruPost Post
      </span>
      <div style="display: flex; gap: 8px; align-items: center;">
        <span id="dropi-license-badge" style="font-size: 10px; background: #333; padding: 2px 6px; border-radius: 4px; color: #aaa;">Cargando...</span>
        <button class="dropi-minimize-btn" id="dropi-minimize">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
    </div>
    
    <div class="dropi-tabs">
        <div class="dropi-tab active" id="tab-btn-editor">📢 Publicar</div>
        <div class="dropi-tab" id="tab-btn-accounts">👥 Cuentas</div>
        <div class="dropi-tab" id="tab-btn-history">📊 Historial</div>
    </div>

    <div class="dropi-content" id="dropi-content-body">
      
      <!-- TAB EDITOR -->
      <div id="tab-editor">
          <!-- Plantillas -->
          <div class="dropi-input-group">
            <label class="dropi-label" style="display:flex; justify-content:space-between; align-items:center;">
                CAMPAÑAS / PLANTILLAS
                <button id="dropi-save-template-btn" style="background:none; border:none; color:#1877F2; cursor:pointer; font-size:10px; font-weight:bold; text-transform:uppercase;">+ Guardar Actual</button>
            </label>
            <div style="display: flex; gap: 8px;">
                <select id="dropi-template-select" class="dropi-search-input" style="flex: 1; cursor:pointer;">
                    <option value="">-- Cargar Campaña --</option>
                </select>
                <button id="dropi-delete-template-btn" class="dropi-btn dropi-btn-sm dropi-btn-danger" style="width: 32px; padding: 0; display: flex; align-items: center; justify-content: center;" title="Eliminar Campaña">🗑️</button>
            </div>
          </div>

          <!-- Mensaje -->
          <div class="dropi-input-group">
            <label class="dropi-label">CONTENIDO DEL POST</label>
            <textarea id="dropi-message" class="dropi-textarea" placeholder="Escribe algo increíble..."></textarea>
            <div style="font-size: 10px; color: #94a3b8; margin-top: 4px; display: flex; align-items: center; gap: 4px;">
                <span>✨ <b>Spintax Activo:</b> Usa {Hola|Saludos} para variar.</span>
            </div>
          </div>

          <!-- Media (Imagen/Video) -->
          <div class="dropi-input-group">
            <label class="dropi-label">MEDIA (FOTOS/VIDEOS)</label>
            <div class="dropi-file-upload" style="position: relative;">
              <input type="file" id="dropi-file" class="dropi-file-input" accept="image/*,video/*" multiple>
              <span class="dropi-file-label" id="dropi-file-text">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                Seleccionar Archivo(s)
              </span>
            </div>
            
            <!-- Grid de miniaturas -->
            <div id="dropi-image-grid" class="dropi-image-grid" style="display: none;"></div>
            
            <!-- Estrategia de Publicación -->
            <div id="dropi-strategy-container" class="dropi-strategy-row" style="display: none;">
                <label class="dropi-label" style="color: #1877F2;">🎯 ESTRATEGIA DE MEDIA</label>
                <select id="dropi-post-strategy" class="dropi-search-input" style="font-size: 11px; padding: 6px;">
                    <option value="order">Publicar en Orden (1, 2, 3...)</option>
                    <option value="random">Aleatorizar Orden (Confundir IA)</option>
                    <option value="single_random">Elegir 1 Aleatoria (Anti-Spam)</option>
                </select>
                <div style="font-size: 9px; color: #64748b; line-height: 1.2;">
                    * <b>En Orden:</b> Sube todas las fotos tal cual las ves. <br>
                    * <b>Aleatorizar:</b> Sube todas pero en distinto orden cada vez.
                </div>
                <div style="display: flex; align-items: center; gap: 6px; margin-top: 6px; padding-top: 6px; border-top: 1px solid rgba(255,255,255,0.05);">
                    <input type="checkbox" id="dropi-deep-clean" style="cursor:pointer;">
                    <label for="dropi-deep-clean" style="font-size: 10px; color: #4ade80; cursor:pointer; font-weight:bold;">🛡️ MODO NINJA: Limpieza Profunda</label>
                </div>
                <!-- Nuevo: Botón Messenger -->
                <div style="display: flex; align-items: center; gap: 6px; margin-top: 2px;">
                    <input type="checkbox" id="dropi-get-messages" style="cursor:pointer;">
                    <label for="dropi-get-messages" style="font-size: 10px; color: #1877F2; cursor:pointer; font-weight:bold;">💬 Incluir Botón "Enviar Mensaje"</label>
                </div>
            </div>
          </div>

          <!-- Anti-Ban Config -->
          <div class="dropi-input-group">
            <label class="dropi-label">🛡️ ANTI-BAN (ESPERA ALEATORIA)</label>
            <div style="display: flex; gap: 8px; align-items: center; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);">
                <span style="font-size: 12px; color: #aaa;">Entre</span>
                <input type="number" id="dropi-min-delay" class="dropi-search-input" style="width: 50px; text-align: center; padding: 4px;" value="10" min="5">
                <span style="font-size: 12px; color: #aaa;">y</span>
                <input type="number" id="dropi-max-delay" class="dropi-search-input" style="width: 50px; text-align: center; padding: 4px;" value="40" min="10">
                <span style="font-size: 12px; color: #aaa;">segundos</span>
            </div>
            
            <!-- Velocidad de Escritura -->
            <div style="margin-top: 10px; background: rgba(0,0,0,0.2); padding: 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                    <span style="font-size: 11px; color: #aaa; font-weight: bold;">⚡ VELOCIDAD DE ESCRITURA</span>
                    <span id="dropi-typing-speed-val" style="font-size: 10px; color: #1877F2; background: rgba(24,119,242,0.1); padding: 2px 6px; border-radius: 10px;">Normal</span>
                </div>
                <input type="range" id="dropi-typing-speed" min="1" max="5" value="3" class="dropi-slider">
                <div style="display: flex; justify-content: space-between; font-size: 9px; color: #64748b; margin-top: 4px;">
                    <span>Lento</span>
                    <span>Híper</span>
                </div>
            </div>

            <!-- Velocidad de Carga Media -->
            <div style="margin-top: 10px; background: rgba(0,0,0,0.2); padding: 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                    <span style="font-size: 11px; color: #aaa; font-weight: bold;">🖼️ ESPERA DE CARGA (MEDIA)</span>
                    <span id="dropi-upload-speed-val" style="font-size: 10px; color: #4ade80; background: rgba(74,222,128,0.1); padding: 2px 6px; border-radius: 10px;">Seguro</span>
                </div>
                <input type="range" id="dropi-upload-speed" min="1" max="5" value="3" class="dropi-slider">
                <div style="display: flex; justify-content: space-between; font-size: 9px; color: #64748b; margin-top: 4px;">
                    <span>Cauteloso</span>
                    <span>Rápido</span>
                </div>
            </div>
          </div>

          <!-- Grupos Manager -->
          <div class="dropi-input-group">
            <label class="dropi-label">
              DESTINOS
              <button id="dropi-extract-btn" class="dropi-btn dropi-btn-sm dropi-btn-secondary" style="background: rgba(24, 119, 242, 0.2); color: #1877F2; border: 1px solid #1877F2;">
                📡 Escanear Grupos
              </button>
            </label>
            
            <div class="dropi-search-box">
              <svg class="dropi-search-icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
              <input type="text" id="dropi-search" class="dropi-search-input" placeholder="Filtrar grupos...">
            </div>

            <div class="dropi-selection-controls">
                <button id="dropi-select-all" class="dropi-btn dropi-btn-sm dropi-btn-secondary" style="flex: 1; background: rgba(177, 177, 177, 0.57); color: #ffffffff; border: 1px solid #00a015ff;">✅ Todos</button>
                <button id="dropi-deselect-all" class="dropi-btn dropi-btn-sm dropi-btn-secondary" style="flex: 1; background: rgba(177, 177, 177, 0.57); color: #ffffffff; border: 1px solid #f21818ff;">❌ Ninguno</button>
            </div>

            <!-- Nuevo: Filtro por Cuenta -->
            <div style="margin-bottom: 8px;">
                <select id="dropi-account-filter" class="dropi-search-input" style="cursor:pointer; font-size: 11px; padding: 8px;">
                    <option value="all">🌐 Todas las Cuentas</option>
                </select>
            </div>

            <div id="dropi-group-list" class="dropi-group-list-container">
              <div class="dropi-empty-state">
                Sistema en espera.<br>Haz clic en "Escanear Grupos".
              </div>
            </div>
            
            <div style="display: flex; justify-content: space-between; font-size: 10px; color: #64748b; margin-top: 4px;">
              <span id="dropi-selected-count">0 seleccionados</span>
            </div>
          </div>

          <!-- Programación -->
          <div class="dropi-input-group" style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px; margin-top: 10px;">
            <label class="dropi-label">📅 PROGRAMACIÓN (OPCIONAL)</label>
            <div style="display: flex; gap: 8px;">
                <input type="datetime-local" id="dropi-schedule-time" class="dropi-search-input" style="flex: 1; cursor:pointer;">
                <button id="dropi-schedule-btn" class="dropi-btn dropi-btn-sm" style="background: rgba(255, 152, 0, 0.2); color: #FF9800; border: 1px solid #FF9800; width: auto;">
                    ⌚ Programar
                </button>
            </div>
             <div id="dropi-schedule-status" style="font-size: 11px; color: #FF9800; margin-top: 4px; display:none;">
                Inicio programado: <span id="dropi-schedule-display" style="font-weight:bold;"></span>
                <button id="dropi-cancel-schedule" style="background:none; border:none; color:#f87171; text-decoration:underline; cursor:pointer; margin-left:5px;">(Cancelar)</button>
            </div>
          </div>

          <!-- Acciones -->
          <div class="dropi-actions" id="dropi-main-actions">
            <button id="dropi-start" class="dropi-btn dropi-btn-primary" style="background: rgba(24, 119, 242, 0.2); color: #1877F2; border: 1px solid #1877F2;">
              <span>🚀</span> INICIAR SECUENCIA
            </button>
          </div>

          <!-- Controles Activos -->
          <div class="dropi-actions" id="dropi-active-controls" style="display: none;">
            <button id="dropi-skip" class="dropi-btn dropi-btn-warning" style="grid-column: span 1;">
              <span>⏭</span> SALTAR
            </button>
            <button id="dropi-stop" class="dropi-btn dropi-btn-danger" style="grid-column: span 1;">
              <span>⏹</span> DETENER
            </button>
          </div>
      </div>

      <!-- TAB ACCOUNTS -->
      <div id="tab-accounts" style="display: none;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
              <span style="font-size:12px; font-weight:bold; color:#fff;">Cuentas Detectadas</span>
              <button id="dropi-scan-account" style="background:none; border:none; color:#1877F2; cursor:pointer; font-size:10px;">🔄 Detectar Actual</button>
          </div>
          <div id="dropi-accounts-list" class="dropi-history-list">
              <div class="dropi-empty-state">No hay cuentas registradas.</div>
          </div>

          <!-- License Section -->
          <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
            <span style="font-size:12px; font-weight:bold; color:#fff; display:block; margin-bottom:10px;">🔑 Licencia & Plan</span>
            <div style="background: rgba(0,0,0,0.2); padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:11px;">
                    <span style="color:#aaa;">Estado:</span>
                    <span id="dropi-license-status-text" style="color:#fff; font-weight:bold;">Verificando...</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:11px;">
                    <span style="color:#aaa;">Uso Mensual:</span>
                    <span id="dropi-license-usage-text" style="color:#fff;">0 / 0</span>
                </div>
                
                <div style="display:flex; gap:8px;">
                    <input type="text" id="dropi-license-key" class="dropi-search-input" placeholder="Ingresa tu clave..." style="padding: 8px; font-size: 11px;">
                    <button id="dropi-activate-btn" class="dropi-btn dropi-btn-sm dropi-btn-primary" style="width: auto;">ACTIVAR</button>
                </div>
                
                <!-- Contact Buttons -->
                <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255,255,255,0.05); text-align: center;">
                    <span style="font-size: 10px; color: #aaa; display: block; margin-bottom: 8px;">¿Necesitas una licencia? Contáctame:</span>
                    <div style="display: flex; gap: 8px; justify-content: center;">
                        <a href="https://t.me/programadormillonary" target="_blank" style="text-decoration: none; flex: 1;">
                            <button class="dropi-btn dropi-btn-sm" style="width: 100%; background: #229ED9; color: white; border: none;">
                                ✈️ Telegram
                            </button>
                        </a>
                        <a href="https://wa.me/573176116145" target="_blank" style="text-decoration: none; flex: 1;">
                            <button class="dropi-btn dropi-btn-sm" style="width: 100%; background: #25D366; color: white; border: none;">
                                💬 WhatsApp
                            </button>
                        </a>
                    </div>
                </div>
            </div>
            

          </div>
      </div>

      <!-- TAB HISTORY -->
      <div id="tab-history" style="display: none;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
              <span style="font-size:12px; font-weight:bold; color:#fff;">Registro de Actividad</span>
              <button id="dropi-clear-history" style="background:none; border:none; color:#f87171; cursor:pointer; font-size:10px;">Borrar Todo</button>
          </div>
          <div id="dropi-history-list" class="dropi-history-list">
              <div class="dropi-empty-state">No hay actividad reciente.</div>
          </div>
      </div>

      <!-- Status -->
      <div class="dropi-status" style="margin-top: 10px;">
        <div id="dropi-status-dot" class="dropi-status-dot"></div>
        <span id="dropi-status-text" style="flex: 1;">Sistema Online</span>
      </div>
      <div class="dropi-progress-container">
        <div id="dropi-progress-fill" class="dropi-progress-fill"></div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  // --- EVENT LISTENERS ---

  document.getElementById('dropi-minimize').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleMinimize();
  });

  container.addEventListener('click', (e) => {
    if (container.classList.contains('minimized')) toggleMinimize();
  });

  makeDraggable(container);

  // Tabs
  document.getElementById('tab-btn-editor').addEventListener('click', () => switchTab('editor'));
  document.getElementById('tab-btn-accounts').addEventListener('click', () => switchTab('accounts'));
  document.getElementById('tab-btn-history').addEventListener('click', () => switchTab('history'));
  document.getElementById('dropi-clear-history').addEventListener('click', clearHistory);
  document.getElementById('dropi-scan-account').addEventListener('click', () => {
    const info = getCurrentAccountInfo();

    // Update existing groups with this account ID
    let updatedCount = 0;
    allGroups.forEach(g => {
      if (g.accountId === info.id) {
        g.accountName = info.name;
        updatedCount++;
      }
    });

    if (updatedCount > 0) {
      saveGroupsToStorage();
    }

    alert(`Cuenta detectada: ${info.name}\nID: ${info.id}\nGrupos actualizados: ${updatedCount}`);

    renderAccountsList();
    renderGroupList();
  });

  // License Activation
  document.getElementById('dropi-activate-btn').addEventListener('click', async () => {
    const key = document.getElementById('dropi-license-key').value.trim();
    if (!key) return alert('Ingresa una clave');

    const btn = document.getElementById('dropi-activate-btn');
    btn.textContent = '...';

    const success = await activateLicense(key);
    if (success) {
      alert('¡Licencia activada correctamente!');
      document.getElementById('dropi-license-key').value = '';
      updateLicenseUI();
    } else {
      alert('Clave inválida o expirada.');
    }
    btn.textContent = 'ACTIVAR';
  });



  // Botones Principales
  document.getElementById('dropi-start').addEventListener('click', startPosting);
  document.getElementById('dropi-stop').addEventListener('click', stopPosting);
  document.getElementById('dropi-skip').addEventListener('click', skipCurrentGroup);
  document.getElementById('dropi-skip').addEventListener('click', skipCurrentGroup);
  document.getElementById('dropi-extract-btn').addEventListener('click', handleRemoteExtraction);

  // Schedule Listeners
  document.getElementById('dropi-schedule-btn').addEventListener('click', saveSchedule);
  document.getElementById('dropi-cancel-schedule').addEventListener('click', cancelSchedule);

  // Botones Plantillas
  document.getElementById('dropi-save-template-btn').addEventListener('click', saveCurrentTemplate);
  document.getElementById('dropi-delete-template-btn').addEventListener('click', deleteCurrentTemplate);
  document.getElementById('dropi-template-select').addEventListener('change', loadSelectedTemplate);

  // Selección Masiva
  document.getElementById('dropi-select-all').addEventListener('click', () => toggleAllSelection(true));
  document.getElementById('dropi-deselect-all').addEventListener('click', () => toggleAllSelection(false));

  // Inputs
  document.getElementById('dropi-file').addEventListener('change', handleFileSelect);
  document.getElementById('dropi-typing-speed').addEventListener('input', (e) => {
    const labels = ['Muy Lento', 'Lento', 'Normal', 'Rápido', 'Híper'];
    document.getElementById('dropi-typing-speed-val').textContent = labels[e.target.value - 1];
  });

  document.getElementById('dropi-upload-speed').addEventListener('input', (e) => {
    const labels = ['Muy Lento', 'Lento', 'Seguro', 'Rápido', 'Instantáneo'];
    document.getElementById('dropi-upload-speed-val').textContent = labels[e.target.value - 1];
  });

  document.getElementById('dropi-search').addEventListener('input', filterGroups);
  document.getElementById('dropi-account-filter').addEventListener('change', filterGroups);

  // Restore
  restoreState();
  updateLicenseUI();
}

async function updateLicenseUI() {
  const status = await checkLicenseStatus();
  const badge = document.getElementById('dropi-license-badge');
  const statusText = document.getElementById('dropi-license-status-text');
  const usageText = document.getElementById('dropi-license-usage-text');

  if (!badge) return;

  let tierName = 'GRATIS';
  let color = '#aaa';

  if (status.tier === 'basic') { tierName = 'BÁSICO'; color = '#fbbf24'; }
  if (status.tier === 'pro') { tierName = 'PRO'; color = '#4ade80'; }

  if (!status.canPost && status.reason === 'expired_trial') {
    badge.textContent = 'EXPIRADO';
    badge.style.color = '#f87171';
    badge.style.border = '1px solid #f87171';
    statusText.textContent = 'Periodo de prueba finalizado';
  } else {
    if (status.tier === 'free') {
      badge.textContent = `TRIAL: ${status.daysLeft} DÍAS`;
      badge.style.color = '#60a5fa';
      statusText.textContent = `Prueba Gratuita (${status.daysLeft} días restantes)`;
    } else {
      if (status.daysLeft <= 3) {
        badge.textContent = `⚠️ VENCE EN ${status.daysLeft} DÍAS`;
        badge.style.color = '#f87171'; // Rojo Alerta
        badge.style.border = '1px solid #f87171';
      } else {
        badge.textContent = tierName;
        badge.style.color = color;
        badge.style.border = 'none';
      }
      statusText.textContent = `Plan ${tierName} Activo`;
    }
  }

  const limitText = status.postsLimit === Infinity ? 'Ilimitado' : status.postsLimit;
  usageText.textContent = `${status.postsUsed} / ${limitText}`;
}

function switchTab(tabName) {
  const editor = document.getElementById('tab-editor');
  const accounts = document.getElementById('tab-accounts');
  const history = document.getElementById('tab-history');

  const btnEditor = document.getElementById('tab-btn-editor');
  const btnAccounts = document.getElementById('tab-btn-accounts');
  const btnHistory = document.getElementById('tab-btn-history');

  // Reset all
  editor.style.display = 'none';
  accounts.style.display = 'none';
  history.style.display = 'none';

  btnEditor.classList.remove('active');
  btnAccounts.classList.remove('active');
  btnHistory.classList.remove('active');

  if (tabName === 'editor') {
    editor.style.display = 'block';
    btnEditor.classList.add('active');
  } else if (tabName === 'accounts') {
    accounts.style.display = 'block';
    btnAccounts.classList.add('active');
    renderAccountsList();
  } else {
    history.style.display = 'block';
    btnHistory.classList.add('active');
    renderHistory();
  }
}

function updateStatusUI() {
  const statusText = document.getElementById('dropi-status-text');
  const statusDot = document.getElementById('dropi-status-dot');
  const progressFill = document.getElementById('dropi-progress-fill');

  if (currentState.isActive) {
    if (currentState.waitingForUserClick) {
      statusText.textContent = '⚠️ Haz CLICK en "Escribe algo..."';
      statusDot.className = 'dropi-status-dot waiting';
    } else {
      statusText.textContent = `Grupo ${currentState.currentIndex + 1}/${currentState.groups.length}`;
      statusDot.className = 'dropi-status-dot active';
    }
    const progress = ((currentState.currentIndex) / currentState.groups.length) * 100;
    progressFill.style.width = `${progress}%`;
  } else {
    statusText.textContent = 'Sistema Online';
    statusDot.className = 'dropi-status-dot';
    progressFill.style.width = '0%';
  }
}

function makeDraggable(element) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  element.onmousedown = dragMouseDown;

  function dragMouseDown(e) {
    e = e || window.event;
    const isMinimized = element.classList.contains('minimized');
    if (!isMinimized) {
      if (!e.target.closest('#dropi-header')) return;
    }
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    element.style.top = (element.offsetTop - pos2) + "px";
    element.style.left = (element.offsetLeft - pos1) + "px";
    element.style.right = 'auto';
    element.style.bottom = 'auto';
  }

  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

function toggleMinimize() {
  const container = document.getElementById('dropi-container');
  container.classList.toggle('minimized');
  const btn = document.getElementById('dropi-minimize');
  if (!container.classList.contains('minimized')) {
    btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>';
  }
}

async function handleFileSelect(e) {
  const files = Array.from(e.target.files);
  if (files.length > 0) {
    for (const file of files) {
      try {
        const base64 = await fileToDataURL(file);
        selectedImageFiles.push(file);

        // Add to state arrays for persistence if needed
        if (!currentState.imagesBase64) currentState.imagesBase64 = [];
        if (!currentState.imageNames) currentState.imageNames = [];
        if (!currentState.imageTypes) currentState.imageTypes = [];

        currentState.imagesBase64.push(base64);
        currentState.imageNames.push(file.name);
        currentState.imageTypes.push(file.type);
      } catch (err) {
        console.error("Error cargando archivo:", err);
      }
    }

    // Clear input to allow re-selecting same files if deleted
    e.target.value = '';

    renderImageThumbnails();
    saveState();
  }
}

function renderImageThumbnails() {
  const grid = document.getElementById('dropi-image-grid');
  const strategyContainer = document.getElementById('dropi-strategy-container');
  const fileText = document.getElementById('dropi-file-text');

  if (!grid) return;

  if (selectedImageFiles.length === 0) {
    grid.style.display = 'none';
    strategyContainer.style.display = 'none';
    if (fileText) fileText.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg> Seleccionar Archivo(s)`;
    return;
  }

  grid.style.display = 'grid';
  strategyContainer.style.display = 'flex';
  grid.innerHTML = '';

  if (fileText) {
    fileText.textContent = `${selectedImageFiles.length} Archivos seleccionados`;
  }

  selectedImageFiles.forEach((file, index) => {
    const container = document.createElement('div');
    container.className = 'dropi-thumbnail-container';
    container.setAttribute('draggable', 'true');
    container.dataset.index = index;

    // --- Drag & Drop Events ---
    container.ondragstart = (e) => {
      e.dataTransfer.setData('text/plain', index);
      container.style.opacity = '0.5';
    };

    container.ondragend = () => {
      container.style.opacity = '1';
      const allContainers = grid.querySelectorAll('.dropi-thumbnail-container');
      allContainers.forEach(c => c.classList.remove('drag-over'));
    };

    container.ondragover = (e) => {
      e.preventDefault();
      container.classList.add('drag-over');
    };

    container.ondragleave = () => {
      container.classList.remove('drag-over');
    };

    container.ondrop = (e) => {
      e.preventDefault();
      const fromIndex = parseInt(e.dataTransfer.getData('text/plain'));
      const toIndex = index;

      if (fromIndex !== toIndex) {
        reorderMedia(fromIndex, toIndex);
      }
    };
    // ---------------------------

    // If it's a File object, we might need a URL, but we have imagesBase64 in state
    const src = currentState.imagesBase64[index];

    if (file.type.startsWith('video/')) {
      container.innerHTML = `
            <video class="dropi-thumbnail-img" src="${src}"></video>
            <div style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); color:white; pointer-events:none;">🎬</div>
        `;
    } else {
      container.innerHTML = `<img class="dropi-thumbnail-img" src="${src}">`;
    }

    const removeBtn = document.createElement('button');
    removeBtn.className = 'dropi-thumbnail-remove';
    removeBtn.innerHTML = '✕';
    removeBtn.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      removeImageAtIndex(index);
    };

    const orderBadge = document.createElement('div');
    orderBadge.className = 'dropi-thumbnail-order';
    orderBadge.textContent = index + 1;

    container.appendChild(removeBtn);
    container.appendChild(orderBadge);
    grid.appendChild(container);
  });
}

function reorderMedia(fromIndex, toIndex) {
  // Reordenar todos los arrays en simultáneo
  const move = (arr) => {
    const item = arr.splice(fromIndex, 1)[0];
    arr.splice(toIndex, 0, item);
  };

  move(selectedImageFiles);
  move(currentState.imagesBase64);
  move(currentState.imageNames);
  move(currentState.imageTypes);

  renderImageThumbnails();
  saveState();
}

function removeImageAtIndex(index) {
  selectedImageFiles.splice(index, 1);
  if (currentState.imagesBase64) currentState.imagesBase64.splice(index, 1);
  if (currentState.imageNames) currentState.imageNames.splice(index, 1);
  if (currentState.imageTypes) currentState.imageTypes.splice(index, 1);

  renderImageThumbnails();
  saveState();
}

function removeSelectedImage() {
  selectedImageFiles = [];
  currentState.imagesBase64 = [];
  currentState.imageNames = [];
  currentState.imageTypes = [];

  renderImageThumbnails();
  saveState();
}

function renderHistory() {
  const list = document.getElementById('dropi-history-list');
  if (!list) return;

  list.innerHTML = '';

  if (!currentState.logs || currentState.logs.length === 0) {
    list.innerHTML = '<div class="dropi-empty-state">No hay actividad reciente.</div>';
    return;
  }

  currentState.logs.forEach(log => {
    const item = document.createElement('div');
    item.className = 'dropi-log-item';

    let icon = '❓';
    let statusClass = '';
    let statusText = '';

    if (log.type === 'success') { icon = '✅'; statusClass = 'status-success'; statusText = 'Publicado'; }
    else if (log.type === 'error') { icon = '❌'; statusClass = 'status-error'; statusText = 'Falló'; }
    else if (log.type === 'skip') { icon = '⏭️'; statusClass = 'status-skip'; statusText = 'Saltado'; }

    item.innerHTML = `
        <div class="dropi-log-icon">${icon}</div>
        <div class="dropi-log-content">
            <div class="dropi-log-group" title="${log.group}">${log.group}</div>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="dropi-log-status ${statusClass}">${statusText}</span>
                <span class="dropi-log-time">${log.time}</span>
            </div>
        </div>
    `;
    list.appendChild(item);
  });
}

function clearHistory() {
  if (confirm('¿Borrar todo el historial?')) {
    currentState.logs = [];
    saveState();
    renderHistory();
  }
}

function toggleActiveControls(isActive) {
  const mainActions = document.getElementById('dropi-main-actions');
  const activeControls = document.getElementById('dropi-active-controls');

  if (isActive) {
    mainActions.style.display = 'none';
    activeControls.style.display = 'grid';
  } else {
    mainActions.style.display = 'grid';
    activeControls.style.display = 'none';
  }
}
