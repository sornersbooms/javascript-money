// license.js

const TIER_FREE = 'free';
const TIER_BASIC = 'basic';
const TIER_PRO = 'pro';

const LIMITS = {
    [TIER_FREE]: { maxPosts: Infinity, days: 5 },
    [TIER_BASIC]: { maxPosts: 950 },
    [TIER_PRO]: { maxPosts: Infinity }
};

// URL de tu Google Apps Script (PÉGALA AQUÍ ABAJO ENTRE LAS COMILLAS)
const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbyn8P7VcIggsmIn6wKNpn2Gm2Suh_eCPFfcNmZXKK7JlfvrssFaEArtrK7AfpqpXLMI-Q/exec';

// Validación Real con Google Sheets
// Validación Real con Google Sheets (Vía Background para evitar CORS)
async function validateLicenseKeyRemote(key) {
    if (!GOOGLE_SCRIPT_URL || GOOGLE_SCRIPT_URL.includes('TU_URL')) {
        alert('ERROR DE CONFIGURACIÓN: Falta la URL del servidor de licencias en license.js');
        return { valid: false };
    }

    const url = `${GOOGLE_SCRIPT_URL}?key=${encodeURIComponent(key)}`;

    return new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'notifyAdmin', url: url }, (response) => {
            if (response && response.success) {
                try {
                    const data = JSON.parse(response.data);
                    resolve(data);
                } catch (e) {
                    console.error('Error parseando respuesta de licencia:', e);
                    resolve({ valid: false });
                }
            } else {
                console.error('Error validando licencia:', response ? response.error : 'Desconocido');
                alert('Error de conexión validando licencia.');
                resolve({ valid: false });
            }
        });
    });
}

async function checkLicenseStatus() {
    // Usamos SYNC para que persista aunque desinstalen
    const data = await chrome.storage.sync.get(['licenseInfo', 'stats']);
    const now = new Date();

    let license = data.licenseInfo || {
        tier: TIER_FREE,
        installDate: now.getTime(),
        expiryDate: null
    };

    let stats = data.stats || {
        postsThisMonth: 0,
        lastPostMonth: now.getMonth()
    };

    // Reset contador mensual si cambiamos de mes
    if (stats.lastPostMonth !== now.getMonth()) {
        stats.postsThisMonth = 0;
        stats.lastPostMonth = now.getMonth();
        await chrome.storage.sync.set({ stats });
    }

    // Inicializar fecha de instalación si no existe
    if (!data.licenseInfo) {
        await chrome.storage.sync.set({ licenseInfo: license });
        notifyAdmin('🚀 Nueva Instalación', 'Un nuevo usuario ha comenzado su prueba de 5 días.');
    }

    const result = {
        canPost: true,
        reason: '',
        tier: license.tier,
        postsUsed: stats.postsThisMonth,
        postsLimit: LIMITS[license.tier].maxPosts,
        daysLeft: 0
    };

    // 1. Cálculo de Días Restantes (Para todos los planes)
    const oneDay = 24 * 60 * 60 * 1000;

    if (license.expiryDate) {
        // Si tiene fecha de vencimiento explícita (Basic/Pro)
        const expiry = new Date(license.expiryDate).getTime();
        const diff = Math.ceil((expiry - now.getTime()) / oneDay);
        result.daysLeft = Math.max(0, diff);

        // Si ya venció
        if (diff < 0) {
            result.canPost = false;
            result.reason = 'expired_license';
        }
    } else if (license.tier === TIER_FREE) {
        // Lógica Trial (basada en fecha instalación)
        const daysUsed = Math.round((now.getTime() - license.installDate) / oneDay);
        const daysLeft = LIMITS[TIER_FREE].days - daysUsed;
        result.daysLeft = Math.max(0, daysLeft);

        if (daysLeft < 0) {
            result.canPost = false;
            result.reason = 'expired_trial';
        }
    }

    // 2. Chequeo de Límite de Posts (Para Basic)
    if (license.tier === TIER_BASIC) {
        if (stats.postsThisMonth >= LIMITS[TIER_BASIC].maxPosts) {
            result.canPost = false;
            result.reason = 'limit_reached';
        }
    }

    return result;
}

async function incrementPostCounter() {
    const data = await chrome.storage.sync.get('stats');
    let stats = data.stats || { postsThisMonth: 0, lastPostMonth: new Date().getMonth() };

    stats.postsThisMonth++;
    await chrome.storage.sync.set({ stats });
}

async function activateLicense(keyInput) {
    const key = keyInput.trim(); // Quitar espacios accidentales
    const validation = await validateLicenseKeyRemote(key);

    if (validation.valid) {
        const licenseInfo = {
            tier: validation.tier,
            installDate: new Date().getTime(), // Reset o mantener original
            expiryDate: validation.expires,
            key: key
        };
        await chrome.storage.sync.set({ licenseInfo });
        notifyAdmin('💰 Licencia Activada', `Clave: ${key} | Plan: ${validation.tier}`);
        return true;
    }
    return false;
}

// Función para enviar alertas a Telegram (vía Google Script)
// Función para enviar alertas a Telegram (Delegando al Background Script para evitar CORS)
async function notifyAdmin(title, message) {
    if (!GOOGLE_SCRIPT_URL || GOOGLE_SCRIPT_URL.includes('TU_URL')) return;

    const url = `${GOOGLE_SCRIPT_URL}?action=notify&title=${encodeURIComponent(title)}&msg=${encodeURIComponent(message)}`;

    try {
        chrome.runtime.sendMessage({ action: 'notifyAdmin', url: url });
    } catch (e) {
        // Silencioso en producción
    }
}
