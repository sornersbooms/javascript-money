// templates.js


async function saveCurrentTemplate() {
    const message = document.getElementById('dropi-message').value;
    const minDelay = document.getElementById('dropi-min-delay').value;
    const maxDelay = document.getElementById('dropi-max-delay').value;

    const hasImages = selectedImageFiles && selectedImageFiles.length > 0;
    if (!message && !hasImages) return alert('La campaña debe tener al menos un mensaje o una imagen.');

    const name = prompt('Nombre de la campaña (ej. Zapatos Verano):');
    if (!name) return;

    // 1. Guardar Grupos Seleccionados
    const selectedGroupUrls = allGroups.filter(g => g.selected).map(g => g.url);

    // 2. Guardar Imagenes (Array)
    let imagesData = [];
    if (hasImages) {
        try {
            const base64Promises = selectedImageFiles.map(file => fileToDataURL(file));
            const base64Results = await Promise.all(base64Promises);

            imagesData = base64Results.map((b64, i) => ({
                base64: b64,
                name: selectedImageFiles[i].name,
                type: selectedImageFiles[i].type
            }));
        } catch (e) {
            console.error('Error guardando imagenes en plantilla:', e);
            return alert('Error al procesar las imagenes para la campaña.');
        }
    } else if (currentState.imagesBase64 && currentState.imagesBase64.length > 0) {
        // Caso: Imagenes restauradas del estado pero no cambiadas
        imagesData = currentState.imagesBase64.map((b64, i) => ({
            base64: b64,
            name: currentState.imageNames[i],
            type: currentState.imageTypes[i]
        }));
    }

    allTemplates[name] = {
        message: message,
        minDelay: minDelay,
        maxDelay: maxDelay,
        groups: selectedGroupUrls,
        images: imagesData // Renamed from 'image' to 'images' for plural support
    };

    try {
        await chrome.storage.local.set({ [TEMPLATES_KEY]: allTemplates });
        renderTemplateOptions(name);
        alert(`Campaña "${name}" guardada con éxito (${selectedGroupUrls.length} grupos, ${imagesData.length} archivos).`);
    } catch (e) {
        console.error(e);
        alert('Error guardando campaña. Es posible que los archivos sean muy pesados para el almacenamiento local.');
    }
}

async function deleteCurrentTemplate() {
    const select = document.getElementById('dropi-template-select');
    const name = select.value;

    if (!name) return alert('Selecciona una campaña para eliminar.');

    if (confirm(`¿Eliminar la campaña "${name}"?`)) {
        delete allTemplates[name];
        await chrome.storage.local.set({ [TEMPLATES_KEY]: allTemplates });
        renderTemplateOptions();
    }
}

function loadSelectedTemplate() {
    const select = document.getElementById('dropi-template-select');
    const name = select.value;

    if (!name || !allTemplates[name]) return;

    const t = allTemplates[name];

    // 1. Cargar Textos
    document.getElementById('dropi-message').value = t.message || '';
    document.getElementById('dropi-min-delay').value = t.minDelay || 10;
    document.getElementById('dropi-max-delay').value = t.maxDelay || 40;

    // 2. Cargar Grupos
    if (t.groups && Array.isArray(t.groups)) {
        let matchCount = 0;
        allGroups.forEach(g => {
            const shouldSelect = t.groups.includes(g.url);
            if (g.selected !== shouldSelect) {
                g.selected = shouldSelect;
                matchCount++;
            }
        });
        renderGroupList();
        saveGroupsToStorage();
        // Actualizar contador visual
        const selectedCount = allGroups.filter(g => g.selected).length;
        document.getElementById('dropi-selected-count').textContent = `${selectedCount} seleccionados`;
    }

    // 3. Cargar Imagenes
    // Support legacy 't.image' and new 't.images'
    let imagesToLoad = [];
    if (t.images && Array.isArray(t.images)) {
        imagesToLoad = t.images;
    } else if (t.image) {
        imagesToLoad = [t.image];
    }

    if (imagesToLoad.length > 0) {
        // Actualizar Estado Global
        currentState.imagesBase64 = imagesToLoad.map(i => i.base64);
        currentState.imageNames = imagesToLoad.map(i => i.name);
        currentState.imageTypes = imagesToLoad.map(i => i.type);

        // Recrear Objetos File
        selectedImageFiles = imagesToLoad.map((img, i) =>
            dataURLtoFile(img.base64, img.name || `imagen_${i}.png`)
        );

        // Actualizar UI (Nuevo sistema de thumbnails)
        renderImageThumbnails();
    } else {
        // Si la plantilla no tiene imagen, limpiar la actual
        removeSelectedImage();
    }

    saveState();
}

function renderTemplateOptions(selectedName = null) {
    const select = document.getElementById('dropi-template-select');
    select.innerHTML = '<option value="">-- Cargar Campaña --</option>';

    Object.keys(allTemplates).forEach(name => {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        if (name === selectedName) option.selected = true;
        select.appendChild(option);
    });
}
