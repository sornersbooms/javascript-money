// accounts.js

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

function getCurrentAccountInfo() {
    const userId = getCookie('c_user');
    let name = "Desconocido";

    // Strategy 1: Top Right Menu Button (Most reliable for "Account of Name")
    // Buscamos el botón del menú de perfil que suele tener aria-label="Cuenta de [Nombre]"
    const menuButton = document.querySelector('div[role="banner"] div[role="button"][aria-label^="Cuenta de"]');
    if (menuButton) {
        const label = menuButton.getAttribute('aria-label');
        if (label) {
            name = label.replace('Cuenta de ', '').trim();
        }
    }

    // Strategy 2: Sidebar Profile Link
    if (name === "Desconocido") {
        // El selector busca el enlace al perfil en la barra lateral izquierda
        const sidebarLink = document.querySelector('div[role="navigation"] a[href^="/me/"] span, div[role="navigation"] a[href*="profile.php"] span');
        if (sidebarLink && sidebarLink.textContent) {
            name = sidebarLink.textContent.trim();
        }
    }

    // Strategy 3: Profile Page Header (if user is on their own profile)
    if (name === "Desconocido" && (window.location.href.includes('facebook.com/me') || window.location.href.includes('profile.php'))) {
        const profileHeader = document.querySelector('h1');
        if (profileHeader) {
            name = profileHeader.textContent.trim();
        }
    }

    // Strategy 4: Script Data (Last Resort - JSON parsing from embedded scripts)
    if (name === "Desconocido") {
        try {
            const scripts = document.querySelectorAll('script');
            for (let script of scripts) {
                const content = script.textContent;
                if (content.includes('"NAME":')) {
                    const match = content.match(/"NAME":"([^"]+)"/);
                    if (match && match[1]) {
                        name = match[1];
                        break;
                    }
                }
            }
        } catch (e) {
            console.warn('Error parsing script for name', e);
        }
    }

    // GENERATE UNIQUE ID
    // Las Páginas (New Page Experience) comparten la cookie c_user del administrador.
    // Para distinguirlas, usamos una combinación del ID base y el nombre del perfil activo.
    const cleanName = name.replace(/[^a-zA-Z0-9]/g, '');
    const compositeId = (userId && name !== "Desconocido") ? `${userId}_${cleanName}` : (userId || 'unknown');

    return {
        id: compositeId,
        name: name,
        baseId: userId // Guardamos el ID original por si acaso
    };
}

// Function to group groups by account
function getGroupsByAccount() {
    const groupsByAccount = {};
    allGroups.forEach(g => {
        const accId = g.accountId || 'unknown';
        const accName = g.accountName || 'Desconocido';
        const key = `${accName} (${accId})`;

        if (!groupsByAccount[key]) {
            groupsByAccount[key] = [];
        }
        groupsByAccount[key].push(g);
    });
    return groupsByAccount;
}

function renderAccountsList() {
    const list = document.getElementById('dropi-accounts-list');
    if (!list) return;

    list.innerHTML = '';
    const groupsByAccount = getGroupsByAccount();
    const keys = Object.keys(groupsByAccount);

    if (keys.length === 0) {
        list.innerHTML = '<div class="dropi-empty-state">No hay cuentas registradas.</div>';
        return;
    }

    keys.forEach(key => {
        const groups = groupsByAccount[key];
        const item = document.createElement('div');
        item.className = 'dropi-log-item'; // Reuse log item style for now
        item.style.cursor = 'default';

        item.innerHTML = `
            <div class="dropi-log-icon">👤</div>
            <div class="dropi-log-content">
                <div class="dropi-log-group" style="font-weight:bold;">${key}</div>
                <div style="font-size:10px; color:#aaa;">${groups.length} grupos guardados</div>
            </div>
        `;
        list.appendChild(item);
    });
}
