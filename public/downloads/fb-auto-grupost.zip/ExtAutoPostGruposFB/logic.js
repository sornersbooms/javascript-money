// logic.js

async function logActivity(type, groupName, details = '') {
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const entry = {
        type: type, // 'success', 'error', 'skip'
        group: groupName,
        time: timeString,
        details: details,
        timestamp: now.getTime()
    };

    if (!currentState.logs) currentState.logs = [];
    currentState.logs.unshift(entry); // Add to top

    // Limit logs to 50
    if (currentState.logs.length > 50) currentState.logs.pop();

    await saveState();

    // If history tab is open, update it
    if (document.getElementById('tab-history') && document.getElementById('tab-history').style.display !== 'none') {
        renderHistory();
    }
}

async function startPosting() {
    const message = document.getElementById('dropi-message').value;
    const groupsToPost = allGroups.filter(g => g.selected).map(g => g.url);

    const minDelay = parseInt(document.getElementById('dropi-min-delay').value) || 10;
    const maxDelay = parseInt(document.getElementById('dropi-max-delay').value) || 40;

    if (!message && (!selectedImageFiles || selectedImageFiles.length === 0)) return alert('Escribe un mensaje o selecciona archivo (Foto/Video)');
    if (groupsToPost.length === 0) return alert('No hay grupos seleccionados');
    if (minDelay >= maxDelay) return alert('El tiempo mínimo debe ser menor al máximo');

    // --- LICENSE CHECK ---
    const licenseStatus = await checkLicenseStatus();
    if (!licenseStatus.canPost) {
        let title = '🚫 Acción Bloqueada';
        let msg = '';

        if (licenseStatus.reason === 'expired_trial') {
            msg = 'Tu periodo de prueba de 5 días ha finalizado.<br>Por favor adquiere una licencia para continuar.';
        } else if (licenseStatus.reason === 'limit_reached') {
            msg = `Has alcanzado el límite de ${licenseStatus.postsLimit} publicaciones mensuales.<br>Actualiza a PRO para publicaciones ilimitadas.`;
        }

        // Crear Modal Personalizado
        const modal = document.createElement('div');
        modal.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:999999; display:flex; align-items:center; justify-content:center; font-family:sans-serif;';
        modal.innerHTML = `
            <div style="background:#18191c; padding:24px; border-radius:12px; border:1px solid rgba(255,255,255,0.1); width:320px; text-align:center; color:white; box-shadow:0 10px 40px rgba(0,0,0,0.5);">
                <div style="font-size:40px; margin-bottom:16px;">🔒</div>
                <h3 style="margin:0 0 8px 0; color:#f87171;">${title}</h3>
                <p style="font-size:13px; color:#ccc; line-height:1.5; margin-bottom:20px;">${msg}</p>
                
                <div style="display:grid; gap:8px;">
                    <a href="https://t.me/programadormillonary" target="_blank" style="text-decoration:none;">
                        <button style="width:100%; padding:10px; background:#229ED9; color:white; border:none; border-radius:6px; cursor:pointer; font-weight:bold;">✈️ Contactar por Telegram</button>
                    </a>
                    <a href="https://wa.me/573176116145" target="_blank" style="text-decoration:none;">
                        <button style="width:100%; padding:10px; background:#25D366; color:white; border:none; border-radius:6px; cursor:pointer; font-weight:bold;">💬 Contactar por WhatsApp</button>
                    </a>
                    <button id="dropi-close-modal" style="width:100%; padding:10px; background:transparent; color:#aaa; border:1px solid #333; border-radius:6px; cursor:pointer; margin-top:8px;">Cerrar</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        document.getElementById('dropi-close-modal').onclick = () => modal.remove();

        return;
    }
    // ---------------------

    const postStrategy = document.getElementById('dropi-post-strategy').value || 'order';
    const deepClean = document.getElementById('dropi-deep-clean').checked;
    const getMessages = document.getElementById('dropi-get-messages').checked;
    const typingSpeed = parseInt(document.getElementById('dropi-typing-speed').value) || 3;
    const uploadSpeed = parseInt(document.getElementById('dropi-upload-speed').value) || 3;

    currentState = {
        isActive: true,
        groups: groupsToPost,
        currentIndex: 0,
        message: message,
        minDelay: minDelay,
        maxDelay: maxDelay,
        waitingForUserClick: false,
        interactionTimeout: null,
        imagesBase64: currentState.imagesBase64 || [],
        imageNames: currentState.imageNames || [],
        imageTypes: currentState.imageTypes || [],
        postStrategy: postStrategy,
        deepClean: deepClean,
        getMessages: getMessages,
        typingSpeed: typingSpeed,
        uploadSpeed: uploadSpeed,
        logs: currentState.logs || []
    };

    // Notificar uso
    notifyAdmin('🤖 Secuencia Iniciada', `Usuario (Plan: ${licenseStatus.tier}) publicando en ${groupsToPost.length} grupos.`);

    if (selectedImageFiles && selectedImageFiles.length > 0) {
        // Limit check
        const totalSize = selectedImageFiles.reduce((acc, f) => acc + f.size, 0);
        if (totalSize > 150 * 1024 * 1024) { // 150MB Total Limit
            return alert('El tamaño total de archivos es demasiado grande (Máx 150MB).');
        }

        // Asumiendo que currentState ya tiene los base64 cargados por handleFileSelect
        if (!currentState.imagesBase64 || currentState.imagesBase64.length === 0) {
            try {
                const base64Promises = selectedImageFiles.map(file => fileToDataURL(file));
                currentState.imagesBase64 = await Promise.all(base64Promises);
                currentState.imageNames = selectedImageFiles.map(f => f.name);
                currentState.imageTypes = selectedImageFiles.map(f => f.type);
            } catch (e) {
                return alert('Error procesando archivos: ' + e.message);
            }
        }
    }

    const saved = await saveState();
    if (!saved) return; // Detener si no se pudo guardar

    updateStatusUI();
    toggleActiveControls(true);

    navigateToGroup(currentState.groups[0]);
}

async function stopPosting() {
    currentState.isActive = false;
    currentState.waitingForUserClick = false;
    if (currentState.interactionTimeout) clearTimeout(currentState.interactionTimeout);
    await saveState();
    updateStatusUI();
    toggleActiveControls(false);
}

async function skipCurrentGroup() {
    if (!currentState.isActive) return;
    const statusText = document.getElementById('dropi-status-text');
    statusText.textContent = 'Saltando grupo...';

    // Log Skip
    const currentGroupUrl = currentState.groups[currentState.currentIndex];
    const groupName = allGroups.find(g => g.url === currentGroupUrl)?.name || 'Grupo Desconocido';
    await logActivity('skip', groupName);

    document.removeEventListener('focusin', onElementFocused, true);
    currentState.currentIndex++;
    await nextGroup();
}

async function saveState() {
    try {
        await chrome.storage.local.set({ [STATE_KEY]: currentState });
        return true;
    } catch (e) {
        console.error('Error saving state', e);
        alert('Error guardando estado: ' + e.message + '\nPosiblemente el archivo es muy pesado.');
        return false;
    }
}

async function restoreState() {
    // Restore Groups
    const groupsData = await chrome.storage.local.get(GROUPS_KEY);
    if (groupsData[GROUPS_KEY]) {
        allGroups = groupsData[GROUPS_KEY];
        renderGroupList();
    }

    // Restore Templates
    const templatesData = await chrome.storage.local.get(TEMPLATES_KEY);
    if (templatesData[TEMPLATES_KEY]) {
        allTemplates = templatesData[TEMPLATES_KEY];
        renderTemplateOptions();
    }

    // Restore State
    const stateData = await chrome.storage.local.get(STATE_KEY);
    if (stateData[STATE_KEY]) {
        currentState = stateData[STATE_KEY];

        const msgInput = document.getElementById('dropi-message');
        if (msgInput && currentState.message) msgInput.value = currentState.message;

        const minInput = document.getElementById('dropi-min-delay');
        const maxInput = document.getElementById('dropi-max-delay');
        if (minInput && currentState.minDelay) minInput.value = currentState.minDelay;
        if (maxInput && currentState.maxDelay) maxInput.value = currentState.maxDelay;

        if (currentState.postStrategy) {
            const strategySelect = document.getElementById('dropi-post-strategy');
            if (strategySelect) strategySelect.value = currentState.postStrategy;
        }

        if (currentState.deepClean !== undefined) {
            const cleanCheck = document.getElementById('dropi-deep-clean');
            if (cleanCheck) cleanCheck.checked = currentState.deepClean;
        }

        if (currentState.getMessages !== undefined) {
            const msgCheck = document.getElementById('dropi-get-messages');
            if (msgCheck) msgCheck.checked = currentState.getMessages;
        }

        if (currentState.typingSpeed) {
            const typingInput = document.getElementById('dropi-typing-speed');
            if (typingInput) {
                typingInput.value = currentState.typingSpeed;
                const labels = ['Muy Lento', 'Lento', 'Normal', 'Rápido', 'Híper'];
                document.getElementById('dropi-typing-speed-val').textContent = labels[currentState.typingSpeed - 1];
            }
        }

        if (currentState.uploadSpeed) {
            const uploadInput = document.getElementById('dropi-upload-speed');
            if (uploadInput) {
                uploadInput.value = currentState.uploadSpeed;
                const labels = ['Muy Lento', 'Lento', 'Seguro', 'Rápido', 'Instantáneo'];
                document.getElementById('dropi-upload-speed-val').textContent = labels[currentState.uploadSpeed - 1];
            }
        }

        if (currentState.imagesBase64 && currentState.imagesBase64.length > 0) {
            selectedImageFiles = currentState.imagesBase64.map((b64, i) =>
                dataURLtoFile(b64, currentState.imageNames[i] || `file${i}`)
            );
            renderImageThumbnails();
        }

        updateStatusUI();
        toggleActiveControls(currentState.isActive);

        if (currentState.isActive) {
            setTimeout(waitForUserInteraction, 1000);
        }
    }

    // Restore Schedule
    await checkScheduleStatus();
}

async function checkScheduleStatus() {
    const data = await chrome.storage.local.get(SCHEDULE_KEY);
    const schedule = data[SCHEDULE_KEY];
    const statusDiv = document.getElementById('dropi-schedule-status');
    const displaySpan = document.getElementById('dropi-schedule-display');
    const timeInput = document.getElementById('dropi-schedule-time');

    if (schedule && schedule.time > Date.now()) {
        const date = new Date(schedule.time);
        if (displaySpan) displaySpan.textContent = date.toLocaleString();
        if (statusDiv) statusDiv.style.display = 'block';
        if (timeInput) timeInput.value = ''; // Clear input as it's already set
    } else {
        if (statusDiv) statusDiv.style.display = 'none';
        if (schedule) {
            // Expired but not run? clean up
            await chrome.storage.local.remove(SCHEDULE_KEY);
        }
    }
}

async function saveSchedule() {
    const timeInput = document.getElementById('dropi-schedule-time');
    if (!timeInput || !timeInput.value) return alert('Selecciona una fecha y hora.');

    const targetTime = new Date(timeInput.value).getTime();
    if (targetTime < Date.now()) return alert('La fecha debe ser en el futuro.');

    // Validations same as startPosting
    const message = document.getElementById('dropi-message').value;
    const groupsToPost = allGroups.filter(g => g.selected).map(g => g.url);
    const minDelay = parseInt(document.getElementById('dropi-min-delay').value) || 10;
    const maxDelay = parseInt(document.getElementById('dropi-max-delay').value) || 40;

    if (!message && (!selectedImageFiles || selectedImageFiles.length === 0)) return alert('Escribe un mensaje o selecciona archivo.');
    if (groupsToPost.length === 0) return alert('No hay grupos seleccionados.');

    let imagesBase64 = [];
    let imageNames = [];
    let imageTypes = [];

    if (selectedImageFiles && selectedImageFiles.length > 0) {
        if (selectedImageFiles.reduce((acc, f) => acc + f.size, 0) > 150 * 1024 * 1024) return alert('Archivos muy pesados (Máx 150MB Total).');
        try {
            const base64Promises = selectedImageFiles.map(file => fileToDataURL(file));
            imagesBase64 = await Promise.all(base64Promises);
            imageNames = selectedImageFiles.map(f => f.name);
            imageTypes = selectedImageFiles.map(f => f.type);
        } catch (e) { return alert('Error procesando imágenes.'); }
    }

    const scheduleData = {
        time: targetTime,
        config: {
            message,
            groups: groupsToPost,
            minDelay,
            maxDelay,
            imageBase64: null, // Deprecated in config? No, keep structure consistent or null
            imageName: null,
            imageType: null,
            imagesBase64, // New Arrays
            imageNames,
            imageTypes,
            postStrategy: document.getElementById('dropi-post-strategy').value || 'order',
            deepClean: document.getElementById('dropi-deep-clean').checked,
            getMessages: document.getElementById('dropi-get-messages').checked,
            typingSpeed: parseInt(document.getElementById('dropi-typing-speed').value) || 3,
            uploadSpeed: parseInt(document.getElementById('dropi-upload-speed').value) || 3
        }
    };

    await chrome.storage.local.set({ [SCHEDULE_KEY]: scheduleData });
    alert('✅ Programación Guardada para: ' + new Date(targetTime).toLocaleString());

    checkScheduleStatus();
}

async function cancelSchedule() {
    if (confirm('¿Cancelar programación?')) {
        await chrome.storage.local.remove(SCHEDULE_KEY);
        checkScheduleStatus();
    }
}

// Escuchar mensajes del background para Auto-Start
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'EXECUTE_SCHEDULE') {
        const data = request.data;
        console.log('🤖 Ejecutando Programación...', data);
        executeScheduledPost(data);
    }
});

async function executeScheduledPost(scheduleConfig) {
    if (currentState.isActive) return; // Already running

    // 1. Populate State
    currentState = {
        isActive: true,
        groups: scheduleConfig.groups,
        currentIndex: 0,
        message: scheduleConfig.message,
        minDelay: scheduleConfig.minDelay,
        maxDelay: scheduleConfig.maxDelay,
        waitingForUserClick: false,
        interactionTimeout: null,
        imagesBase64: scheduleConfig.imagesBase64 || (scheduleConfig.imageBase64 ? [scheduleConfig.imageBase64] : []),
        imageNames: scheduleConfig.imageNames || (scheduleConfig.imageName ? [scheduleConfig.imageName] : []),
        imageTypes: scheduleConfig.imageTypes || (scheduleConfig.imageType ? [scheduleConfig.imageType] : []),
        postStrategy: scheduleConfig.postStrategy || 'order',
        deepClean: scheduleConfig.deepClean || false,
        getMessages: scheduleConfig.getMessages || false,
        typingSpeed: scheduleConfig.typingSpeed || 3,
        uploadSpeed: scheduleConfig.uploadSpeed || 3,
        logs: currentState.logs || []
    };

    await saveState();

    // 2. Populate UI (Visual feedback if user is watching)
    const msgInput = document.getElementById('dropi-message');
    if (msgInput) msgInput.value = currentState.message;

    // ... we could populate image preview too but not strictly necessary for logic

    // 3. Start
    updateStatusUI();
    toggleActiveControls(true);
    navigateToGroup(currentState.groups[0]);


}

async function waitForUserInteraction() {
    if (!currentState.isActive) return;
    currentState.waitingForUserClick = true;
    updateStatusUI();

    // NEW: Timeout de 2 minutos para saltar si no hay interacción manual
    if (currentState.interactionTimeout) clearTimeout(currentState.interactionTimeout);
    currentState.interactionTimeout = setTimeout(async () => {
        if (currentState.isActive && currentState.waitingForUserClick) {
            console.log('⏰ Timeout: No hubo interacción manual en 2 minutos. Saltando grupo...');
            const statusText = document.getElementById('dropi-status-text');
            if (statusText) statusText.textContent = '⏰ Tiempo agotado. Saltando...';

            document.removeEventListener('focusin', onElementFocused, true);
            currentState.waitingForUserClick = false;

            // Log Skip
            const currentGroupUrl = currentState.groups[currentState.currentIndex];
            const groupName = allGroups.find(g => g.url === currentGroupUrl)?.name || 'Grupo Desconocido';
            await logActivity('skip', groupName, 'Tiempo de espera agotado (2min)');

            currentState.currentIndex++;
            await nextGroup();
        }
    }, 120000); // 120 segundos

    // Listener manual por si falla el automático (Backup)
    document.addEventListener('focusin', onElementFocused, true);

    const statusText = document.getElementById('dropi-status-text');
    if (statusText) statusText.textContent = 'Buscando campo de escritura...';

    // Esperar un momento para asegurar que la interfaz de FB cargó
    await sleep(2000);

    // 1. Estrategia Principal: Clases específicas (Usuario - Actualizado)
    // Buscamos el contenedor que tiene el texto "Escribe algo..."
    let trigger = null;
    const candidates = document.querySelectorAll('.xi81zsa.x1lkfr7t.xkjl1po.x1mzt3pk.xh8yej3.x13faqbe');

    for (const candidate of candidates) {
        if (candidate.textContent.includes('Escribe algo...')) {
            trigger = candidate;
            break;
        }
    }

    // 2. Estrategia Secundaria: Búsqueda por Texto (Múltiples Variaciones)
    if (!trigger) {
        const validTexts = [
            'Escribe algo...',
            'Crea una publicación pública...', // Variación detectada en Cuenta B
            'Crea una publicación...',
            'Write something...',
            'Create a public post...',
            '¿Qué estás pensando?',
            'Vender algo'
        ];

        const allSpans = Array.from(document.querySelectorAll('span, div'));
        // Usamos includes para ser más flexibles, pero verificamos que no sea un texto muy largo
        const textElement = allSpans.find(el =>
            validTexts.some(t => el.textContent.trim() === t || (el.textContent.includes(t) && el.textContent.length < 50))
        );

        if (textElement) {
            trigger = textElement.closest('div[role="button"]') || textElement.closest('div');
        }
    }

    // 3. Estrategia Terciaria: Atributos de Accesibilidad
    if (!trigger) {
        const ariaLabels = [
            'Crear una publicación',
            'Crea una publicación pública',
            'Create a post',
            'Create a public post',
            'Write something'
        ];
        // Construir selector OR para todos los labels
        const selector = ariaLabels.map(l => `div[aria-label*="${l}"]`).join(', ');
        trigger = document.querySelector(selector);
    }

    if (trigger) {
        console.log('🤖 Auto-Click: Disparador encontrado.', trigger);
        trigger.click();

        if (statusText) statusText.textContent = 'Abriendo editor...';

        // Esperar a que aparezca el modal con el editor real
        // FIX: Buscamos específicamente DENTRO de un dialog (modal) para evitar cajas de comentarios del feed
        const postModalSelector = 'div[role="dialog"] div[contenteditable="true"][role="textbox"]';
        const editable = await waitForElement(postModalSelector, 8000);

        if (editable) {
            // FIX: Evitar doble ejecución (Race Condition) si el listener de foco ya capturó el evento
            if (!currentState.waitingForUserClick) {
                console.log('🤖 Race Condition: onElementFocused ya inició la secuencia.');
                return;
            }

            console.log('🤖 Auto-Click: Editor de POST abierto exitosamente.');

            // Limpiar timeout de espera manual
            if (currentState.interactionTimeout) clearTimeout(currentState.interactionTimeout);

            currentState.waitingForUserClick = false;
            updateStatusUI();

            // Limpiar listener manual para evitar doble ejecución
            document.removeEventListener('focusin', onElementFocused, true);

            // Pequeña pausa para estabilidad del foco
            await sleep(1000);
            await executePostSequence(editable);
        } else {
            console.warn('🤖 Auto-Click: No se detectó el editor tras el click.');
            if (statusText) statusText.textContent = '⚠️ Haz CLICK manual en el campo...';
        }
    } else {
        console.warn('🤖 Auto-Click: No se encontró el disparador inicial.');
        if (statusText) statusText.textContent = '⚠️ Haz CLICK manual en "Crea una publicación..."';
    }
}

async function onElementFocused(e) {
    if (!currentState.isActive || !currentState.waitingForUserClick) return;
    const target = e.target;
    const isEditable = target.isContentEditable || target.tagName === 'TEXTAREA' || (target.tagName === 'INPUT' && target.type === 'text');
    if (target.closest('#dropi-container')) return;

    if (isEditable) {
        // Limpiar timeout de espera manual
        if (currentState.interactionTimeout) clearTimeout(currentState.interactionTimeout);

        currentState.waitingForUserClick = false;
        updateStatusUI();
        document.removeEventListener('focusin', onElementFocused, true);
        await executePostSequence(target);
    }
}

async function executePostSequence(inputElement) {
    const statusText = document.getElementById('dropi-status-text');
    statusText.textContent = 'Escribiendo...';

    const currentGroupUrl = currentState.groups[currentState.currentIndex];
    const groupName = allGroups.find(g => g.url === currentGroupUrl)?.name || 'Grupo Desconocido';

    try {
        if (currentState.message) {
            inputElement.focus();
            await sleep(500); // Asegurar foco

            const finalMessage = processSpintax(currentState.message);

            // Ajustar velocidad de escritura por CARÁCTER
            // 1: 250ms, 2: 120ms, 3: 60ms, 4: 25ms, 5: 5ms
            const charSpeedMap = [250, 120, 60, 25, 5];
            const typingDelay = charSpeedMap[(currentState.typingSpeed || 3) - 1];

            console.log(`✍️ Escribiendo mensaje (${finalMessage.length} caracteres) a velocidad ${typingDelay}ms/char`);

            const lines = finalMessage.split('\n');
            for (let i = 0; i < lines.length; i++) {
                if (!currentState.isActive) break;

                // Pegar la línea completa de una vez
                if (lines[i].length > 0) {
                    document.execCommand('insertText', false, lines[i]);
                }

                // Si no es la última línea, insertar salto de línea simulando Enter
                if (i < lines.length - 1) {
                    const keyEvent = new KeyboardEvent('keydown', {
                        bubbles: true, cancelable: true, view: window,
                        keyCode: 13, which: 13, code: 'Enter', key: 'Enter', shiftKey: true
                    });
                    inputElement.dispatchEvent(keyEvent);
                    document.execCommand('insertText', false, '\n');
                }

                // Disparar evento de input para que Facebook detecte el cambio
                inputElement.dispatchEvent(new Event('input', { bubbles: true }));

                // Pequeña pausa opcional entre líneas para estabilidad, aunque sea "instantáneo"
                await sleep(100);
            }
        }

        if (selectedImageFiles && selectedImageFiles.length > 0) {
            let filesToUpload = [...selectedImageFiles];
            const strategy = currentState.postStrategy || 'order';

            if (strategy === 'single_random' && selectedImageFiles.length > 1) {
                // Modo antiguo: elegir solo una al azar
                const randomIndex = Math.floor(Math.random() * selectedImageFiles.length);
                filesToUpload = [selectedImageFiles[randomIndex]];
                console.log(`🎲 Imagen Única Aleatoria: ${filesToUpload[0].name}`);
            } else if (strategy === 'random') {
                // Mezclar el array de archivos (Shuffle)
                for (let i = filesToUpload.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [filesToUpload[i], filesToUpload[j]] = [filesToUpload[j], filesToUpload[i]];
                }
                console.log(`🎲 Orden Aleatorio Aplicado a ${filesToUpload.length} archivos`);
            } else {
                console.log(`📋 Publicando en Orden: ${filesToUpload.length} archivos`);
            }

            statusText.textContent = `Subiendo ${filesToUpload.length} archivo(s)...`;

            if (currentState.deepClean) {
                statusText.textContent = `🧹 Modo Ninja: Limpiando metadatos...`;
                const cleanedFiles = [];
                for (const file of filesToUpload) {
                    cleanedFiles.push(await cleanImageMetadata(file));
                }
                filesToUpload = cleanedFiles;
            }

            await uploadMediaToElement(inputElement, filesToUpload);

            // Ajustar espera según la velocidad configurada
            // Multiplicadores: 1: 2.5x, 2: 1.5x, 3: 1x, 4: 0.7x, 5: 0.4x
            const uploadSpeedMap = [2.5, 1.5, 1, 0.7, 0.4];
            const waitMultiplier = uploadSpeedMap[(currentState.uploadSpeed || 3) - 1];

            const isVideo = filesToUpload.some(f => f.type.startsWith('video/'));
            const baseWait = isVideo ? 15000 : 6000;
            const perFileWait = isVideo ? 5000 : 1000;
            const calculatedWait = (baseWait + (filesToUpload.length * perFileWait)) * waitMultiplier;
            await sleep(Math.min(calculatedWait, 60000)); // Cap at 60s
        }

        // --- NUEVO: Botón Messenger (Recibir Mensajes) ---
        if (currentState.getMessages) {
            statusText.textContent = 'Añadiendo botón Messenger...';
            try {
                const searchMessengerBtn = async () => {
                    const labels = ['Recibir mensajes', 'Get messages', 'Get Messages', 'Send messenger message'];
                    for (const label of labels) {
                        const btn = document.querySelector(`div[aria-label*="${label}"]`);
                        if (btn) return btn;
                    }
                    return null;
                };

                let messengerBtn = await searchMessengerBtn();

                if (!messengerBtn) {
                    const moreBtn = document.querySelector('div[aria-label="Más"], div[aria-label="More"]');
                    if (moreBtn) {
                        moreBtn.click();
                        await sleep(1000);
                        messengerBtn = await searchMessengerBtn();
                    }
                }

                if (messengerBtn) {
                    messengerBtn.click();
                    console.log('✅ Botón "Recibir mensajes" activado.');
                    await sleep(2000);
                } else {
                    console.warn('⚠️ No se encontró el botón de Messenger.');
                }
            } catch (err) {
                console.error('Error activando botón Messenger:', err);
            }
        }
        // ------------------------------------------------

        statusText.textContent = 'Buscando botón Publicar...';
        await sleep(2000);

        const postBtnSelector = 'div[aria-label="Publicar"]';
        const postBtn = await waitForElement(postBtnSelector, 5000);

        if (postBtn) {
            let attempts = 0;
            while (postBtn.getAttribute('aria-disabled') === 'true' && attempts < 8) {
                await sleep(1000);
                attempts++;
            }
            if (postBtn.getAttribute('aria-disabled') !== 'true') {
                statusText.textContent = 'Publicando...';
                postBtn.click();

                // Log Success
                await logActivity('success', groupName);
                await incrementPostCounter(); // Count usage

                await sleep(5000);
                currentState.currentIndex++;
                await nextGroup();
                return;
            }
        }
        throw new Error('Botón no activo');
    } catch (e) {
        console.error(e);
        statusText.textContent = 'Error. Saltando...';

        // Log Error
        await logActivity('error', groupName);

        await sleep(3000);
        currentState.currentIndex++;
        await nextGroup();
    }
}

async function nextGroup() {
    if (currentState.currentIndex >= currentState.groups.length) {
        alert('¡Secuencia finalizada!');
        stopPosting();
    } else {
        await saveState();

        const min = currentState.minDelay || 10;
        const max = currentState.maxDelay || 40;
        const randomSeconds = Math.floor(Math.random() * (max - min + 1) + min);
        const delayMs = randomSeconds * 1000;

        let remaining = randomSeconds;
        const interval = setInterval(() => {
            remaining--;
            const statusText = document.getElementById('dropi-status-text');
            if (statusText) statusText.textContent = `Siguiente en ${remaining}s (Aleatorio)...`;
            if (remaining <= 0) clearInterval(interval);
        }, 1000);

        setTimeout(() => {
            navigateToGroup(currentState.groups[currentState.currentIndex]);
        }, delayMs);
    }
}

function navigateToGroup(url) { window.location.href = url; }

function uploadMediaToElement(targetElement, files) {
    const dropEvent = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: new DataTransfer() });

    if (Array.isArray(files)) {
        files.forEach(f => dropEvent.dataTransfer.items.add(f));
    } else {
        dropEvent.dataTransfer.items.add(files);
    }

    targetElement.dispatchEvent(dropEvent);
    const parent = targetElement.closest('[role="dialog"]') || targetElement.parentElement;
    if (parent) parent.dispatchEvent(dropEvent);
}
