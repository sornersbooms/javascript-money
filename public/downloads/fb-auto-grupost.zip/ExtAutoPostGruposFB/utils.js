// utils.js
function processSpintax(text) {
    if (!text) return '';
    let processed = text;

    // Auto-insert newline between consecutive spintax blocks (adjacent or with spaces): "{A} {B}" -> "{A}\n{B}"
    if (processed) {
        processed = processed.replace(/\}\s*\{/g, '}\n{');
    }

    let hasSpintax = true;

    while (hasSpintax) {
        let matchFound = false;
        processed = processed.replace(/\{([^{}]+)\}/g, (match, content) => {
            matchFound = true;
            const options = content.split('|');
            const randomIndex = Math.floor(Math.random() * options.length);
            return options[randomIndex];
        });

        if (!matchFound) hasSpintax = false;
    }

    return processed;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function waitForElement(selector, timeout = 5000) {
    return new Promise(resolve => {
        if (document.querySelector(selector)) return resolve(document.querySelector(selector));
        const observer = new MutationObserver(() => {
            if (document.querySelector(selector)) {
                observer.disconnect();
                resolve(document.querySelector(selector));
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
        setTimeout(() => { observer.disconnect(); resolve(null); }, timeout);
    });
}

function fileToDataURL(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) { u8arr[n] = bstr.charCodeAt(n); }
    return new File([u8arr], filename, { type: mime });
}
async function cleanImageMetadata(file) {
    const newName = `media_${Date.now()}_${Math.floor(Math.random() * 10000)}.${file.name.split('.').pop()}`;

    if (!file.type.startsWith('image/')) {
        // Para videos, solo podemos renombrarlos (creando un nuevo objeto File)
        return new File([file], newName, { type: file.type });
    }

    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            // Slight variation: add 1-2 pixels to dimension or keep same but redraw
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);

            // Export as new blob/file - this strips all metadata (EXIF)
            canvas.toBlob((blob) => {
                const cleanedFile = new File([blob], newName, { type: 'image/jpeg' });
                resolve(cleanedFile);
            }, 'image/jpeg', 0.92);
        };
        img.onerror = () => resolve(new File([file], newName, { type: file.type }));
        img.src = URL.createObjectURL(file);
    });
}
