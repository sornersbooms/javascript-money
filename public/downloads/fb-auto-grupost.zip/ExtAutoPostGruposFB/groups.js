// groups.js

async function handleRemoteExtraction() {
    const btn = document.getElementById('dropi-extract-btn');
    const statusText = document.getElementById('dropi-status-text');

    if (window.location.href.includes('/groups/joins') || window.location.href.includes('/groups/?category=membership')) {
        await extractFromCurrentPage(btn, statusText);
        return;
    }

    btn.textContent = '🕵️ Escaneando...';
    btn.disabled = true;
    statusText.textContent = 'Modo Silencioso: Buscando grupos...';

    try {
        const groupsFound = await extractGroupsViaIframe();

        if (!groupsFound || groupsFound.length === 0) {
            throw new Error('No se encontraron grupos en el escaneo silencioso.');
        }

        const accountInfo = getCurrentAccountInfo();
        const existingMap = new Map(allGroups.map(g => [g.url, g]));
        let newCount = 0;

        groupsFound.forEach(g => {
            if (!existingMap.has(g.url)) {
                g.accountId = accountInfo.id;
                g.accountName = accountInfo.name;
                existingMap.set(g.url, g);
                newCount++;
            } else {
                // Update account info if missing OR if ID matches (to update name)
                const existing = existingMap.get(g.url);
                if (!existing.accountId || existing.accountId === accountInfo.id) {
                    existing.accountId = accountInfo.id;
                    existing.accountName = accountInfo.name;
                }
            }
        });

        allGroups = Array.from(existingMap.values());
        saveGroupsToStorage();
        renderGroupList();

        btn.innerHTML = '📡 Escanear Grupos';
        btn.disabled = false;
        statusText.textContent = `¡${newCount} nuevos, ${allGroups.length} total!`;
        alert(`Proceso finalizado.\nTotal grupos: ${allGroups.length}\nNuevos añadidos: ${newCount}`);

    } catch (e) {
        console.error('Error en extracción remota:', e);
        if (confirm('El escaneo silencioso no pudo completar la tarea (posible bloqueo de seguridad). ¿Quieres ir a la página de "Mis Grupos" para escanearlos manualmente?')) {
            window.location.href = 'https://www.facebook.com/groups/joins/?category=membership';
        } else {
            btn.innerHTML = '📡 Escanear Grupos';
            btn.disabled = false;
            statusText.textContent = 'Escaneo cancelado.';
        }
    }
}

async function extractFromCurrentPage(btn, statusText) {
    btn.textContent = '⬇️ Bajando...';
    btn.disabled = true;
    statusText.textContent = 'Desplazando para cargar todos los grupos...';

    let previousHeight = 0;
    let noChangeCount = 0;
    const maxScrolls = 30;

    for (let i = 0; i < maxScrolls; i++) {
        window.scrollTo(0, document.body.scrollHeight);
        await sleep(1500);

        const currentHeight = document.body.scrollHeight;
        if (currentHeight === previousHeight) {
            noChangeCount++;
            if (noChangeCount >= 3) break;
        } else {
            noChangeCount = 0;
            previousHeight = currentHeight;
            statusText.textContent = `Cargando... (Página ${i + 1})`;
        }
    }

    const groups = parseGroupsFromDOM(document);

    if (groups.length === 0) {
        btn.innerHTML = '📡 Escanear Grupos';
        btn.disabled = false;
        statusText.textContent = 'No se encontraron grupos. Intenta de nuevo.';
        alert('No se encontraron grupos. Asegúrate de estar en la pestaña "Tus grupos".');
        return;
    }

    const accountInfo = getCurrentAccountInfo();
    const existingMap = new Map(allGroups.map(g => [g.url, g]));
    let newCount = 0;

    groups.forEach(g => {
        if (!existingMap.has(g.url)) {
            g.accountId = accountInfo.id;
            g.accountName = accountInfo.name;
            existingMap.set(g.url, g);
            newCount++;
        } else {
            const existing = existingMap.get(g.url);
            if (!existing.accountId || existing.accountId === accountInfo.id) {
                existing.accountId = accountInfo.id;
                existing.accountName = accountInfo.name;
            }
        }
    });

    allGroups = Array.from(existingMap.values());
    saveGroupsToStorage();
    renderGroupList();

    btn.innerHTML = '📡 Escanear Grupos';
    btn.disabled = false;
    statusText.textContent = `¡${newCount} nuevos, ${allGroups.length} total!`;
    alert(`Proceso finalizado.\nTotal grupos: ${allGroups.length}\nNuevos añadidos: ${newCount}`);
}

function extractGroupsViaIframe() {
    return new Promise((resolve, reject) => {
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = 'https://mbasic.facebook.com/groups/?seemore';
        document.body.appendChild(iframe);

        const timeout = setTimeout(() => {
            if (document.body.contains(iframe)) document.body.removeChild(iframe);
            reject(new Error('Timeout esperando a Facebook'));
        }, 20000);

        iframe.onload = async () => {
            try {
                await sleep(2000);
                const iDoc = iframe.contentDocument || iframe.contentWindow.document;
                if (!iDoc) throw new Error('Bloqueo de seguridad (CORS)');

                const anchors = Array.from(iDoc.querySelectorAll('a[href*="/groups/"]'));
                const uniqueGroups = new Map();

                anchors.forEach(a => {
                    const href = a.getAttribute('href');
                    const match = href.match(/\/groups\/([a-zA-Z0-9.]+)/);

                    if (match && !href.includes('create') && !href.includes('category')) {
                        const groupId = match[1];
                        const cleanUrl = `https://www.facebook.com/groups/${groupId}/`;
                        const name = a.textContent.trim();

                        if (name && name.length > 2 && !uniqueGroups.has(cleanUrl)) {
                            uniqueGroups.set(cleanUrl, { url: cleanUrl, name: name, selected: true });
                        }
                    }
                });

                clearTimeout(timeout);
                document.body.removeChild(iframe);
                resolve(Array.from(uniqueGroups.values()));

            } catch (err) {
                clearTimeout(timeout);
                if (document.body.contains(iframe)) document.body.removeChild(iframe);
                console.warn('Fallo mbasic, error:', err);
                reject(err);
            }
        };

        iframe.onerror = () => {
            clearTimeout(timeout);
            if (document.body.contains(iframe)) document.body.removeChild(iframe);
            reject(new Error('Error de carga en Iframe'));
        };
    });
}

function parseGroupsFromDOM(doc) {
    const anchors = Array.from(doc.querySelectorAll('a[href*="/groups/"]'));
    const uniqueGroups = new Map();

    anchors.forEach(a => {
        const href = a.href;
        const match = href.match(/\/groups\/([a-zA-Z0-9.]+)\/?/);

        if (match && !href.includes('/create/') && !href.includes('/feed/') && !href.includes('/discover/') && !href.includes('/category/')) {
            let name = a.innerText || a.textContent;
            if (!name || name.trim().length === 0) name = a.getAttribute('aria-label');
            if (!name || name.trim().length === 0) {
                const img = a.querySelector('img');
                if (img) name = img.getAttribute('alt');
            }
            if (name) name = name.trim();

            const invalidNames = ['Ver más', 'Unirte', 'Invitar', 'Editar', 'Abandonar', 'Reportar', 'Miembros', 'Amigos'];

            if (name && name.length > 2 && !invalidNames.includes(name)) {
                const cleanUrl = `https://www.facebook.com/groups/${match[1]}/`;
                if (uniqueGroups.has(cleanUrl)) {
                    const existing = uniqueGroups.get(cleanUrl);
                    if (name.length > existing.name.length && !name.includes('miembros') && !name.includes('publicaciones')) existing.name = name;
                } else {
                    if (!name.includes('miembros') && !name.includes('publicaciones')) {
                        uniqueGroups.set(cleanUrl, { url: cleanUrl, name: name.substring(0, 60), selected: true });
                    }
                }
            }
        }
    });
    return Array.from(uniqueGroups.values());
}

function renderGroupList() {
    const listContainer = document.getElementById('dropi-group-list');
    const searchTerm = document.getElementById('dropi-search').value.toLowerCase();
    const accountFilter = document.getElementById('dropi-account-filter');
    const selectedAccount = accountFilter ? accountFilter.value : 'all';

    // Update Account Filter Options
    if (accountFilter) {
        const currentSelection = accountFilter.value;
        const accounts = new Set();
        allGroups.forEach(g => {
            if (g.accountName) accounts.add(JSON.stringify({ name: g.accountName, id: g.accountId }));
        });

        let optionsHTML = '<option value="all">🌐 Todas las Cuentas</option>';
        accounts.forEach(accStr => {
            const acc = JSON.parse(accStr);
            const value = acc.id || 'unknown';
            const label = acc.name || 'Desconocido';
            optionsHTML += `<option value="${value}">${label}</option>`;
        });

        // Only update innerHTML if options have changed to avoid losing selection
        if (accountFilter.innerHTML !== optionsHTML) {
            accountFilter.innerHTML = optionsHTML;
            accountFilter.value = currentSelection; // Restore selection if possible
            if (accountFilter.value !== currentSelection) accountFilter.value = 'all'; // Fallback
        }
    }

    listContainer.innerHTML = '';

    if (allGroups.length === 0) {
        listContainer.innerHTML = '<div class="dropi-empty-state">Sin datos.</div>';
        return;
    }

    let visibleCount = 0;
    let selectedCount = 0;

    allGroups.forEach((group, index) => {
        // Filter by Search Term
        const matchesSearch = group.name.toLowerCase().includes(searchTerm);

        // Filter by Account
        const matchesAccount = selectedAccount === 'all' || group.accountId === selectedAccount;

        if (matchesSearch && matchesAccount) {
            visibleCount++;
            if (group.selected) selectedCount++;

            const item = document.createElement('div');
            item.className = `dropi-group-item ${group.selected ? 'selected' : ''}`;
            item.onclick = () => toggleGroupSelection(index);

            const accountLabel = group.accountName ? `<span style="font-size:9px; color:#aaa; display:block;">👤 ${group.accountName}</span>` : '';

            item.innerHTML = `
        <div class="dropi-checkbox">
          ${group.selected ? '✓' : ''}
        </div>
        <div class="dropi-group-name" title="${group.name}">
            ${group.name}
            ${accountLabel}
        </div>
      `;

            listContainer.appendChild(item);
        }
    });

    document.getElementById('dropi-selected-count').textContent = `${selectedCount} seleccionados`;
}

function toggleGroupSelection(index) {
    allGroups[index].selected = !allGroups[index].selected;
    saveGroupsToStorage();
    renderGroupList();
}

function toggleAllSelection(select) {
    const searchTerm = document.getElementById('dropi-search').value.toLowerCase();
    const accountFilter = document.getElementById('dropi-account-filter');
    const selectedAccount = accountFilter ? accountFilter.value : 'all';

    allGroups.forEach(group => {
        const matchesSearch = group.name.toLowerCase().includes(searchTerm);
        const matchesAccount = selectedAccount === 'all' || group.accountId === selectedAccount;

        if (matchesSearch && matchesAccount) {
            group.selected = select;
        }
    });
    saveGroupsToStorage();
    renderGroupList();
}

function filterGroups() {
    renderGroupList();
}

async function saveGroupsToStorage() {
    await chrome.storage.local.set({ [GROUPS_KEY]: allGroups });
}
