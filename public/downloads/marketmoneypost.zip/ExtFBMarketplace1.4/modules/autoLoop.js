window.DropiApp = window.DropiApp || {};

/**
 * Módulo de Auto-Loop (Ciclo Infinito de Publicación)
 * Se encarga de reiniciar el ciclo cuando detecta la página de "Crear nuevo item".
 * Flujo: Detectar URL -> Avanzar Producto -> Esperar -> Rellenar.
 */
window.DropiApp.AutoLoop = {

    monitorInterval: null,
    isProcessing: false,
    lastUrl: '',

    init() {
        console.log('[DropiLoop] 🔄 Inicializando Monitor de Bucle (SPA)...');

        // Evitar duplicados
        if (this.monitorInterval) clearInterval(this.monitorInterval);

        // Monitor activo cada 1 segundo (Para detectar cambios de URL sin recarga)
        this.monitorInterval = setInterval(() => {
            this.checkLoopCondition();
        }, 1000);
    },

    checkLoopCondition() {
        // 1. Verificar Activación (Por defecto ON si es nulo)
        let isEnabled = localStorage.getItem('dropi_loop_enabled');
        if (isEnabled === null) {
            isEnabled = 'true';
            localStorage.setItem('dropi_loop_enabled', 'true');
        }

        if (isEnabled !== 'true') return;

        // 2. Verificar URL correcta
        const currentUrl = window.location.href;
        const isCreatePage = currentUrl.includes('/marketplace/create/item');

        // Si cambiamos de URL, reseteamos el flag de bloqueo
        if (currentUrl !== this.lastUrl) {
            this.lastUrl = currentUrl;
            this.isProcessing = false; // Nueva página = Nuevo intento permitido
            console.log('[DropiLoop] 📍 Nueva URL detectada. Estado desbloqueado.');
        }

        // 3. Ejecutar SOLO si es la página correcta y NO estamos procesando ya
        if (isCreatePage && !this.isProcessing) {
            this.startCycle();
        }
    },

    startCycle() {
        if (this.isProcessing) return; // Doble check
        this.isProcessing = true;
        console.log('[DropiLoop] 🟢 Detectada página de creación. Esperando estabilidad (5s)...');

        // Aumentamos espera inicial a 5 segundos para asegurar que no es una carga transitoria
        setTimeout(() => {
            // Verificar si seguimos en la misma página y el usuario no canceló
            if (window.location.href.includes('/marketplace/create/item') && localStorage.getItem('dropi_loop_enabled') === 'true') {
                this.triggerNextProduct();
            } else {
                this.isProcessing = false; // Falsa alarma o cancelación
            }
        }, 5000);
    },

    triggerNextProduct() {
        // CANDADO 1: Si estamos llenando activamente, NO INTERRUMPIR
        if (window.DROPI_IS_FILLING) {
            console.warn('[DropiLoop] ⛔ AutoLoop detenido: Automatización en curso.');
            return;
        }

        // CANDADO 2: Solo permitir avanzar si estamos en la ruta exacta de creación
        if (!window.location.href.includes('/marketplace/create/item')) {
            console.warn('[DropiLoop] ⛔ Intento de avance bloqueado: No estamos en /create/item.');
            this.isProcessing = false;
            return;
        }

        const nextBtn = document.getElementById('dropi-next-btn');
        if (nextBtn) {
            console.log('[DropiLoop] ▶️ Moviendo al siguiente producto...');
            nextBtn.click();

            // Esperar 3 segundos para que la UI termine de cambiar de producto visualmente
            setTimeout(() => {
                this.scheduleFill();
            }, 3000);
        } else {
            console.warn('[DropiLoop] ⚠️ Botón Siguiente no listo. Reintentando...');
            setTimeout(() => this.triggerNextProduct(), 2000);
        }
    },

    scheduleFill() {
        console.log('[DropiLoop] ⏳ Esperando 5 segundos para "Rellenar Datos"...');

        setTimeout(() => {
            if (localStorage.getItem('dropi_loop_enabled') !== 'true') return;

            const fillBtn = document.getElementById('dropi-fill-btn');
            if (fillBtn) {
                console.log('[DropiLoop] 🚀 ¡DISPARANDO RELLENADO!');
                fillBtn.click();
            } else {
                console.error('[DropiLoop] ❌ No se encontró el botón de rellenar.');
                this.isProcessing = false;
            }
        }, 5000);
    }
};
