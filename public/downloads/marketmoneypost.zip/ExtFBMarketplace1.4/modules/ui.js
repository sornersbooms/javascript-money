
window.DropiApp = window.DropiApp || {};

window.DropiApp.UI = {
    init() {
        if (document.getElementById('dropi-extension-root')) return;
        this.createDOM();
        this.bindEvents();
        this.makeDraggable();
        this.render();
    },

    createDOM() {
        const root = document.createElement('div');
        root.id = 'dropi-extension-root';
        root.innerHTML = `
            <div id="dropi-extension-card" class="glass-panel">
                <!-- HEADER -->
                <div id="dropi-header">
                    <div class="dropi-brand">
                        <span class="dropi-logo-icon">⚡</span>
                        <h1 id="dropi-title">AutoPublicador <span class="pro-badge">...</span></h1>
                        <div id="dropi-expire-warning" class="expire-warning" style="display:none;">⚠️ Expira en 3 días</div>
                    </div>
                    <div class="dropi-window-controls">
                        <button id="dropi-minimize-btn" class="dropi-icon-btn" title="Minimizar">_</button>
                    </div>
                </div>
                
                <!-- TABS -->
                <div id="dropi-tabs">
                    <div class="dropi-tab active" data-tab="publisher">
                        <span class="tab-icon">📢</span> Publicador
                    </div>
                    <div class="dropi-tab" data-tab="extractor">
                        <span class="tab-icon">🕷️</span> Extraer
                    </div>
                    <div class="dropi-tab" data-tab="license">
                        <span class="tab-icon">🔑</span> Licencia
                    </div>
                </div>

                <!-- CONTENT WRAPPER -->
                <div class="dropi-content-body">
                    
                    <!-- === PUBLISHER SECTION === -->
                    <div id="dropi-content-publisher">
                        <div id="dropi-file-section" class="dropi-section">
                            <label for="dropi-file-input" class="dropi-upload-area">
                                <span class="upload-icon">📂</span>
                                <span class="upload-text">Cargar JSON de Productos</span>
                            </label>
                            <input type="file" id="dropi-file-input" accept=".json" class="dropi-hidden">
                        </div>

                        <div id="dropi-controls" class="dropi-hidden dropi-control-bar">
                            <button id="dropi-prev-btn" class="dropi-nav-btn">◀</button>
                            <span id="dropi-counter" class="dropi-counter-badge">0 / 0</span>
                            <button id="dropi-next-btn" class="dropi-nav-btn">▶</button>
                        </div>

                        <div id="dropi-product-info" class="dropi-hidden product-display-card">
                            <h2 id="dropi-product-title">Seleccione un producto</h2>
                            <div class="price-tag" id="dropi-product-price">$0</div>

                        </div>

                        <div id="dropi-image-gallery" class="dropi-hidden gallery-grid"></div>
                        
                        <div id="dropi-copy-hint" class="dropi-hidden hint-text">
                            💡 Click para Copiar | Arrastrar a Facebook
                        </div>

                        <div id="dropi-actions" class="dropi-hidden action-stack">
                            
                            <!-- Interruptor Bucle Infinito -->
                            <div class="dropi-row" style="margin-bottom: 10px; justify-content: flex-end; align-items: center;">
                                <label style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #fff; cursor: pointer; background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 4px;">
                                    <input type="checkbox" id="dropi-loop-check" style="cursor: pointer;">
                                    <span>🔄 Bucle Infinito</span>
                                </label>
                            </div>

                            <button id="dropi-fill-btn" class="dropi-btn dropi-btn-primary">
                                🚀 Rellenar Datos
                            </button>
                            <div class="dropi-row">
                                <button id="dropi-extras-btn" class="dropi-btn dropi-btn-outline">
                                    🏷️ Extras
                                </button>
                                <button id="dropi-new-post-btn" class="dropi-btn dropi-btn-outline">
                                    🔄 Nuevo
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- === EXTRACTOR SECTION === -->
                    <div id="dropi-content-extractor" class="dropi-hidden">
                        
                        <!-- URL Extraction Card -->
                        <div class="dropi-card-section">
                            <div class="card-header">
                                <span class="card-title">FEED SCRAPER</span>
                            </div>
                            <div class="card-body">
                                <div class="dropi-row">
                                    <button id="dropi-extract-urls-btn" class="dropi-btn dropi-btn-secondary">
                                        🌐 Extraer URLs (Scroll)
                                    </button>
                                    <button id="dropi-stop-urls-btn" class="dropi-btn dropi-btn-danger dropi-stop-btn" style="display:none; width: 45px;" title="Detener">
                                        ⏹
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Detail Extraction Card -->
                        <div class="dropi-card-section">
                            <div class="card-header">
                                <span class="card-title">DETAIL SCRAPER</span>
                            </div>
                            <div class="card-body">
                                <label for="dropi-urls-input" class="dropi-mini-upload">
                                    📂 Cargar Lista URLs
                                </label>
                                <input type="file" id="dropi-urls-input" accept=".json" class="dropi-hidden">
                                
                                <div id="dropi-scrape-status" class="status-indicator" style="display: none;">
                                    <span class="status-dot"></span>
                                    <span id="dropi-scrape-count">0 URLs listas</span>
                                </div>

                                <div class="dropi-row">
                                    <button id="dropi-start-scrape-btn" class="dropi-btn dropi-btn-primary" disabled>
                                        🕷️ Iniciar
                                    </button>
                                    <button id="dropi-stop-scrape-btn" class="dropi-btn dropi-btn-danger dropi-stop-btn" style="display:none; width: 45px;" title="Detener">
                                        ⏹
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Console -->
                        <div id="dropi-console-container" class="console-terminal" style="display:none;">
                            <div class="console-header">
                                <span class="console-title">_TERMINAL PROCESS_</span>
                                <div class="dropi-progress-bar">
                                     <div id="dropi-progress-fill" class="dropi-progress-fill"></div>
                                </div>
                            </div>
                            <div id="dropi-console-logs" class="console-body">
                                <div class="log-entry log-info">[System] Ready...</div>
                            </div>
                        </div>

                    </div>
                    </div>
                    <!-- End Extractor -->

                    <!-- === LICENSE SECTION === -->
                    <div id="dropi-content-license" class="dropi-hidden">
                        
                        <div class="dropi-card-section">
                            <div class="card-header">
                                <span class="card-title">ACTIVAR PLAN</span>
                            </div>
                            <div class="card-body">
                                <p style="font-size:12px; color:#94a3b8; margin:0 0 10px 0;">
                                    Ingresa tu clave para activar o renovar tu plan PRO.
                                </p>
                                <div class="license-input-group">
                                    <input type="text" id="dropi-license-input" class="dropi-input" placeholder="Pegar licencia aquí..." autocomplete="off">
                                    <button id="dropi-activate-btn" class="dropi-btn dropi-btn-primary" style="padding: 10px 16px;">
                                        ACTIVAR
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="dropi-card-section">
                            <div class="card-header">
                                <span class="card-title">SOPORTE Y VENTAS</span>
                            </div>
                            <div class="card-body">
                                <div class="social-grid">
                                    <a href="https://wa.link/q6l1dw" target="_blank" class="social-btn" id="dropi-social-wa">
                                        <span class="social-icon">💬</span>
                                        <span style="font-size:12px; font-weight:600;">Contactar</span>
                                    </a>
                                    <a href="https://t.me/ProgramadorMillonary" target="_blank" class="social-btn" id="dropi-social-tg">
                                        <span class="social-icon">✈️</span>
                                        <span style="font-size:12px; font-weight:600;">Telegram</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="dropi-card-section" style="border:none; background:none;">
                            <div style="text-align:center; color:#64748b; font-size:11px;">
                                ID de Instalación:<br>
                                <span id="dropi-uuid-display" style="font-family:monospace; color:#94a3b8;">...</span>
                            </div>
                        </div>

                    </div>
                </div>
                
                <div class="dropi-footer">
                    v4.0 Premium | By AntiGravity
                </div>
            </div>
        `;
        document.body.appendChild(root);
    },

    bindEvents() {
        // --- TABS ---
        const tabs = document.querySelectorAll('.dropi-tab');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const tabId = tab.dataset.tab;
                document.getElementById('dropi-content-publisher').classList.toggle('dropi-hidden', tabId !== 'publisher');
                document.getElementById('dropi-content-extractor').classList.toggle('dropi-hidden', tabId !== 'extractor');
                document.getElementById('dropi-content-license').classList.toggle('dropi-hidden', tabId !== 'license');

                // Extra UI updates for License tab
                if (tabId === 'license') {
                    if (window.DropiApp.License) {
                        document.getElementById('dropi-uuid-display').innerText = window.DropiApp.License.state.uuid || 'Cargando...';
                    }
                }
            });
        });

        // --- PUBLISHER ---
        document.getElementById('dropi-file-input').addEventListener('change', (e) => this.handleFileUpload(e));

        document.getElementById('dropi-prev-btn').addEventListener('click', () => {
            if (window.DropiApp.State.navigate(-1)) this.render();
        });
        document.getElementById('dropi-next-btn').addEventListener('click', () => {
            if (window.DropiApp.State.navigate(1)) this.render();
        });



        // --- BUCLE INFINITO LISTENER ---
        const loopCheck = document.getElementById('dropi-loop-check');
        if (loopCheck) {
            // Cargar estado guardado
            const savedState = localStorage.getItem('dropi_loop_enabled') === 'true';
            loopCheck.checked = savedState;

            loopCheck.addEventListener('change', (e) => {
                const isEnabled = e.target.checked;
                localStorage.setItem('dropi_loop_enabled', isEnabled);
                console.log(`[DropiUI] Bucle Infinito: ${isEnabled ? 'ON' : 'OFF'}`);

                // Si se activa, intentamos iniciar el ciclo si estamos en la pag correcta
                if (isEnabled && window.DropiApp.AutoLoop) {
                    window.DropiApp.AutoLoop.init();
                }
            });
        }

        document.getElementById('dropi-fill-btn').addEventListener('click', async () => {
            const btn = document.getElementById('dropi-fill-btn');
            const originalText = btn.innerHTML;
            btn.innerHTML = '⚡ Inyectando...';
            btn.disabled = true;

            try {
                const product = window.DropiApp.State.getCurrentProduct();

                // License Check
                if (window.DropiApp.License && !window.DropiApp.License.canPerform('publish')) {
                    throw new Error('Límite de publicación alcanzado. Actualiza tu plan.');
                }
                if (window.DropiApp.License) window.DropiApp.License.recordAction('publish');

                await window.DropiApp.Automation.fillProduct(product);
                btn.innerHTML = '✅ ¡Listo!';
            } catch (error) {
                console.error('[DropiUI]', error);
                btn.innerHTML = '❌ Error';
                alert('Error: ' + error.message);
            } finally {
                btn.disabled = false;
                setTimeout(() => btn.innerHTML = originalText, 2000);
            }
        });

        document.getElementById('dropi-extras-btn').addEventListener('click', async () => {
            const btn = document.getElementById('dropi-extras-btn');
            const originalText = btn.innerText;
            btn.innerText = '⏳ ...';
            btn.disabled = true;
            try {
                const product = window.DropiApp.State.getCurrentProduct();
                if (window.DropiApp.Extras) {
                    await window.DropiApp.Extras.run(product);
                    btn.innerText = '✅ OK';
                } else {
                    alert('Extras module missing.');
                }
            } catch (error) {
                btn.innerText = '❌';
            } finally {
                btn.disabled = false;
                setTimeout(() => btn.innerText = originalText, 2000);
            }
        });

        document.getElementById('dropi-new-post-btn').addEventListener('click', () => {
            window.location.href = 'https://www.facebook.com/marketplace/create/item';
        });

        document.getElementById('dropi-minimize-btn').addEventListener('click', () => this.toggleMinimize());

        // --- LICENSE TAB ACTIONS ---
        document.getElementById('dropi-activate-btn').addEventListener('click', () => {
            const input = document.getElementById('dropi-license-input');
            const key = input.value.trim();
            const btn = document.getElementById('dropi-activate-btn');

            if (key) {
                if (window.DropiApp.License) {
                    btn.innerText = '⏳';
                    btn.disabled = true;

                    window.DropiApp.License.redeemLicense(key).then(res => {
                        btn.innerText = 'ACTIVAR';
                        btn.disabled = false;

                        if (res.success) {
                            alert(`✅ ¡Licencia ACTIVADA!\nNuevo Plan: ${res.plan}`);
                            input.value = ''; // clear

                            // Update UI Badge
                            const badge = document.querySelector('.pro-badge');
                            if (badge) {
                                badge.innerText = res.plan;
                                badge.style.background = (res.plan === 'PRO')
                                    ? 'linear-gradient(135deg, #f59e0b, #ea580c)'
                                    : '#22c55e';
                            }
                            // Hide warning if renewed
                            const warningEl = document.getElementById('dropi-expire-warning');
                            if (warningEl) warningEl.style.display = 'none';

                        } else {
                            alert(`❌ Error: ${res.error}`);
                        }
                    });
                }
            } else {
                alert('Por favor, ingresa una clave.');
            }
        });

        // --- EXTRACTOR BUTTONS ---

        // 1. EXTRACT URLS
        const btnExtractUrls = document.getElementById('dropi-extract-urls-btn');
        const btnStopUrls = document.getElementById('dropi-stop-urls-btn');

        btnExtractUrls.addEventListener('click', async () => {
            btnExtractUrls.disabled = true;
            btnExtractUrls.innerHTML = '⏳ Corriendo...';
            btnStopUrls.style.display = 'flex'; // Show Stop

            try {
                if (window.DropiApp.Extractor) {
                    // License Check
                    if (window.DropiApp.License && !window.DropiApp.License.canPerform('extract')) {
                        btnExtractUrls.innerHTML = '❌ Límite Alcanzado';
                        return;
                    }
                    if (window.DropiApp.License) window.DropiApp.License.recordAction('extract'); // Opt: record batch or single

                    await window.DropiApp.Extractor.downloadUrls();
                    btnExtractUrls.innerHTML = '✅ URLs Listas';
                }
            } catch (e) {
                btnExtractUrls.innerHTML = '❌ Error';
            } finally {
                btnExtractUrls.disabled = false;
                btnStopUrls.style.display = 'none'; // Hide Stop
                setTimeout(() => btnExtractUrls.innerHTML = '🌐 Extraer URLs (Scroll)', 3000);
            }
        });

        btnStopUrls.addEventListener('click', () => {
            if (window.DropiApp.Extractor) {
                window.DropiApp.Extractor.stop();
                btnStopUrls.style.display = 'none';
                btnExtractUrls.innerHTML = '🛑 Detenido';
            }
        });

        // 2. SCRAPE DETAILS
        const urlsInput = document.getElementById('dropi-urls-input');
        const btnStartScrape = document.getElementById('dropi-start-scrape-btn');
        const btnStopScrape = document.getElementById('dropi-stop-scrape-btn');
        let loadedUrls = [];

        urlsInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                try {
                    let content = ev.target.result;
                    if (content.charCodeAt(0) === 0xFEFF) content = content.slice(1);
                    loadedUrls = JSON.parse(content);

                    const countSpan = document.getElementById('dropi-scrape-count');
                    const statusDiv = document.getElementById('dropi-scrape-status');

                    if (Array.isArray(loadedUrls) && loadedUrls.length > 0) {
                        countSpan.innerText = `${loadedUrls.length} URLs cargadas`;
                        statusDiv.style.display = 'flex';
                        btnStartScrape.disabled = false;
                    } else {
                        alert('JSON inválido.');
                        btnStartScrape.disabled = true;
                    }
                } catch (err) {
                    alert('Error JSON: ' + err.message);
                }
            };
            reader.readAsText(file, 'UTF-8');
        });

        btnStartScrape.addEventListener('click', async () => {
            if (loadedUrls.length === 0) return;
            const confirmStart = confirm(`¿Iniciar scraping rápido de ${loadedUrls.length} productos?`);
            if (confirmStart) {
                btnStartScrape.disabled = true;
                btnStartScrape.innerHTML = '🚀 Ejecutando...';
                btnStopScrape.style.display = 'flex'; // Show Stop

                if (window.DropiApp.Extractor) {
                    // License Check
                    if (window.DropiApp.License && !window.DropiApp.License.canPerform('extract')) {
                        btnStartScrape.innerHTML = '❌ Límite Alcanzado';
                        btnStopScrape.style.display = 'none';
                        return;
                    }
                    await window.DropiApp.Extractor.startDetailedExtraction(loadedUrls);
                }

                btnStartScrape.disabled = false;
                btnStartScrape.innerHTML = '🕷️ Iniciar';
                btnStopScrape.style.display = 'none';
            }
        });

        btnStopScrape.addEventListener('click', () => {
            if (window.DropiApp.Extractor) {
                window.DropiApp.Extractor.stop();
                btnStopScrape.style.display = 'none';
                btnStartScrape.innerHTML = '🛑 Detenido';
            }
        });
    },

    makeDraggable() {
        const root = document.getElementById('dropi-extension-root');
        const header = document.getElementById('dropi-header');

        let isDragging = false;
        let startX, startY, initialLeft, initialTop;

        header.addEventListener('mousedown', (e) => {
            if (e.target.closest('button')) return;

            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            const rect = root.getBoundingClientRect();
            initialLeft = rect.left;
            initialTop = rect.top;
            header.style.cursor = 'grabbing';
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            e.preventDefault();
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            root.style.left = `${initialLeft + dx}px`;
            root.style.top = `${initialTop + dy}px`;
            root.style.right = 'auto';
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
            header.style.cursor = 'grab';
        });
    },

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                let content = e.target.result;
                if (content.charCodeAt(0) === 0xFEFF) content = content.slice(1);
                const products = JSON.parse(content);
                window.DropiApp.State.setProducts(products);
                this.render();
            } catch (err) {
                console.error(err);
                alert('Error JSON: ' + err.message);
            }
        };
        reader.readAsText(file, 'UTF-8');
    },

    toggleMinimize() {
        const card = document.getElementById('dropi-extension-card');
        const btn = document.getElementById('dropi-minimize-btn');
        card.classList.toggle('minimized');

        if (card.classList.contains('minimized')) {
            btn.innerText = '□'; // Maximize icon representation
            btn.title = "Maximizar";
        } else {
            btn.innerText = '_'; // Minimize icon
            btn.title = "Minimizar";
        }
    },

    render() {
        const hasProducts = window.DropiApp.State.hasProducts();
        const elementsToToggle = ['dropi-controls', 'dropi-product-info', 'dropi-image-gallery', 'dropi-actions', 'dropi-copy-hint'];

        elementsToToggle.forEach(id => {
            const el = document.getElementById(id);
            if (hasProducts) el.classList.remove('dropi-hidden');
            else el.classList.add('dropi-hidden');
        });

        if (hasProducts) {
            const product = window.DropiApp.State.getCurrentProduct();
            const total = window.DropiApp.State.products.length;
            const index = window.DropiApp.State.currentIndex;

            document.getElementById('dropi-counter').textContent = `${index + 1} / ${total}`;
            document.getElementById('dropi-product-title').textContent = product.title || 'Sin título';

            let price = product.providerPrice || product.suggestedPrice || 0;
            document.getElementById('dropi-product-price').textContent = `$${price}`;

            this.renderGallery(product);
            if (product.images) {
                window.DropiApp.Automation.prepareImages(product.images);
            }


        }

        // Check Expiration Warning
        if (window.DropiApp.License && window.DropiApp.License.state) {
            const days = parseInt(window.DropiApp.License.state.daysLeft);
            const warningEl = document.getElementById('dropi-expire-warning');

            // Ensure element exists before toggling
            if (warningEl) {
                // Check valid number and range [0, 3]
                if (!isNaN(days) && days <= 3) {
                    warningEl.style.display = 'flex'; // Use flex to align with header
                    warningEl.innerHTML = (days <= 0)
                        ? '🚫 <span style="font-weight:800; margin-left:4px;">EXPIRADA</span>'
                        : `⚠️ Expira: <span style="font-weight:800; margin-left:4px;">${days} días</span>`;
                } else {
                    warningEl.style.display = 'none';
                }
            }

            // Update UUID in License tab if rendered
            const uuidEl = document.getElementById('dropi-uuid-display');
            if (uuidEl) uuidEl.innerText = window.DropiApp.License.state.uuid || '...';

            // Force Badge Update (Fix for empty badge)
            window.DropiApp.License.emitChange();
        }
    },

    renderGallery(product) {

        const gallery = document.getElementById('dropi-image-gallery');
        gallery.innerHTML = '';
        if (product.images && product.images.length > 0) {
            product.images.forEach(imgUrl => {
                const img = document.createElement('img');
                img.src = imgUrl;
                img.className = 'dropi-image-thumb';
                img.draggable = true;
                img.title = 'Click para Copiar';
                img.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('text/plain', imgUrl);
                });
                img.addEventListener('click', async () => {
                    img.classList.add('copied-anim');
                    const success = await window.DropiApp.Automation.copyImageToClipboard(imgUrl);
                    if (success) {
                        const hint = document.getElementById('dropi-copy-hint');
                        hint.innerHTML = '<span style="color:#4ade80">✅ Copiada! Ctrl+V en Facebook</span>';
                        setTimeout(() => hint.innerHTML = '💡 Click para Copiar | Arrastrar a Facebook', 3000);
                    }
                    setTimeout(() => img.classList.remove('copied-anim'), 500);
                });
                gallery.appendChild(img);
            });
        } else {
            gallery.innerHTML = '<span class="no-images">Sin imágenes</span>';
        }
    }
};
