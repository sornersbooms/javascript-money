window.DropiApp = window.DropiApp || {};

/**
 * License Module
 * Handles install ID, server sync, limits verification.
 */
window.DropiApp.License = {
    // CAMBIAR ESTA URL POR LA DEL SCRIPT DEL USUARIO
    API_URL: 'https://script.google.com/macros/s/AKfycbwwkM9HRo5sAfqR15uViEXl9dBNttH-D1yXiYR8evKff-7jHbOiWKj8S2rWpdWklywa/exec',

    state: {
        
        uuid: null,
        plan: 'FREE', // TRIAL, BASIC, PRO, FREE(expired)
        daysLeft: 0,
        usage: { publish: 0, extract: 0 },
        limits: { publish: 0, extract: 0 },
        isValid: false,
        loading: true
    },

    async init() {
        await this.loadUUID();
        await this.loadFromCache(); // Cargar caché primero para evitar bloqueo si falla la red
        await this.syncWithServer();
    },

    async loadFromCache() {
        return new Promise(resolve => {
            chrome.storage.local.get(['dropi_license_cache'], (result) => {
                if (result.dropi_license_cache) {
                    console.log('[License] Restored from cache:', result.dropi_license_cache);
                    // Actualizamos estado SIN sobrescribir el storage aun (evitar redundancia)
                    // Pero updateLocalState escribe en storage. No importa, es seguro.
                    this.updateLocalState(result.dropi_license_cache);
                }
                resolve();
            });
        });
    },

    async loadUUID() {
        return new Promise(resolve => {
            chrome.storage.local.get(['dropi_uuid'], (result) => {
                if (result.dropi_uuid) {
                    this.state.uuid = result.dropi_uuid;
                } else {
                    this.state.uuid = crypto.randomUUID();
                    chrome.storage.local.set({ dropi_uuid: this.state.uuid });
                }
                resolve(this.state.uuid);
            });
        });
    },

    async syncWithServer() {
        this.state.loading = true;
        try {
            // "no-cors" doesn't return data in browser for GS, so we typically rely on 
            // a GS script that returns JSONP or handle simple GET if possible with CORS. 
            // Apps Script web apps DO support CORS now if return ContentService is used correctly.
            // But usually needs POST for body data. Let's try POST.

            const response = await fetch(this.API_URL, {
                method: 'POST',
                body: JSON.stringify({ action: 'register_or_check', uuid: this.state.uuid })
                // Apps Script handles JSON ContentType weirdly sometimes, text/plain is safer to avoid preflight issues if strict
            });
            const json = await response.json();

            if (json.success) {
                this.updateLocalState(json.data);
            } else {
                console.error('[License] Server Error:', json.error);
                // Fallback offline logic if needed, or lock
            }
        } catch (e) {
            console.error('[License] Network Error (Offline?):', e);
            // Si falla la red, quizás permitir acceso limitado o usar último estado conocido guardado en storage.
            // Por seguridad, para este MVP, asumiremos "Error de Validación" si no conecta.
        } finally {
            this.state.loading = false;
            this.emitChange();
        }
    },

    updateLocalState(data) {
        this.state.plan = data.plan;
        this.state.daysLeft = parseInt(data.daysLeft) || 0; // Ensure Number
        this.state.isExpired = data.isExpired;
        this.state.usage = data.usage;
        this.state.limits = data.limits;
        this.state.isValid = !data.isExpired;

        // Critical: Store remote config (selectors)
        if (data.config) {
            this.state.config = data.config;
        } else {
            // If no config (expired), clear it
            this.state.config = null;
        }

        console.log('[License] Updated:', this.state);

        // Guardar en local storage
        chrome.storage.local.set({ dropi_license_cache: data });
    },

    async recordAction(type) { // 'publish' or 'extract'
        // Optimistic update locally
        this.state.usage[type]++;

        // Send to server (fire and forget mostly, but check for limit errors)
        try {
            fetch(this.API_URL, {
                method: 'POST',
                mode: 'no-cors', // Fire and forget stats to avoid waiting
                body: JSON.stringify({
                    action: 'update_stats',
                    uuid: this.state.uuid,
                    type: type,
                    count: 1
                })
            });
        } catch (e) { console.error(e); }
    },

    canPerform(type) {
        if (this.state.loading) return true; // Allow while loading? Or wait.
        if (!this.state.isValid) {
            alert(`⛔ Tu licencia ${this.state.plan} ha expirado.\nContacta a soporte para renovar.`);
            return false;
        }

        if (this.state.plan === 'PRO' || this.state.plan === 'TRIAL') return true;

        const limit = this.state.limits[type];
        const used = this.state.usage[type];

        if (used >= limit) {
            alert(`⛔ Has alcanzado el límite de ${type} (${used}/${limit}) de tu plan Básico.\nActualiza a PRO para ilimitado.`);
            return false;
        }
        return true;
    },

    emitChange() {
        // Update UI Badge
        const badge = document.querySelector('.pro-badge');
        if (badge) {
            if (this.state.loading) {
                badge.textContent = '...';
                badge.style.background = '#64748b'; // Slate 500
                return;
            }

            badge.textContent = this.state.plan || 'FREE';

            if (this.state.isExpired) {
                badge.style.background = '#ef4444'; // Red
                badge.textContent = 'OFF';
            } else if (this.state.plan === 'PRO') {
                badge.style.background = 'linear-gradient(135deg, #f59e0b, #ea580c)';
            } else if (this.state.plan === 'TRIAL') {
                badge.style.background = '#3b82f6'; // Blue
            } else if (this.state.plan === 'BASIC') {
                badge.style.background = '#22c55e'; // Green
            } else {
                badge.style.background = '#64748b'; // Gray default
            }
        }
    },

    async redeemLicense(key) {
        if (!key) return { success: false, error: 'Ingrese una licencia' };

        try {
            const response = await fetch(this.API_URL, {
                method: 'POST',
                body: JSON.stringify({
                    action: 'redeem_license',
                    uuid: this.state.uuid,
                    key: key
                })
            });
            const json = await response.json();

            if (json.success) {
                this.updateLocalState(json.data);
                this.emitChange();
                return { success: true, plan: json.data.plan };
            } else {
                return { success: false, error: json.error || 'Error desconocido' };
            }
        } catch (e) {
            return { success: false, error: 'Error de conexión' };
        }
    }
};
