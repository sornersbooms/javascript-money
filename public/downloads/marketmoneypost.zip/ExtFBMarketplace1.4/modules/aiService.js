
window.DropiApp = window.DropiApp || {};

window.DropiApp.AiService = {
    // API CONFIG
    API_KEY: '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',
    API_URL: 'https://api.groq.com/openai/v1/chat/completions',
    MODEL: 'llama-3.1-8b-instant',

    /**
     * Genera TODO el contenido necesario para el listing: Título, Descripción y Categoría.
     * @param {Object} product - Objeto del producto (title, description, etc.)
     * @returns {Object} { title, description, category }
     */
    async generateContent(product) {
        console.log('[AiService] Generando contenido inteligente...');

        // 1. Validar Dependencias (Categorías)
        if (!window.DropiApp.Fields || !window.DropiApp.Fields.Category) {
            console.error('[AiService] Error: Módulo Category no cargado.');
            return null;
        }
        const validCategories = window.DropiApp.Fields.Category.SUPPORTED_CATEGORIES;

        // 2. Construir Prompt
        const prompt = this.buildPrompt(product, validCategories);

        // 3. Llamar API
        try {
            const response = await fetch(this.API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.API_KEY}`
                },
                body: JSON.stringify({
                    model: this.MODEL,
                    messages: [
                        {
                            role: "system",
                            content: "Eres un experto en Copywriting y ventas en Facebook Marketplace. Tu objetivo es generar contenido de ALTA CONVERSIÓN. Responde SIEMPRE en formato JSON válido."
                        },
                        { role: "user", content: prompt }
                    ],
                    temperature: 0.7, // Creatividad balanceada para el copy
                    response_format: { type: "json_object" } // Force JSON Mode if supported or use strict prompting
                })
            });

            if (!response.ok) throw new Error(`API Error: ${response.statusText}`);

            const data = await response.json();
            const content = data.choices[0]?.message?.content;

            console.log('[AiService] Respuesta Raw:', content);

            // Parsear JSON
            let parsed = null;
            try {
                parsed = JSON.parse(content);
            } catch (e) {
                // Fallback si devuelve markdown ```json ... ```
                const clean = content.replace(/```json/g, '').replace(/```/g, '').trim();
                parsed = JSON.parse(clean);
            }

            // Validar Categoría
            if (parsed.category) {
                const exactMatch = validCategories.find(c => c.toLowerCase() === parsed.category.toLowerCase());
                if (exactMatch) parsed.category = exactMatch;
                else {
                    console.warn(`[AiService] Categoría inválida "${parsed.category}".`);
                    parsed.category = null; // Dejar null para fallback
                }
            }

            return parsed;

        } catch (error) {
            console.error('[AiService] Fallo:', error);
            return null;
        }
    },

    buildPrompt(product, categories) {
        return `
            Analiza el siguiente producto y genera contenido optimizado para vender.
            
            PRODUCTO ORIGINAL:
            - Título: "${product.title}"
            - Descripción: "${(product.description || '').substring(0, 500)}"
            
            TAREAS:
            1. CLASIFICAR: OBLIGATORIO elegir una categoría de esta lista: ${JSON.stringify(categories)}. 
               - Instrucción Crítica: Si no estás 100% seguro, ELIGE LA MÁS CERCANA O "Varios". NO la dejes vacía ni inventes una nueva. DEBES devolver una de la lista.
            2. TÍTULO (listing_title): Escribe un título ALTAMENTE persuasivo para vender.
               - Debe sonar como una OPORTUNIDAD ÚNICA. usa Neuromarketing.
               - Incluye 1 o 2 EMOJIS al principio para llamar la atención.
               - NO pongas el nombre del producto seco. Vende el BENEFICIO o la sensación.
               - Ejemplo Malo: "Zapatos negros".
               - Ejemplo Bueno: "🔥 Zapatos de Lujo Super Cómodos - Estilo Único 👟"
               - LONGITUD CRÍTICA: Máximo 60-63 caracteres (obligatorio). (Es VITAL ser breve y directo porque se agregará un texto largo al final).
            3. PRECIO (listing_price): Calcula el precio de venta sugerido siguiendo esta lógica estricta:
               - Base: Precio del Proveedor (${product.providerPrice || 0}) + 30000 (obligatorio).
               - Valor Percibido: Analiza el producto. Si parece premium, lujoso o de alta demanda, agrega un margen extra INTELIGENTE (ej: +5000, +10000, etc.).
               - Si el producto se ve genérico, agrega 0 de valor percibido.
               - El resultado debe ser un NÚMERO entero (sin signos de moneda).
            4. DESCRIPCIÓN (listing_description): Escribe la descripción de ventas siguiendo EXACTAMENTE esta estructura:

            --- ESTRUCTURA OBLIGATORIA START ---
            [Título breve + emoji vendedor + palabra OFERTA si aplica]
            
            [Micro-storytelling: 2 líneas explicando experiencia/solución + validación social breve]
            
            [Lista de 6 a 9 puntos rápidos con emojis (bullets). Información que la gente pregunta: medidas, funciones, beneficios reales. Sin subtítulos.]
            
            🛡️ Garantía 4 meses
            📦 Envío gratis
            💵 Pagas al recibir
            
            [Cierre emocional de 1 línea reforzando valor/urgencia]
            --- ESTRUCTURA OBLIGATORIA END ---

            5. ETIQUETAS (listing_tags): Genera una lista de 3 a 6 etiquetas (keywords) MUY ESPECÍFICAS y de alta relevancia.
               - Regla de Oro: Calidad > Cantidad.
               - Ejemplo Malo: "ventas", "todo", "barato", "oferta" (Palabras vacías).
               - Ejemplo Bueno: "Iphone15", "Apple", "CelularUsado", "Garantia" (Producto + Marca + Condición).
               - Solo palabras clave que un comprador real buscaría. Sin emojis.

            FORMATO DE SALIDA (JSON ÚNICAMENTE):
            {
                "category": "Nombre Exacto Categoría",
                "listing_title": "Título del Anuncio",
                "listing_description": "Texto completo de la descripción siguiendo la estructura",
                "listing_tags": ["tag1", "tag2", "tag3"],
                "listing_price": 100000
            }
        `;
    }
};
