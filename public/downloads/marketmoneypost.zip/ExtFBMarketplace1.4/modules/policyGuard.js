window.DropiApp = window.DropiApp || {};

/**
 * Módulo de Seguridad: PolicyGuard
 * Se encarga de filtrar productos prohibidos ANTES de intentar publicarlos.
 * Utiliza IA para análisis semántico y keywords para detección rápida.
 */
window.DropiApp.PolicyGuard = {

    // Lista negra de palabras clave de alto riesgo (Detección rápida sin IA)
    BLACKLIST_KEYWORDS: [
        "arma", "pistola", "rifle", "municion", "droga", "marihuana", "cbd", "vape",
        "tabaco", "cigarro", "alcohol", "licor", "cerveza", "vino",
        "animal", "perro", "gato", "mascota", "cachorro", "adoptar",
        "sexo", "sexual", "vibrador", "desnudo", "xxx", "adulto",
        "medicina", "medicamento", "pastilla", "suplemento", "farmacia", "covid", "vacuna",
        "dinero", "billete", "moneda", "cripto", "bitcoin", "prestamo", "credito",
        "netflix", "spotify", "cuenta digital", "iptv", "streaming", "hack",
        "falsificacion", "replíca", "clon", "imitacion"
    ],

    /**
     * Verifica si un producto es seguro para publicar.
     * @param {Object} product - El objeto producto (title, description)
     * @returns {Promise<{safe: boolean, reason: string}>}
     */
    async checkProduct(product) {
        console.log('[PolicyGuard] 🛡️ Analizando seguridad del producto...');
        const textToCheck = `${product.title} ${product.description}`.toLowerCase();

        // 1. FILTRO RÁPIDO (Keywords)
        // Ahorra tokens de IA si detecta algo obvio
        for (const word of this.BLACKLIST_KEYWORDS) {
            // Buscamos la palabra palabra completa o muy evidente
            if (textToCheck.includes(` ${word} `) || textToCheck.includes(` ${word}s `)) {
                console.warn(`[PolicyGuard] ❌ DETECTADO POR KEYWORD: "${word}"`);
                return { safe: false, reason: `Palabra prohibida detectada: ${word}` };
            }
        }

        // 2. ANÁLISIS PROFUNDO CON IA (Si el filtro rápido pasa)
        if (window.DropiApp.AiService) {
            try {
                const aiVerdict = await this.askAiModerator(product);
                if (!aiVerdict.safe) {
                    console.warn(`[PolicyGuard] ❌ BLOQUEADO POR IA: ${aiVerdict.reason}`);
                    return aiVerdict;
                }
            } catch (e) {
                console.error('[PolicyGuard] Error consultando IA, asumiendo seguro por defecto (Fallback):', e);
            }
        }

        console.log('[PolicyGuard] ✅ Producto APROBADO.');
        return { safe: true, reason: 'OK' };
    },

    /**
     * Consulta a la IA si el producto viola políticas.
     */
    async askAiModerator(product) {
        const prompt = `
            ACTÚA COMO UN MODERADOR PRAGMÁTICO DE FACEBOOK MARKETPLACE.
            Tu misión es detectar SOLO productos ILEGALES o PELIGROSOS.
            
            NO seas paranoico. Si es un producto físico normal, DEBES permitirlo.

            Producto: "${product.title}"
            Descripción: "${product.description ? product.description.substring(0, 150) : ''}..."

            REGLAS CLARAS:
            ❌ PROHIBIDO: Armas de fuego reales, Drogas, Sexo/Adultos, Animales vivos, Medicinas con receta, Estafas financieras.
            ✅ PERMITIDO: Cuchillos de cocina (Son herramientas), Tijeras, Ropa, Juguetes, Muebles, Electrónica, Cremas cosméticas (sin receta).

            Tu respuesta debe ser un JSON:
            {"allowed": true/false, "reason": "Breve razón"}

            Ejemplo: 
            - "Cuchillo de Chef" -> {"allowed": true}
            - "Pistola Glock" -> {"allowed": false, "reason": "Arma de fuego"}
        `;

        // Simulamos una llamada al servicio de IA existente
        // Nota: Reutilizamos la infraestructura de AiService pero con un prompt especial
        // Como AiService está diseñado para devolver un JSON de producto, 
        // usaremos una llamada directa a la API aquí o ampliaremos AiService.
        // INTEGRACIÓN: Usaremos window.DropiApp.AiService.generateRaw si existiera, 
        // o llamaremos a la API usando la misma config.

        // Para mantener la modularidad, invocamos el método genérico si lo creamos, 
        // o hacemos fetch directo aquí usando la key del AiService.

        const apiKey = window.DropiApp.AiService.API_KEY;
        const model = window.DropiApp.AiService.MODEL;

        if (!apiKey) return { safe: true, reason: "No API Key" };

        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                messages: [{ role: 'user', content: prompt }],
                model: model,
                temperature: 0.1, // Muy determinista
                response_format: { type: "json_object" }
            })
        });

        const data = await response.json();
        const content = data.choices[0].message.content;

        try {
            const json = JSON.parse(content);
            return { safe: json.allowed, reason: json.reason || 'Política infringida' };
        } catch (e) {
            // Si la IA falla el formato, aprobamos por defecto para no bloquear ventas legítimas
            return { safe: true, reason: "Error formato IA" };
        }
    }
};
