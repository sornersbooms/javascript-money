// BACKGROUND SERVICE WORKER v6.0 (Foreground Automation)

// 1. LISTENER
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'GENERATE_PROMPT') {
        const youtubeTabId = sender.tab ? sender.tab.id : null;
        runOrchestrator(request.prompt, youtubeTabId, sendResponse);
        return true;
    }
    if (request.action === 'CHECK_CONNECTION') {
        findTab().then(t => sendResponse({ connected: !!t }));
        return true;
    }
});

// 2. ORCHESTRATOR
async function runOrchestrator(prompt, originTabId, finalResponseCallback) {
    try {
        let tab = await findTab();
        if (!tab) return finalResponseCallback({ status: 'error', message: 'No hay ChatGPT abierto.' });

        console.log('[BG] Switch to ChatGPT (Foreground Mode)');

        // A. FOCUS CHATGPT
        try {
            await chrome.tabs.update(tab.id, { active: true });
            if (tab.windowId) {
                await chrome.windows.update(tab.windowId, { focused: true }).catch(() => { });
            }
        } catch (e) { console.log("Focus error", e); }

        await wait(800);

        // B. PREPARE
        let healthy = await sendMessage(tab.id, { action: 'PING' });
        if (!healthy) {
            await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content_chatgpt.js'] }).catch(() => { });
            await wait(500);
        }

        // C. START
        const startResult = await sendMessage(tab.id, { action: 'START_GENERATION', prompt: prompt });
        if (!startResult || startResult.status === 'error') {
            await returnToYouTube(originTabId);
            return finalResponseCallback({ status: 'error', message: startResult?.message || 'Error iniciando.' });
        }

        // D. LOOP
        let attempts = 0;
        const maxAttempts = 300;
        let lastLength = 0;
        let stability = 0;

        const loop = setInterval(async () => {
            attempts++;

            if (attempts >= maxAttempts) {
                clearInterval(loop);
                sendMessage(tab.id, { action: 'STOP_AUDIO' });
                await returnToYouTube(originTabId);
                return finalResponseCallback({ status: 'timeout', data: "Tiempo agotado." });
            }

            // Active Polling
            let status = null;
            try {
                const results = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => window.__GPT_STATUS
                });
                if (results && results[0] && results[0].result) status = results[0].result;
            } catch (e) { }

            if (!status) return;

            // ... Lógica de estados ...

            if (status.state === 'generating') {
                const len = status.data ? status.data.length : 0;
                if (len > 0) {
                    if (len === lastLength) stability++;
                    else { stability = 0; lastLength = len; }
                }

                // Si terminó "visualmente" y estable (más rápido pues estamos viendo)
                if (stability > 5) {
                    clearInterval(loop);
                    sendMessage(tab.id, { action: 'STOP_AUDIO' });
                    await returnToYouTube(originTabId);
                    return finalResponseCallback({ status: 'success', data: status.data });
                }
            }

            if (status.state === 'complete') {
                clearInterval(loop);
                sendMessage(tab.id, { action: 'STOP_AUDIO' });
                await returnToYouTube(originTabId);
                return finalResponseCallback({ status: 'success', data: status.data });
            }

            if (status.state === 'error') {
                clearInterval(loop);
                await returnToYouTube(originTabId);
                return finalResponseCallback({ status: 'error', message: status.message });
            }

        }, 1000);

    } catch (e) {
        console.error(e);
        if (originTabId) await returnToYouTube(originTabId);
        finalResponseCallback({ status: 'error', message: e.message });
    }
}


// --- HELPERS ---

async function returnToYouTube(tabId) {
    if (tabId) {
        try {
            await chrome.tabs.update(tabId, { active: true });
            const tab = await chrome.tabs.get(tabId);
            if (tab.windowId) {
                await chrome.windows.update(tab.windowId, { focused: true });
            }
        } catch (e) {
            console.log('Error volviendo a YT:', e);
        }
    }
}

async function findTab() {
    const tabs = await chrome.tabs.query({ url: ["*://chatgpt.com/*", "*://chat.openai.com/*"] });
    return (tabs && tabs.length) ? tabs[0] : null;
}

function sendMessage(tabId, msg) {
    return new Promise(resolve => {
        chrome.tabs.sendMessage(tabId, msg, (resp) => {
            if (chrome.runtime.lastError) resolve(null);
            else resolve(resp);
        });
    });
}

function wait(ms) { return new Promise(r => setTimeout(r, ms)); }
