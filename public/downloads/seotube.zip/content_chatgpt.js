// --- CONTENT SCRIPT: CHATGPT (WORKER) v5.0 (Audio Keep-Alive) ---

console.log('[GPT Worker] v5.0 Loaded (Audio Boost)');

// GLOBAL STATE BRIDGE
window.__GPT_STATUS = { state: 'idle', data: '' };
let initialArticleCount = 0;
let audioCtx = null;
let oscillator = null;

// 1. KEEP ALIVE SYSTEM (The "Silent Scream")
// Reproduce un sonido casi inaudible para obligar a Chrome a dar prioridad a la pestaña.
function enableKeepAlive() {
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (audioCtx.state === 'suspended') audioCtx.resume();

        if (!oscillator) {
            oscillator = audioCtx.createOscillator();
            const gainNode = audioCtx.createGain();

            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(440, audioCtx.currentTime); // 440Hz
            gainNode.gain.setValueAtTime(0.0001, audioCtx.currentTime); // Prácticamente silencio

            oscillator.connect(gainNode);
            gainNode.connect(audioCtx.destination);
            oscillator.start();
            console.log('[GPT Worker] Keep-Alive Audio Started');
        }
    } catch (e) {
        console.error('Audio KeepAlive failed:', e);
    }
}

function disableKeepAlive() {
    try {
        if (oscillator) {
            oscillator.stop();
            oscillator.disconnect();
            oscillator = null;
        }
    } catch (e) { }
}


// 2. MONITOR LOOP (Internal Heartbeat)
// Actualiza window.__GPT_STATUS constantemente
setInterval(() => {
    updateGlobalStatus();
}, 500);

function updateGlobalStatus() {
    try {
        // Force Reflow
        document.body.offsetHeight;

        const articles = document.querySelectorAll('article');
        const currentCount = articles.length;

        // Aún no empezó
        if (currentCount <= initialArticleCount) {
            window.__GPT_STATUS = { state: 'waiting_for_start', debug: `Init: ${initialArticleCount}, Curr: ${currentCount}` };
            return;
        }

        // Analizar último mensaje
        const lastArticle = articles[articles.length - 1];
        const isAssistant = lastArticle.querySelector('[data-message-author-role="assistant"]');

        if (!isAssistant) {
            window.__GPT_STATUS = { state: 'generating', data: '', debug: 'User message detected' };
            return;
        }

        const text = getLastResponse(lastArticle);
        const stopBtn = document.querySelector('button[data-testid="stop-button"]');
        const sendBtn = document.querySelector('button[data-testid="send-button"]');

        const isVisuallyDone = !stopBtn || (sendBtn && !sendBtn.disabled);

        if (isVisuallyDone && text.length > 0) {
            window.__GPT_STATUS = { state: 'complete', data: text };
        } else {
            window.__GPT_STATUS = { state: 'generating', data: text };
        }
    } catch (e) {
        window.__GPT_STATUS = { state: 'error', message: e.message };
    }
}


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // 1. PING
    if (request.action === 'PING') {
        sendResponse({ status: 'pong' });
        return;
    }

    // 2. START
    if (request.action === 'START_GENERATION') {
        try {
            enableKeepAlive(); // 🔥 ENABLE BOOST

            const input = findChatInput();
            if (!input) throw new Error('Input no encontrado');

            initialArticleCount = document.querySelectorAll('article').length;
            window.__GPT_STATUS = { state: 'waiting_for_start', data: '' };

            if (!simulateTyping(input, request.prompt)) throw new Error('Error escribiendo');

            setTimeout(async () => {
                await wait(300);
                clickSend();
            }, 100);

            sendResponse({ status: 'started' });
        } catch (e) {
            sendResponse({ status: 'error', message: e.message });
        }
        return;
    }

    // 3. STOP (Cleanup)
    if (request.action === 'STOP_AUDIO') {
        disableKeepAlive();
        sendResponse({ status: 'stopped' });
    }
});


// --- DOM UTILS (Simplifed) ---

function getLastResponse(article) {
    if (!article) return "";
    const contentNode = article.querySelector('.markdown') ||
        article.querySelector('[data-message-author-role="assistant"]');

    let rawText = contentNode ? contentNode.innerText : article.innerText;
    return rawText.replace(/^ChatGPT\n/i, '').replace(/\nCopyToClipboardButton.*$/s, '').trim();
}

function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function findChatInput() {
    return document.querySelector('#prompt-textarea') ||
        document.querySelector('[contenteditable="true"]') ||
        document.querySelector('textarea');
}

function clickSend() {
    const btn = document.querySelector('button[data-testid="send-button"]') ||
        document.querySelector('button[aria-label="Send prompt"]');
    if (btn && !btn.disabled) btn.click();
}

function simulateTyping(inputEl, text) {
    inputEl.focus();
    try { document.execCommand('insertText', false, text); } catch (e) { }

    if (inputEl.tagName === 'TEXTAREA') {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
        setter.call(inputEl, text);
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
        inputEl.innerText = text;
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    }
    return true;
}
