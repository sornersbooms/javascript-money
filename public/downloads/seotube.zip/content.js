// Prefijo para evitar colisiones
const ID_PREFIX = 'dropi-';

// --- FUNCIONES DE UTILIDAD ---

// Función para crear elementos con prefijo de ID automático
function createElement(tag, idSuffix, className = '') {
    const el = document.createElement(tag);
    if (idSuffix) el.id = `${ID_PREFIX}${idSuffix}`;
    if (className) el.className = className;
    return el;
}

// Log en nuestra UI
function logStatus(message, type = 'info') {
    const statusEl = document.getElementById(`${ID_PREFIX}status`);
    if (statusEl) {
        // Find message span if using new UI
        const msgSpan = statusEl.querySelector('span');
        if (msgSpan) {
            msgSpan.innerText = message;
        } else {
            statusEl.textContent = message;
        }

        // Find dot if using new UI
        const dot = statusEl.querySelector('.dropi-status-dot');
        if (dot) {
            dot.className = 'dropi-status-dot ' + type;
        } else {
            statusEl.style.borderLeftColor = type === 'error' ? '#ef4444' : '#10b981';
        }
    }
    console.log(`[ChatGPT Extension] ${message}`);
}

// --- CORE: INTERACCIÓN CON LA PÁGINA ---

// Busca el input del chat (Prioriza contenteditable visible, luego el textarea aunque esté oculto si es necesario)
function findChatInput() {
    // 1. El div contenteditable estándar de ChatGPT (suele tener id prompt-textarea)
    const contentEditable = document.querySelector('#prompt-textarea');
    if (contentEditable) return contentEditable;

    // 2. Fallback: Buscar por el atributo name que nos diste, pero intentamos encontrar su versión visible
    // A veces el textarea está oculto y hay un div hermano que es el interactuable.
    const specificTextarea = document.querySelector('textarea[name="prompt-textarea"]');
    if (specificTextarea) {
        // Si está visible, lo usamos
        if (specificTextarea.offsetParent !== null) return specificTextarea;

        // Si está oculto (display: none), buscamos un hermano contenteditable o 'focusable'
        // A menudo está justo al lado.
        const sibling = specificTextarea.parentElement.querySelector('[contenteditable="true"]');
        if (sibling) return sibling;
    }

    // 3. Fallback genérico
    return document.querySelector('[contenteditable="true"][role="textbox"]') ||
        document.querySelector('textarea');
}

// Busca el botón de enviar
function findSendButton() {
    return document.querySelector('button[data-testid="send-button"]') ||
        document.querySelector('button[aria-label="Send prompt"]') ||
        document.querySelector('button[disabled] svg')?.closest('button'); // A veces cambia
}

// Escribe texto simulando usuario (execCommand para compatibilidad con React)
function simulateTyping(text) {
    const inputEl = findChatInput();
    if (!inputEl) {
        logStatus('Error: No se encontró el input del chat', 'error');
        return false;
    }

    // Enfocar el elemento
    inputEl.focus();

    try {
        const success = document.execCommand('insertText', false, text);

        if (!success) {
            throw new Error('execCommand devolvió false');
        }

        // Disparar eventos manualmente para asegurar que React se entere
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));

        return true;
    } catch (e) {
        console.warn('execCommand falló, intentando fallback...', e);
        // Fallback simple
        inputEl.value = text;
        if (inputEl.innerText !== undefined) inputEl.innerText = text;
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
    }
}

function clickSend() {
    const btn = findSendButton();
    if (btn) {
        if (btn.disabled) {
            logStatus('El botón de enviar está deshabilitado. ¿Hay texto?', 'error');
            return false;
        }
        btn.click();
        return true;
    }
    logStatus('No se encontró el botón de enviar', 'error');
    return false;
}

// --- SCRAPING ---

// Obtiene la última respuesta de ChatGPT
function getLastResponse() {
    // Buscamos todos los elementos con la clase markdown
    const responses = document.querySelectorAll('.markdown');

    if (responses.length === 0) return null;

    // Tomamos el último (la respuesta más reciente)
    const lastResponse = responses[responses.length - 1];
    return lastResponse.innerText; // Retorna solo el texto. .innerHTML para HTML completo
}

function scrapeCurrentGPTInfo() {
    const modelSelector = document.querySelector('div[data-testid="model-selector-dropdown"] span') ||
        document.querySelector('div[class*="text-token-text-secondary"]');

    if (modelSelector) {
        return `Modelo detectado: ${modelSelector.innerText}`;
    }
    return "No se pudo detectar el modelo/GPT info exacto.";
}

// --- PARSING & FORMATTING (YouTube Toolkit) ---

// Intenta parsear una lista numerada de la respuesta
function parseResponseToList(text) {
    if (!text) return [];

    // Regex para encontrar líneas que empiezan con "1.", "1)", "- ", "• "
    // Captura el contenido de la línea
    const regex = /^\s*(?:\d+[\.|)]|-|•)\s+(.+)$/gm;
    let matches = [];
    let match;

    while ((match = regex.exec(text)) !== null) {
        if (match[1] && match[1].trim().length > 0) {
            matches.push(match[1].trim());
        }
    }

    return matches;
}

// Copiar al portapapeles
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        logStatus('Copiado al portapapeles!', 'success');
    }, (err) => {
        logStatus('Error al copiar', 'error');
    });
}

// --- UI INJECTION ---

function injectUI() {
    if (document.getElementById(`${ID_PREFIX}root`)) return;

    const root = createElement('div', 'root');
    const container = createElement('div', 'container');

    // Header
    const header = createElement('div', 'header');
    const title = createElement('h1', 'title');
    title.innerText = 'YouTube Creator Kit';
    header.appendChild(title);

    const closeBtn = createElement('button', 'close-btn', 'dropi-btn dropi-btn-secondary dropi-btn-sm');
    closeBtn.innerText = 'X';
    closeBtn.onclick = () => { container.style.display = 'none'; };
    header.appendChild(closeBtn);

    // Drag logic
    let isDragging = false, startX, startY, initialLeft, initialTop;

    header.onmousedown = (e) => {
        if (e.target === closeBtn) return;
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;

        // Obtener la transform actual (o usar 0,0 si no existe)
        const style = window.getComputedStyle(container);
        const matrix = new WebKitCSSMatrix(style.transform);
        initialLeft = matrix.m41;
        initialTop = matrix.m42;

        document.onmousemove = (e) => {
            if (!isDragging) return;
            e.preventDefault();
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            container.style.transform = `translate3d(${initialLeft + dx}px, ${initialTop + dy}px, 0)`;
        };
        document.onmouseup = () => { isDragging = false; document.onmousemove = null; };
    };

    // Quick Actions Area
    const quickActions = createElement('div', 'quick-actions');
    const labelActions = createElement('span', null, 'dropi-label');
    labelActions.innerText = 'Herramientas Rápidas:';
    quickActions.appendChild(labelActions);

    const actionButtons = [
        { label: '🪄 Títulos Virales', prompt: 'Actúa como un experto en YouTube y SEO. Genera 10 títulos virales, con alto CTR y clickbait moderado para un video sobre: ' },
        { label: '📝 Descripción SEO', prompt: 'Genera una descripción optimizada para YouTube, incluyendo un párrafo introductorio atractivo, puntos clave con emojis, y un llamado a la acción, para el video: ' },
        { label: '🏷️ Tags / Keywords', prompt: 'Dame una lista de 30 etiquetas (keywords) separadas por comas, optimizadas para buscar tráfico en YouTube, para el tema: ' },
        { label: '💡 Ideas de Video', prompt: 'Dame 5 ideas creativas y únicas para videos de YouTube relacionados con: ' }
    ];

    actionButtons.forEach(btn => {
        const chip = createElement('button', null, 'dropi-chip');
        chip.innerText = btn.label;
        chip.onclick = () => {
            const topic = extTextarea.value.trim();
            if (!topic) {
                logStatus('⚠️ Escribe primero el TEMA del video abajo.', 'error');
                extTextarea.focus();
                extTextarea.style.borderColor = '#ec4899';
                setTimeout(() => { extTextarea.style.borderColor = ''; }, 2000);
                return;
            }

            const fullPrompt = `${btn.prompt} "${topic}". ${btn.label.includes('Títulos') ? 'Dame solo la lista, sin introducción.' : ''}`;

            // Auto-send logic
            // extTextarea.value = fullPrompt; // Opcional: mostrar prompt completo
            logStatus(`Generando ${btn.label}...`, 'working');

            if (simulateTyping(fullPrompt)) {
                setTimeout(() => {
                    clickSend();
                    extTextarea.value = topic; // Restaurar el tema
                    logStatus('Solicitud enviada. Esperando respuesta...', 'working');

                    waitForResponse();
                }, 600);
            }
        };
        quickActions.appendChild(chip);
    });

    // Input Area
    const inputArea = createElement('div', 'input-area');
    const labelInput = createElement('label', null, 'dropi-label');
    labelInput.innerText = 'Tema del Video o Prompt Manual:';

    const extTextarea = createElement('textarea', 'message-input', 'dropi-textarea');
    extTextarea.placeholder = 'Ej: Cómo hacer una extensión de Chrome con IA...';

    inputArea.appendChild(labelInput);
    inputArea.appendChild(extTextarea);

    // Manual Actions
    const manualActions = createElement('div', 'actions');
    manualActions.style.display = 'flex';
    manualActions.style.gap = '8px';
    manualActions.style.marginBottom = '12px';

    const sendBtn = createElement('button', 'send-btn', 'dropi-btn');
    sendBtn.innerText = 'Enviar Prompt';
    sendBtn.onclick = () => {
        if (!extTextarea.value) return;
        simulateTyping(extTextarea.value);
        setTimeout(clickSend, 500);
        waitForResponse();
    };

    const scrapeBtn = createElement('button', 'scrape-btn', 'dropi-btn dropi-btn-secondary');
    scrapeBtn.innerText = 'Capturar Respuesta';
    scrapeBtn.onclick = () => {
        renderResults(getLastResponse());
    };

    manualActions.appendChild(sendBtn);
    manualActions.appendChild(scrapeBtn);

    // Results Area
    const resultsContainer = createElement('div', 'results-container');
    resultsContainer.style.display = 'none';

    // Función para renderizar resultados de forma limpia
    function renderResults(text) {
        if (!text) {
            logStatus('No se encontró respuesta.', 'error');
            return;
        }

        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'flex';

        // Intentar detectar si es una lista
        const listItems = parseResponseToList(text);

        if (listItems.length > 0) {
            logStatus(`Se detectaron ${listItems.length} opciones.`, 'success');

            const title = createElement('div', null, 'dropi-label');
            title.innerText = 'Resultados (Clic para copiar):';
            resultsContainer.appendChild(title);

            listItems.forEach(item => {
                const row = createElement('div', null, 'dropi-result-item');
                row.innerText = item;

                const hint = createElement('span', null, 'dropi-copy-hint');
                hint.innerText = 'COPIAR';
                row.appendChild(hint);

                row.onclick = () => {
                    copyToClipboard(item);
                    row.style.background = '#dcfce7';
                    setTimeout(() => { row.style.background = 'white'; }, 200);
                };
                resultsContainer.appendChild(row);
            });
        } else {
            // Texto plano
            logStatus('Respuesta capturada (Texto plano).', 'success');
            const content = createElement('div', 'viewer');
            content.style.cssText = 'font-size: 13px; white-space: pre-wrap; color: #334155;';
            content.innerText = text;

            const copyAllBtn = createElement('button', null, 'dropi-btn dropi-btn-secondary dropi-btn-sm');
            copyAllBtn.innerText = 'Copiar Todo';
            copyAllBtn.style.marginBottom = '8px';
            copyAllBtn.onclick = () => copyToClipboard(text);

            resultsContainer.appendChild(copyAllBtn);
            resultsContainer.appendChild(content);
        }
    }

    // Auto-wait logic
    let checkInterval;
    function waitForResponse() {
        if (checkInterval) clearInterval(checkInterval);
        let attempts = 0;
        const initialText = getLastResponse() || "";

        checkInterval = setInterval(() => {
            attempts++;
            const currentText = getLastResponse();

            // Si el contenido ha crecido significativamente
            if (currentText && currentText !== initialText && currentText.length > initialText.length + 10) {
                const sendBtn = findSendButton();
                // Si el botón de enviar está habilitado de nuevo, terminó de generar
                if (sendBtn && !sendBtn.disabled) {
                    clearInterval(checkInterval);
                    renderResults(currentText);
                    logStatus('¡Respuesta lista!', 'success');
                }
            }

            if (attempts > 300) clearInterval(checkInterval); // 5 minutos max (por si acaso)
        }, 1000);
    }

    // Status Bar
    const status = createElement('div', 'status');
    const dot = createElement('div', null, 'dropi-status-dot active');
    const msg = createElement('span');
    msg.innerText = 'Listo.';
    status.appendChild(dot);
    status.appendChild(msg);

    // Assemble
    container.appendChild(header);
    container.appendChild(quickActions);
    container.appendChild(inputArea);
    container.appendChild(manualActions);
    container.appendChild(resultsContainer);
    container.appendChild(status);

    root.appendChild(container); // Append container to root
    document.body.appendChild(root); // Append root to body
}

// --- INIT ---
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectUI);
} else {
    injectUI();
}

const observer = new MutationObserver(() => {
    if (!document.getElementById(`${ID_PREFIX}root`)) injectUI();
});
observer.observe(document.body, { childList: true, subtree: true });

console.log('YouTube Creator Kit Loaded.');
