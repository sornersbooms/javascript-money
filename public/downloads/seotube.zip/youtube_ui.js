// --- YOUTUBE UI MODULE v3.0 (Smart Creator) ---

class YouTubeUI {
  constructor() {
    this.panel = null;
    this.host = null;
    this.root = null;
    this.bubble = null;
    this.isMinimized = false;

    // Templates
    this.prompts = {
      "default": "",
      "title_viral": "Escribe 10 títulos virales y clickbait para este video de YouTube sobre: ",
      "desc_seo": "Crea una descripción optimizada para SEO (con hashtags) para un video titulado: ",
      "tags": "Genera una lista de 30 etiquetas (tags) separadas por comas de alta relevancia para: ",
      "summary": "Resume el siguiente guion en 3 puntos clave: "
    };
  }

  createPanel() {
    // 1. Shadow Host
    this.host = document.createElement('div');
    this.host.id = 'dropi-host';
    this.host.style.position = 'fixed';
    this.host.style.top = '0px';
    this.host.style.left = '0px';
    this.host.style.zIndex = '9999999';
    this.host.style.width = '0px';
    this.host.style.height = '0px';
    document.body.appendChild(this.host);

    // 2. Shadow Root
    this.root = this.host.attachShadow({ mode: 'open' });

    // 3. Main Panel
    this.panel = document.createElement('div');
    this.panel.id = 'dropi-panel';
    this.panel.innerHTML = `
            <div class="header" id="drag-handle">
                <span class="title">🤖 Creator Kit</span>
                <div class="controls">
                    <button class="icon-btn" id="btn-min">_</button>
                    <button class="icon-btn" id="btn-close">✕</button>
                </div>
            </div>
            
            <div class="content">
                <!-- PRESETS -->
                <div class="presets-row">
                    <select id="template-select">
                        <option value="default">✨ Seleccionar Plantilla...</option>
                        <option value="title_viral">🔥 Títulos Virales</option>
                        <option value="desc_seo">📝 Descripción SEO</option>
                        <option value="tags">🏷️ Generar Tags</option>
                        <option value="summary">📄 Resumir Guion</option>
                    </select>
                </div>

                <!-- INPUT -->
                <textarea id="prompt-input" placeholder="Escribe tu tema o pega tu título aquí..."></textarea>
                
                <!-- ACTION ROW -->
                <div class="action-row">
                    <div class="status" id="status-text">Listo</div>
                    <button id="send-btn">GENERAR</button>
                </div>

                <!-- RESULTS -->
                <div id="result-area" class="result-area" style="display:none;"></div>
                
                <!-- FOOTER ACTIONS -->
                <div class="footer-row" id="result-actions" style="display:none;">
                    <button id="insert-btn" class="secondary-btn">Insertar Todo</button>
                    <button id="copy-btn" class="secondary-btn">Copiar</button>
                    <button id="clear-btn" class="text-btn">Limpiar</button>
                </div>
            </div>
        `;

    // 4. Floating Bubble (Minimized State)
    this.bubble = document.createElement('div');
    this.bubble.id = 'dropi-bubble';
    this.bubble.innerHTML = `<span>🤖</span>`;
    this.bubble.style.display = 'none'; // Hidden by default

    // 5. STYLES
    const style = document.createElement('style');
    style.textContent = `
            /* PANEL */
            #dropi-panel {
                position: fixed;
                top: 20px;
                left: 20px;
                width: 320px;
                background: #1f1f1f;
                color: #ffffff;
                border: 1px solid #333;
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.5);
                font-family: 'Roboto', sans-serif;
                display: flex;
                flex-direction: column;
                overflow: hidden;
                transition: opacity 0.2s, transform 0.2s;
            }

            /* BUBBLE */
            #dropi-bubble {
                position: fixed;
                top: 20px;
                left: 20px;
                width: 50px;
                height: 50px;
                background: #ff0033; /* YouTube Red */
                border-radius: 50%;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: transform 0.2s;
                z-index: 10000;
                font-size: 24px;
            }
            #dropi-bubble:hover { transform: scale(1.1); }

            /* HEADER */
            .header {
                background: #282828;
                padding: 12px 16px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                cursor: move;
                border-bottom: 1px solid #333;
            }
            .title { font-weight: 700; font-size: 14px; color: #fff; }
            .controls { display: flex; gap: 8px; }
            .icon-btn {
                background: none; border: none; color: #aaa;
                cursor: pointer; font-size: 14px; padding: 2px 6px;
                border-radius: 4px;
            }
            .icon-btn:hover { background: #3d3d3d; color: #fff; }

            /* CONTENT */
            .content { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
            
            /* PRESETS SELECT */
            select {
                width: 100%;
                background: #282828;
                color: #ddd;
                border: 1px solid #444;
                padding: 8px;
                border-radius: 6px;
                font-size: 13px;
                outline: none;
                cursor: pointer;
            }
            select:hover { border-color: #666; }

            /* INPUT */
            textarea {
                width: 100%;
                height: 80px;
                background: #121212;
                border: 1px solid #333;
                border-radius: 6px;
                color: #eee;
                padding: 10px;
                resize: vertical;
                font-family: inherit;
                font-size: 13px;
                box-sizing: border-box; /* Fix padding overflow */
            }
            textarea:focus { outline: none; border-color: #065fd4; }

            /* ACTION ROW */
            .action-row { display: flex; justify-content: space-between; align-items: center; }
            .status { font-size: 11px; color: #888; }
            
            button#send-btn {
                background: #065fd4;
                color: white;
                border: none;
                padding: 8px 20px;
                border-radius: 18px;
                font-weight: 600;
                cursor: pointer;
                font-size: 13px;
                transition: background 0.2s;
            }
            button#send-btn:hover { background: #0556bf; }
            button#send-btn:disabled { background: #333; color: #666; cursor: wait; }

            /* RESULT AREA */
            .result-area {
                background: #222;
                padding: 10px;
                border-radius: 6px;
                font-size: 13px;
                line-height: 1.4;
                max-height: 200px;
                overflow-y: auto;
                border: 1px solid #333;
                white-space: pre-wrap; /* Preserve newlines */
            }
            
            /* FOOTER */
            .footer-row { display: flex; gap: 8px; flex-wrap: wrap; }
            .secondary-btn {
                flex: 1;
                background: #333;
                color: #eee;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
            }
            .secondary-btn:hover { background: #444; }
            .text-btn {
                background: none; border: none; color: #666; 
                cursor: pointer; font-size: 11px; text-decoration: underline;
            }
            .text-btn:hover { color: #888; }

            /* SCROLLBAR */
            ::-webkit-scrollbar { width: 6px; }
            ::-webkit-scrollbar-thumb { background: #444; border-radius: 3px; }
            ::-webkit-scrollbar-track { background: transparent; }
        `;

    this.root.appendChild(style);
    this.root.appendChild(this.panel);
    this.root.appendChild(this.bubble); // Append bubble to root too
  }

  getElements() {
    return {
      panel: this.panel,
      bubble: this.bubble, // Expose bubble
      btnMin: this.panel.querySelector('#btn-min'),
      btnClose: this.panel.querySelector('#btn-close'),
      dragHandle: this.panel.querySelector('#drag-handle'),
      input: this.panel.querySelector('#prompt-input'),
      sendBtn: this.panel.querySelector('#send-btn'),
      status: this.panel.querySelector('#status-text'),
      resultArea: this.panel.querySelector('#result-area'),
      resultActions: this.panel.querySelector('#result-actions'),
      insertBtn: this.panel.querySelector('#insert-btn'),
      copyBtn: this.panel.querySelector('#copy-btn'),
      clearBtn: this.panel.querySelector('#clear-btn'),
      templateSelect: this.panel.querySelector('#template-select') // New
    };
  }
}
// Export for usage
window.YouTubeUI = YouTubeUI;
