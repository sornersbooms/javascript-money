// --- MODULE: EVENTS & DRAGGING v3.2 ---
// Handles interaction logic, dragging, and focus protection.

class YouTubeEvents {
    constructor(ui) {
        this.ui = ui;
        this.isDragging = false;
        this.dragOffset = { x: 0, y: 0 };
    }

    init() {
        this.setupGlobalListener(); // Window Level (Capture)
        this.setupHostFirewall();   // Host Level (Bubble)
        this.setupFocusProtection();
    }

    // 1. GLOBAL LISTENER (Window Capture)
    setupGlobalListener() {
        // We catch events at window level to handle dragging smoothly even if mouse leaves the iframe/shadow
        const masterHandler = (e) => {
            const { panel, header, bubble, dragHandle } = this.ui.getElements();

            // Detect drag target (Header OR Bubble)
            const path = e.composedPath();
            const isHeaderClick = path.includes(dragHandle) || path.includes(header);
            const isBubbleClick = path.includes(bubble);

            // --- A) DRAG START ---
            if (e.type === 'mousedown') {
                if (isHeaderClick || isBubbleClick) {
                    // Ignore buttons
                    if (path.some(el => el.classList && (el.classList.contains('icon-btn') || el.classList.contains('controls')))) return;

                    this.isDragging = true;
                    this.targetEl = isBubbleClick ? bubble : panel; // Move which element?

                    if (this.targetEl) {
                        const rect = this.targetEl.getBoundingClientRect();
                        this.dragOffset.x = e.clientX - rect.left;
                        this.dragOffset.y = e.clientY - rect.top;

                        if (header) header.style.cursor = 'grabbing';
                        if (bubble) bubble.style.cursor = 'grabbing';

                        // We must preventDefault here to stop text selection during drag
                        e.preventDefault();
                        return;
                    }
                }
            }

            // --- B) DRAG MOVE ---
            if (e.type === 'mousemove' && this.isDragging && this.targetEl) {
                e.preventDefault(); e.stopPropagation();
                let newX = e.clientX - this.dragOffset.x;
                let newY = e.clientY - this.dragOffset.y;

                // Boundaries
                const width = this.targetEl.offsetWidth;
                const height = this.targetEl.offsetHeight;
                newX = Math.max(0, Math.min(newX, window.innerWidth - width));
                newY = Math.max(0, Math.min(newY, window.innerHeight - height));

                this.targetEl.style.left = `${newX}px`;
                this.targetEl.style.top = `${newY}px`;
                return;
            }

            // --- C) DRAG END ---
            if (e.type === 'mouseup' && this.isDragging) {
                this.isDragging = false;
                if (header) header.style.cursor = 'move';
                if (bubble) bubble.style.cursor = 'pointer';
                this.targetEl = null;

                e.preventDefault(); e.stopPropagation();
                return;
            }

            // --- D) INTERACTION FIREWALL (Smart Filter) ---
            const isInsidePanel = path.includes(this.ui.panel) || path.includes(this.ui.host) || path.includes(this.ui.root);

            if (isInsidePanel) {
                // 1. FOCUS CLOAK (Capture Phase)
                // If YouTube's Focus Trap sees us getting focus, it steals it back.
                if (e.type === 'focus' || e.type === 'focusin') {
                    e.stopPropagation();
                    return;
                }

                // 2. INPUT PROTECTION
                // We do NOT block keydown/mousedown here in Capture, 
                // so they can reach the input. We block them later at Host level.
            }
        };

        const events = ['mousedown', 'mousemove', 'mouseup', 'click', 'keydown', 'keyup', 'keypress', 'input', 'change', 'focus', 'blur', 'focusin'];
        events.forEach(evt => window.addEventListener(evt, masterHandler, true));
    }

    // 2. HOST FIREWALL (Bubble Phase)
    // This stops events from bubbling UP to YouTube listeners on document/body
    setupHostFirewall() {
        const host = this.ui.host;
        const kill = (e) => {
            e.stopPropagation();
        };

        ['keydown', 'keyup', 'keypress', 'input', 'change', 'mousedown', 'mouseup', 'click', 'contextmenu'].forEach(evt => {
            if (this.ui.root) this.ui.root.addEventListener(evt, kill);
            if (host) host.addEventListener(evt, kill);
        });
    }

    // 3. AGGRESSIVE FOCUS PROTECTION
    setupFocusProtection() {
        const { input } = this.ui.getElements();
        if (input) {
            // Prevent Tab/Enter from triggering YouTube shortcuts if they bubble up (double safety)
            input.addEventListener('keydown', (e) => {
                e.stopPropagation();
            });
        }
    }
}

window.YouTubeEvents = YouTubeEvents;
