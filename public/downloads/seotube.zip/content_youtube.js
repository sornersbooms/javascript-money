// --- CONTROLLER: MAIN LOGIC v3.0 (Smart Creator) ---
// Orchestrates UI, Events, and Data

(function () {
    console.log('[Dropi] Initializing v3.0 (Smart Creator)...');

    let ui = null;
    let events = null;
    let lastYoutubeInput = null;

    // --- 1. SETUP & INJECTION ---
    async function init() {
        if (window.hasDropi) return;
        window.hasDropi = true;

        // Init UI
        ui = new window.YouTubeUI();
        ui.createPanel();

        // Init Events (Drag, Focus protection)
        events = new window.YouTubeEvents(ui);
        events.init();

        // Bind Actions
        bindActions();

        // Load Persistence (Position & State)
        await loadState();

        // Start Tracking YouTube Inputs
        trackYoutubeInputs();

        console.log('[Dropi] Ready.');
    }

    // --- 2. LOGIC BINDING ---
    function bindActions() {
        const {
            btnMin, btnClose, sendBtn, input,
            templateSelect, resultActions,
            insertBtn, copyBtn, clearBtn, bubble, resultArea
        } = ui.getElements();

        // --- Controls ---

        // Minimize
        btnMin.onclick = () => toggleMinimize(true);
        bubble.onclick = () => toggleMinimize(false);

        // Close
        btnClose.onclick = () => {
            ui.host.style.display = 'none';
        };

        // Template Selection
        templateSelect.onchange = () => {
            const key = templateSelect.value;
            if (ui.prompts[key]) {
                input.value = ui.prompts[key];
                input.focus();
            }
        };

        // --- Core Actions ---

        // Send (Generate)
        sendBtn.onclick = () => {
            const text = input.value.trim();
            if (!text) {
                setStatus('Escribe un tema...', 'error');
                return;
            }
            processRequest(text);
        };

        // Insert All
        insertBtn.onclick = () => {
            const text = resultArea.innerText;
            if (text) handleInsert(text, insertBtn);
        };

        // Copy
        copyBtn.onclick = () => {
            navigator.clipboard.writeText(resultArea.innerText);
            setStatus('📋 Copiado', 'success');
        };

        // Clear
        clearBtn.onclick = () => {
            resultArea.innerText = '';
            resultArea.style.display = 'none';
            resultActions.style.display = 'none';
            input.value = '';
            setStatus('Limpio', 'active');
        };
    }

    // --- 3. STATE MANAGEMENT (Persistence) ---
    function toggleMinimize(minimize) {
        ui.isMinimized = minimize;
        if (minimize) {
            ui.panel.style.opacity = '0';
            ui.panel.style.pointerEvents = 'none';
            ui.bubble.style.display = 'flex';
        } else {
            ui.panel.style.opacity = '1';
            ui.panel.style.pointerEvents = 'auto';
            ui.bubble.style.display = 'none';
        }
        saveState();
    }

    function saveState() {
        const state = {
            top: ui.panel.style.top,
            left: ui.panel.style.left,
            minimized: ui.isMinimized
        };
        chrome.storage.local.set({ 'dropi_state': state });
    }

    async function loadState() {
        const data = await chrome.storage.local.get('dropi_state');
        if (data && data.dropi_state) {
            const s = data.dropi_state;
            if (s.top) {
                ui.panel.style.top = s.top;
                ui.bubble.style.top = s.top; // Sync bubble pos too
            }
            if (s.left) {
                ui.panel.style.left = s.left;
                ui.bubble.style.left = s.left;
            }
            if (s.minimized) {
                toggleMinimize(true);
            }
        }
    }

    // --- 4. COMMUNICATION ---
    function processRequest(prompt) {
        setStatus('🧠 Pensando... (Consultando ChatGPT)', 'working');
        const { resultArea, resultActions } = ui.getElements();

        resultArea.style.display = 'none';
        resultActions.style.display = 'none';

        chrome.runtime.sendMessage({
            action: 'GENERATE_PROMPT',
            prompt: prompt
        }, (response) => {
            if (chrome.runtime.lastError || !response) {
                setStatus('❌ Error de conexión', 'error');
                return;
            }

            if (response.status === 'success') {
                setStatus('✅ ¡Listo! Click para insertar', 'success');
                renderResults(response.data);
            } else {
                setStatus('❌ Error: ' + response.message, 'error');
            }
        });
    }

    // --- 5. RENDERING ---
    function renderResults(text) {
        const { resultArea, resultActions } = ui.getElements();

        // Show container
        resultArea.style.display = 'block';
        resultActions.style.display = 'flex';
        resultArea.innerHTML = ''; // Clear raw text

        // Parse Smart List
        const listItems = parseResponseToList(text);

        if (listItems.length > 0) {
            // Header Hint
            const label = document.createElement('div');
            label.style.fontSize = '11px';
            label.style.color = '#888';
            label.style.marginBottom = '8px';
            label.innerText = '👇 Click para insertar una opción:';
            resultArea.appendChild(label);

            listItems.forEach(item => {
                // Item Row
                const row = document.createElement('div');
                row.style.cssText = `
                    display: flex; 
                    align-items: center; 
                    gap: 8px; 
                    padding: 8px; 
                    background: #2a2a2a; 
                    border-radius: 6px; 
                    margin-bottom: 6px; 
                    cursor: pointer; 
                    border: 1px solid transparent; 
                    transition: all 0.2s;
                `;

                // Icon
                const icon = document.createElement('span');
                icon.innerText = '📥';
                icon.style.fontSize = '14px';

                // Text
                const textSpan = document.createElement('span');
                textSpan.innerText = item;
                textSpan.style.fontSize = '13px';
                textSpan.style.lineHeight = '1.3';
                textSpan.style.color = '#eee';

                row.append(icon, textSpan);

                // Hover Effect
                row.onmouseenter = () => { row.style.background = '#333'; row.style.borderColor = '#555'; };
                row.onmouseleave = () => { row.style.background = '#2a2a2a'; row.style.borderColor = 'transparent'; };

                // Click Action
                row.onclick = () => {
                    handleInsert(item, row);
                };

                resultArea.appendChild(row);
            });
        } else {
            // Fallback for non-list responses (Summary, intro, etc)
            resultArea.innerText = text;
        }
    }

    function parseResponseToList(text) {
        if (!text) return [];
        const lines = text.split('\n').filter(line => line.trim().length > 0);
        const items = [];

        // Regex for numbered lists or bullets: (1. | 1) | - | •)
        const explicitListRegex = /^\s*(?:(?:\d+[\.|)]?)|-|•)\s+(.*)$/;
        // Regex for quoted titles: "Title Here"
        const quotedRegex = /^\s*["“](.*?)["”]\s*$/;

        lines.forEach(line => {
            let cleanLine = line.trim();
            let match = null;

            // 1. Check for Explicit List (1. Title)
            if ((match = cleanLine.match(explicitListRegex))) {
                cleanLine = match[1].trim();
            }

            // 2. Check for Quotes ("Title") - Can be inside list or standalone
            if ((match = cleanLine.match(quotedRegex))) {
                cleanLine = match[1].trim();
            }

            // 3. Filter out conversational filler (e.g. "Here are 5 titles:")
            if (cleanLine.endsWith(':') || cleanLine.length < 3) return;

            items.push(cleanLine);
        });

        // Use heuristic: If we found at least 2 items, it's a list. Otherwise, return [] to trigger raw fallback
        return items.length >= 2 ? items : [];
    }

    function handleInsert(text, uiElement) {
        if (insertTextIntoLastInput(text)) {
            setStatus('✨ ¡Insertado con éxito!', 'success');
        } else {
            navigator.clipboard.writeText(text);
            setStatus('📋 Copiado (No había campo seleccionado)', 'warning');
        }
    }

    // --- 6. HELPERS ---
    function setStatus(msgText, type) {
        const { status, status: { firstElementChild: dot } } = ui.getElements();
        // Since we access DOT differently in new UI getter
        // Let's just fix the status element text
        if (status) {
            status.innerText = msgText;
            status.style.color = type === 'error' ? '#ef4444' : (type === 'success' ? '#10b981' : '#9ca3af');
        }
    }

    // --- 7. AGGRESSIVE AGENTS ---
    function trackYoutubeInputs() {
        document.addEventListener('focus', (e) => {
            if (e.target === ui.host) return; // Ignore self
            if (isEditable(e.target)) {
                lastYoutubeInput = e.target;
            }
        }, true);
    }

    function isEditable(el) {
        if (!el) return false;
        return el.tagName === 'INPUT' ||
            el.tagName === 'TEXTAREA' ||
            el.isContentEditable ||
            el.getAttribute('role') === 'textbox';
    }

    function insertTextIntoLastInput(text) {
        if (!lastYoutubeInput || !document.contains(lastYoutubeInput)) {
            return false;
        }
        try {
            lastYoutubeInput.focus();
            const success = document.execCommand('insertText', false, text);
            if (!success) {
                lastYoutubeInput.value = text;
            }
            lastYoutubeInput.dispatchEvent(new Event('input', { bubbles: true }));
            // Trigger YouTube specific events
            return true;
        } catch (e) {
            console.error(e);
            return false;
        }
    }

    // --- 8. GLOBAL PERSISTENCE LISTENER (Drag End) ---
    // We need to hook into the Drag event from youtube_events.js
    // OR we just monitor style changes. Simplest is to save on mouseup.
    document.addEventListener('mouseup', () => {
        if (ui && ui.panel) saveState();
    });


    // --- 9. BOOTSTRAP ---
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // SPA Watchdog
    setInterval(() => {
        if (!document.getElementById('dropi-host') && document.body) {
            window.hasDropi = false;
            init();
        }
    }, 2000);

})();
